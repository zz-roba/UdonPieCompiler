from typing import Any

from . UnityEngineParticleSystemAnimationTimeMode import UnityEngineParticleSystemAnimationTimeMode


class UnityEngineParticleSystemAnimationTimeMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemAnimationTimeMode:
        return UnityEngineParticleSystemAnimationTimeMode
