from typing import Any

from . UnityEngineParticleSystemBurst import UnityEngineParticleSystemBurst


class UnityEngineParticleSystemBurst:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst
