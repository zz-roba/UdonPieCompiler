from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineParticleSystemBurst import UnityEngineParticleSystemBurst
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean
from . SystemInt16 import SystemInt16


class UnityEngineParticleSystemBurst:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: SystemInt16) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: SystemInt16, input_2: SystemInt16) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: SystemInt16, input_2: SystemInt16, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: UnityEngineParticleSystemMinMaxCurve) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: UnityEngineParticleSystemMinMaxCurve, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineParticleSystemBurst:
        return UnityEngineParticleSystemBurst

    @staticmethod
    def get_count() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_cycleCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_maxCount() -> SystemInt16:
        return SystemInt16

    @staticmethod
    def get_minCount() -> SystemInt16:
        return SystemInt16

    @staticmethod
    def get_probability() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_repeatInterval() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_time() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_count(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_cycleCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_maxCount(input_1: SystemInt16) -> None:
        return 

    @staticmethod
    def set_minCount(input_1: SystemInt16) -> None:
        return 

    @staticmethod
    def set_probability(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_repeatInterval(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_time(input_1: Union[SystemSingle, int, float]) -> None:
        return 
