from typing import Any

from . UnityEngineMeshTopology import UnityEngineMeshTopology


class UnityEngineMeshTopology:

    def __new__(cls, input_1: Any) -> UnityEngineMeshTopology:
        return UnityEngineMeshTopology
