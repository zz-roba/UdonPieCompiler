from typing import Any

from . UnityEngineParticleSystemEmitterVelocityMode import UnityEngineParticleSystemEmitterVelocityMode


class UnityEngineParticleSystemEmitterVelocityMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemEmitterVelocityMode:
        return UnityEngineParticleSystemEmitterVelocityMode
