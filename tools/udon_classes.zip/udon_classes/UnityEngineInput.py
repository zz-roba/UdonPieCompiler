from typing import Union
from typing import Any

from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineInput import UnityEngineInput
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . UnityEngineKeyCode import UnityEngineKeyCode
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineVector3 import UnityEngineVector3
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemInt32 import SystemInt32


class UnityEngineInput:

    def __new__(cls, input_1: Any) -> UnityEngineInput:
        return UnityEngineInput

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAxis(input_0: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetAxisRaw(input_0: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetButton(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetButtonDown(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetButtonUp(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetJoystickNames() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetKey(input_0: UnityEngineKeyCode) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetKey(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetKeyDown(input_0: UnityEngineKeyCode) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetKeyDown(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetKeyUp(input_0: UnityEngineKeyCode) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetKeyUp(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetMouseButton(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetMouseButtonDown(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetMouseButtonUp(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineInput:
        return UnityEngineInput

    @staticmethod
    def get_anyKey() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_anyKeyDown() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_imeIsSelected() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_inputString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_mousePosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_mousePresent() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_mouseScrollDelta() -> UnityEngineVector2:
        return UnityEngineVector2
