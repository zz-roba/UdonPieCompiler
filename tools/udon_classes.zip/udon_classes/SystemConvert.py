from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemInt64 import SystemInt64
from . SystemSingle import SystemSingle
from . SystemInt32 import SystemInt32
from . SystemByteArray import SystemByteArray
from . SystemSByte import SystemSByte
from . SystemChar import SystemChar
from . SystemBase64FormattingOptions import SystemBase64FormattingOptions
from . SystemInt16 import SystemInt16
from . SystemDouble import SystemDouble
from . SystemBoolean import SystemBoolean
from . SystemByte import SystemByte
from . SystemConvert import SystemConvert
from . SystemCharArray import SystemCharArray
from . SystemDateTime import SystemDateTime
from . SystemObject import SystemObject
from . SystemDecimal import SystemDecimal
from . SystemUInt32 import SystemUInt32
from . SystemString import SystemString
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemUInt16 import SystemUInt16
from . SystemUInt64 import SystemUInt64


class SystemConvert:

    def __new__(cls, input_1: Any) -> SystemConvert:
        return SystemConvert

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FromBase64CharArray(input_0: SystemCharArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> SystemByteArray:
        return SystemByteArray

    @staticmethod
    def FromBase64String(input_0: Union[SystemString, str]) -> SystemByteArray:
        return SystemByteArray

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToBase64CharArray(input_0: SystemByteArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: SystemCharArray, input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToBase64CharArray(input_0: SystemByteArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: SystemCharArray, input_4: Union[SystemInt32, int], input_5: SystemBase64FormattingOptions) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToBase64String(input_0: SystemByteArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToBase64String(input_0: SystemByteArray, input_1: SystemBase64FormattingOptions) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToBase64String(input_0: SystemByteArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToBase64String(input_0: SystemByteArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: SystemBase64FormattingOptions) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToBoolean(input_0: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemObject, input_1: SystemIFormatProvider) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemSByte) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemByte) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemUInt32) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemInt64) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemUInt64) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemDecimal) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToBoolean(input_0: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToByte(input_0: SystemObject) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemBoolean, bool]) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemByte) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemChar) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemSByte) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemInt16) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemUInt16) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemInt32, int]) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemUInt32) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemInt64) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemUInt64) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemSingle, int, float]) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemDouble) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemDecimal) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemString, str]) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: SystemDateTime) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToByte(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemByte:
        return SystemByte

    @staticmethod
    def ToChar(input_0: SystemObject) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: Union[SystemBoolean, bool]) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemChar) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemSByte) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemByte) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemInt16) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemUInt16) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: Union[SystemInt32, int]) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemUInt32) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemInt64) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemUInt64) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: Union[SystemString, str]) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: Union[SystemSingle, int, float]) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemDouble) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemDecimal) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToChar(input_0: SystemDateTime) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToDateTime(input_0: SystemDateTime) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemObject) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: Union[SystemString, str]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemSByte) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemByte) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemInt16) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemUInt16) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemUInt32) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemUInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: Union[SystemBoolean, bool]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemChar) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: Union[SystemSingle, int, float]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDateTime(input_0: SystemDecimal) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToDecimal(input_0: SystemObject) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemSByte) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemByte) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemChar) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemInt16) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemUInt16) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: Union[SystemInt32, int]) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemUInt32) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemInt64) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemUInt64) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: Union[SystemSingle, int, float]) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemDouble) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: Union[SystemString, str]) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemDecimal) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: Union[SystemBoolean, bool]) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDecimal(input_0: SystemDateTime) -> SystemDecimal:
        return SystemDecimal

    @staticmethod
    def ToDouble(input_0: SystemObject) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemSByte) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemByte) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemInt16) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemChar) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemUInt16) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: Union[SystemInt32, int]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemUInt32) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemInt64) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemUInt64) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: Union[SystemSingle, int, float]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemDouble) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemDecimal) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: Union[SystemString, str]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: Union[SystemBoolean, bool]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToDouble(input_0: SystemDateTime) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToInt16(input_0: SystemObject) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemBoolean, bool]) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemChar) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemSByte) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemByte) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemUInt16) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemInt32, int]) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemUInt32) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemInt16) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemInt64) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemUInt64) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemSingle, int, float]) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemDouble) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemDecimal) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemString, str]) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: SystemDateTime) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt16(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemInt16:
        return SystemInt16

    @staticmethod
    def ToInt32(input_0: SystemObject) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemObject, input_1: SystemIFormatProvider) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemSByte) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemByte) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemUInt32) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemInt64) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemUInt64) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemDouble) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemDecimal) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: SystemDateTime) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt32(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToInt64(input_0: SystemObject) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemBoolean, bool]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemChar) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemSByte) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemByte) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemInt16) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemUInt16) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemInt32, int]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemUInt32) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemUInt64) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemInt64) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemSingle, int, float]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemDouble) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemDecimal) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemString, str]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: SystemDateTime) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToInt64(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToSByte(input_0: SystemObject) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemBoolean, bool]) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemSByte) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemChar) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemByte) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemInt16) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemUInt16) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemInt32, int]) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemUInt32) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemInt64) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemUInt64) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemSingle, int, float]) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemDouble) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemDecimal) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemString, str]) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: SystemDateTime) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSByte(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemSByte:
        return SystemSByte

    @staticmethod
    def ToSingle(input_0: SystemObject) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemObject, input_1: SystemIFormatProvider) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemSByte) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemByte) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemChar) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemInt16) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemUInt16) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemUInt32) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemInt64) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemUInt64) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemDouble) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemDecimal) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: Union[SystemBoolean, bool]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToSingle(input_0: SystemDateTime) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToString(input_0: SystemObject) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemObject, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemChar, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemSByte) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemSByte, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemByte) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemByte, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt16) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt16, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt16) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt16, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemInt32, int], input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt32) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt32, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt64) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt64, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt64) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemUInt64, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemSingle, int, float]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemSingle, int, float], input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDouble) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDouble, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDecimal) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDecimal, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDateTime) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemDateTime, input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemByte, input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt16, input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemInt64, input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemBoolean, bool]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: Union[SystemBoolean, bool], input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUInt16(input_0: SystemObject) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemBoolean, bool]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemChar) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemSByte) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemByte) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemInt16) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemInt32, int]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemUInt16) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemUInt32) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemInt64) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemUInt64) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemSingle, int, float]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemDouble) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemDecimal) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemString, str]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: SystemDateTime) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt16(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToUInt32(input_0: SystemObject) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemBoolean, bool]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemChar) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemSByte) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemByte) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemInt16) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemUInt16) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemInt32, int]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemUInt32) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemInt64) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemUInt64) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemSingle, int, float]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemDouble) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemDecimal) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemString, str]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: SystemDateTime) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt32(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def ToUInt64(input_0: SystemObject) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemObject, input_1: SystemIFormatProvider) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemBoolean, bool]) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemChar) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemSByte) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemByte) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemInt16) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemUInt16) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemInt32, int]) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemUInt32) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemInt64) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemUInt64) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemSingle, int, float]) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemDouble) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemDecimal) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemString, str]) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: SystemDateTime) -> SystemUInt64:
        return SystemUInt64

    @staticmethod
    def ToUInt64(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemUInt64:
        return SystemUInt64
