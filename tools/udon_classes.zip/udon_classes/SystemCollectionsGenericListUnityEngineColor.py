from typing import Any

from . SystemCollectionsGenericListUnityEngineColor import SystemCollectionsGenericListUnityEngineColor


class SystemCollectionsGenericListUnityEngineColor:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineColor:
        return SystemCollectionsGenericListUnityEngineColor
