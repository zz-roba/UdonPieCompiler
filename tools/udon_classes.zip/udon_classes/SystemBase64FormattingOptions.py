from typing import Any

from . SystemBase64FormattingOptions import SystemBase64FormattingOptions


class SystemBase64FormattingOptions:

    def __new__(cls, input_1: Any) -> SystemBase64FormattingOptions:
        return SystemBase64FormattingOptions
