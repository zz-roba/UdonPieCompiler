from typing import Any

from . UnityEngineAnimationsAxis import UnityEngineAnimationsAxis


class UnityEngineAnimationsAxis:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationsAxis:
        return UnityEngineAnimationsAxis
