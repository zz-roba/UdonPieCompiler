from typing import Any

from . UnityEngineParticleSystemTrailMode import UnityEngineParticleSystemTrailMode


class UnityEngineParticleSystemTrailMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemTrailMode:
        return UnityEngineParticleSystemTrailMode
