from typing import Any

from . UnityEngineParticleSystemForceOverLifetimeModuleArray import UnityEngineParticleSystemForceOverLifetimeModuleArray


class UnityEngineParticleSystemForceOverLifetimeModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemForceOverLifetimeModuleArray:
        return UnityEngineParticleSystemForceOverLifetimeModuleArray
