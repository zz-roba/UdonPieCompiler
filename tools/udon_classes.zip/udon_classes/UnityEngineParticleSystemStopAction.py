from typing import Any

from . UnityEngineParticleSystemStopAction import UnityEngineParticleSystemStopAction


class UnityEngineParticleSystemStopAction:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemStopAction:
        return UnityEngineParticleSystemStopAction
