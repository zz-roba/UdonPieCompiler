from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineAnimationsConstraintSource import UnityEngineAnimationsConstraintSource
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineAnimationsConstraintSource:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationsConstraintSource:
        return UnityEngineAnimationsConstraintSource

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_sourceTransform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_weight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_sourceTransform(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def set_weight(input_1: Union[SystemSingle, int, float]) -> None:
        return 
