from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineLayerMask import UnityEngineLayerMask
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineLayerMask:

    def __new__(cls, input_1: Any) -> UnityEngineLayerMask:
        return UnityEngineLayerMask

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMask(input_0: SystemStringArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def LayerToName(input_0: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def NameToLayer(input_0: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_value() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Implicit(input_0: UnityEngineLayerMask) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Implicit(input_0: Union[SystemInt32, int]) -> UnityEngineLayerMask:
        return UnityEngineLayerMask

    @staticmethod
    def set_value(input_1: Union[SystemInt32, int]) -> None:
        return 
