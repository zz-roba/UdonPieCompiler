from typing import Union
from typing import Any

from . UnityEngineHumanLimit import UnityEngineHumanLimit
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineHumanBone import UnityEngineHumanBone
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class UnityEngineHumanBone:

    def __new__(cls, input_1: Any) -> UnityEngineHumanBone:
        return UnityEngineHumanBone

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_boneName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_humanName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_limit() -> UnityEngineHumanLimit:
        return UnityEngineHumanLimit

    @staticmethod
    def set_boneName(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_humanName(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_limit() -> UnityEngineHumanLimit:
        return UnityEngineHumanLimit
