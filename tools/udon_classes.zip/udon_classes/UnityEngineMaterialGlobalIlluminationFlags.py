from typing import Any

from . UnityEngineMaterialGlobalIlluminationFlags import UnityEngineMaterialGlobalIlluminationFlags


class UnityEngineMaterialGlobalIlluminationFlags:

    def __new__(cls, input_1: Any) -> UnityEngineMaterialGlobalIlluminationFlags:
        return UnityEngineMaterialGlobalIlluminationFlags
