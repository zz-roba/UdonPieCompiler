from typing import Any

from . UnityEngineConfigurableJointMotion import UnityEngineConfigurableJointMotion


class UnityEngineConfigurableJointMotion:

    def __new__(cls, input_1: Any) -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion
