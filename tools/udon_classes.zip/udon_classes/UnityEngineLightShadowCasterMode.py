from typing import Any

from . UnityEngineLightShadowCasterMode import UnityEngineLightShadowCasterMode


class UnityEngineLightShadowCasterMode:

    def __new__(cls, input_1: Any) -> UnityEngineLightShadowCasterMode:
        return UnityEngineLightShadowCasterMode
