from typing import Any

from . SystemCollectionsGenericListUnityEngineSprite import SystemCollectionsGenericListUnityEngineSprite


class SystemCollectionsGenericListUnityEngineSprite:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineSprite:
        return SystemCollectionsGenericListUnityEngineSprite
