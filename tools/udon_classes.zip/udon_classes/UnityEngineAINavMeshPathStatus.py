from typing import Any

from . UnityEngineAINavMeshPathStatus import UnityEngineAINavMeshPathStatus


class UnityEngineAINavMeshPathStatus:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshPathStatus:
        return UnityEngineAINavMeshPathStatus
