from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineBounds import UnityEngineBounds
from . UnityEngineAnimationState import UnityEngineAnimationState
from . SystemBoolean import SystemBoolean
from . UnityEngineQueueMode import UnityEngineQueueMode
from . T import T
from . SystemInt32 import SystemInt32
from . UnityEngineAnimation import UnityEngineAnimation
from . SystemCollectionsIEnumerator import SystemCollectionsIEnumerator
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . UnityEngineAnimationCullingType import UnityEngineAnimationCullingType
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . UnityEngineWrapMode import UnityEngineWrapMode
from . SystemString import SystemString
from . UnityEnginePlayMode import UnityEnginePlayMode
from . UnityEngineAnimationClip import UnityEngineAnimationClip
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject


class UnityEngineAnimation:

    def __new__(cls, input_1: Any) -> UnityEngineAnimation:
        return UnityEngineAnimation

    @staticmethod
    def AddClip(input_1: UnityEngineAnimationClip, input_2: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def AddClip(input_1: UnityEngineAnimationClip, input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def AddClip(input_1: UnityEngineAnimationClip, input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Blend(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Blend(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Blend(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: UnityEnginePlayMode) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def CrossFadeQueued(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: UnityEngineQueueMode, input_4: UnityEnginePlayMode) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def CrossFadeQueued(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: UnityEngineQueueMode) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def CrossFadeQueued(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def CrossFadeQueued(input_1: Union[SystemString, str]) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetClip(input_1: Union[SystemString, str]) -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def GetClipCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimation, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimation, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimation, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimation, input_1: T) -> None:
        return 

    @staticmethod
    def GetEnumerator() -> SystemCollectionsIEnumerator:
        return SystemCollectionsIEnumerator

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsPlaying(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Play() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Play(input_1: UnityEnginePlayMode) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Play(input_1: Union[SystemString, str], input_2: UnityEnginePlayMode) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Play(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def PlayQueued(input_1: Union[SystemString, str], input_2: UnityEngineQueueMode, input_3: UnityEnginePlayMode) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def PlayQueued(input_1: Union[SystemString, str], input_2: UnityEngineQueueMode) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def PlayQueued(input_1: Union[SystemString, str]) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def RemoveClip(input_1: UnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def RemoveClip(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Rewind(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Rewind() -> None:
        return 

    @staticmethod
    def Sample() -> None:
        return 

    @staticmethod
    def Stop() -> None:
        return 

    @staticmethod
    def Stop(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def SyncLayer(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Item(input_1: Union[SystemString, str]) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def get_animatePhysics() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_clip() -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def get_cullingType() -> UnityEngineAnimationCullingType:
        return UnityEngineAnimationCullingType

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_isPlaying() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_localBounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_playAutomatically() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_wrapMode() -> UnityEngineWrapMode:
        return UnityEngineWrapMode

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_animatePhysics(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_clip(input_1: UnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def set_cullingType(input_1: UnityEngineAnimationCullingType) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_localBounds(input_1: UnityEngineBounds) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_playAutomatically(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_wrapMode(input_1: UnityEngineWrapMode) -> None:
        return 
