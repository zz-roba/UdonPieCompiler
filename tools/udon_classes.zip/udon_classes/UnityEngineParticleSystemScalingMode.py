from typing import Any

from . UnityEngineParticleSystemScalingMode import UnityEngineParticleSystemScalingMode


class UnityEngineParticleSystemScalingMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemScalingMode:
        return UnityEngineParticleSystemScalingMode
