from typing import Any

from . UnityEngineLightType import UnityEngineLightType


class UnityEngineLightType:

    def __new__(cls, input_1: Any) -> UnityEngineLightType:
        return UnityEngineLightType
