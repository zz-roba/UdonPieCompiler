from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . UnityEngineFingerDof import UnityEngineFingerDof
from . SystemInt32 import SystemInt32
from . UnityEngineBodyDof import UnityEngineBodyDof
from . UnityEngineHumanPartDof import UnityEngineHumanPartDof
from . UnityEngineLegDof import UnityEngineLegDof
from . SystemString import SystemString
from . UnityEngineExperimentalAnimationsMuscleHandleArray import UnityEngineExperimentalAnimationsMuscleHandleArray
from . UnityEngineExperimentalAnimationsMuscleHandle import UnityEngineExperimentalAnimationsMuscleHandle
from . UnityEngineArmDof import UnityEngineArmDof
from . UnityEngineHeadDof import UnityEngineHeadDof
from . SystemBoolean import SystemBoolean


class UnityEngineExperimentalAnimationsMuscleHandle:

    def __new__(cls, input_1: Any) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMuscleHandles(input_0: UnityEngineExperimentalAnimationsMuscleHandleArray) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: UnityEngineBodyDof) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def ctor(input_0: UnityEngineHeadDof) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def ctor(input_0: UnityEngineHumanPartDof, input_1: UnityEngineLegDof) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def ctor(input_0: UnityEngineHumanPartDof, input_1: UnityEngineArmDof) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def ctor(input_0: UnityEngineHumanPartDof, input_1: UnityEngineFingerDof) -> UnityEngineExperimentalAnimationsMuscleHandle:
        return UnityEngineExperimentalAnimationsMuscleHandle

    @staticmethod
    def get_dof() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_humanPartDof() -> UnityEngineHumanPartDof:
        return UnityEngineHumanPartDof

    @staticmethod
    def get_muscleHandleCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]
