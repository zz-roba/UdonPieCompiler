from typing import Any

from . UnityEngineParticleSystemParticle import UnityEngineParticleSystemParticle


class UnityEngineParticleSystemParticle:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemParticle:
        return UnityEngineParticleSystemParticle
