from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . ListT import ListT
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineObject import UnityEngineObject
from . SystemSingle import SystemSingle
from . SystemString import SystemString
from . UnityEngineFrictionJoint2D import UnityEngineFrictionJoint2D
from . UnityEngineRigidbody2D import UnityEngineRigidbody2D
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineTransform import UnityEngineTransform
from . SystemInt32 import SystemInt32
from . SystemType import SystemType
from . T import T


class UnityEngineFrictionJoint2D:

    def __new__(cls, input_1: Any) -> UnityEngineFrictionJoint2D:
        return UnityEngineFrictionJoint2D

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineFrictionJoint2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineFrictionJoint2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineFrictionJoint2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineFrictionJoint2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetReactionForce(input_1: Union[SystemSingle, int, float]) -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def GetReactionTorque(input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_anchor() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_attachedRigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_autoConfigureConnectedAnchor() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_breakForce() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_breakTorque() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_connectedAnchor() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_connectedBody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_enableCollision() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_maxForce() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxTorque() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_reactionForce() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_reactionTorque() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_anchor(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_autoConfigureConnectedAnchor(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_breakForce(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_breakTorque(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_connectedAnchor(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_connectedBody(input_1: UnityEngineRigidbody2D) -> None:
        return 

    @staticmethod
    def set_enableCollision(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_maxForce(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxTorque(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 
