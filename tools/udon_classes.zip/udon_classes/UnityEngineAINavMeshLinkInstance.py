from typing import Any

from . UnityEngineAINavMeshLinkInstance import UnityEngineAINavMeshLinkInstance


class UnityEngineAINavMeshLinkInstance:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshLinkInstance:
        return UnityEngineAINavMeshLinkInstance
