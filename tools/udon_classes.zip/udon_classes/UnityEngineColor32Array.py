from typing import Any

from . UnityEngineColor32Array import UnityEngineColor32Array


class UnityEngineColor32Array:

    def __new__(cls, input_1: Any) -> UnityEngineColor32Array:
        return UnityEngineColor32Array
