from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . UnityEngineColor import UnityEngineColor
from . SystemObject import SystemObject
from . SystemInt32Array import SystemInt32Array
from . SystemSingleArray import SystemSingleArray
from . SystemInt32 import SystemInt32
from . SystemSingleRef import SystemSingleRef
from . SystemString import SystemString
from . SystemUInt16 import SystemUInt16
from . UnityEngineMathf import UnityEngineMathf
from . SystemBoolean import SystemBoolean


class UnityEngineMathf:

    def __new__(cls, input_1: Any) -> UnityEngineMathf:
        return UnityEngineMathf

    @staticmethod
    def Abs(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Abs(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Acos(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Approximately(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Asin(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Atan(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Atan2(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Ceil(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def CeilToInt(input_0: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Clamp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Clamp(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Clamp01(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ClosestPowerOfTwo(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CorrelatedColorTemperatureToRGB(input_0: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def Cos(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def DeltaAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Exp(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def FloatToHalf(input_0: Union[SystemSingle, int, float]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def Floor(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def FloorToInt(input_0: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Gamma(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GammaToLinearSpace(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def HalfToFloat(input_0: SystemUInt16) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def InverseLerp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def IsPowerOfTwo(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Lerp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def LerpAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def LerpUnclamped(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def LinearToGammaSpace(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Log(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Log(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Log10(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Max(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Max(input_0: SystemSingleArray) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Max(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Max(input_0: SystemInt32Array) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Min(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Min(input_0: SystemSingleArray) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Min(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Min(input_0: SystemInt32Array) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def MoveTowards(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def MoveTowardsAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def NextPowerOfTwo(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def PerlinNoise(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def PingPong(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Pow(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Repeat(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Round(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def RoundToInt(input_0: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Sign(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Sin(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDamp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDamp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDamp(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDampAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDampAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothDampAngle(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: SystemSingleRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def SmoothStep(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Sqrt(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Tan(input_0: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Deg2Rad() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_Epsilon() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_Infinity() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_NegativeInfinity() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_PI() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_Rad2Deg() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]
