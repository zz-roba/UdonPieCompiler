from typing import Any

from . UnityEngineAnimationBlendMode import UnityEngineAnimationBlendMode


class UnityEngineAnimationBlendMode:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationBlendMode:
        return UnityEngineAnimationBlendMode
