from typing import Any

from . UnityEngineHorizontalWrapMode import UnityEngineHorizontalWrapMode


class UnityEngineHorizontalWrapMode:

    def __new__(cls, input_1: Any) -> UnityEngineHorizontalWrapMode:
        return UnityEngineHorizontalWrapMode
