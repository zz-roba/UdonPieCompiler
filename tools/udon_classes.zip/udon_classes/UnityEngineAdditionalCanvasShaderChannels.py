from typing import Any

from . UnityEngineAdditionalCanvasShaderChannels import UnityEngineAdditionalCanvasShaderChannels


class UnityEngineAdditionalCanvasShaderChannels:

    def __new__(cls, input_1: Any) -> UnityEngineAdditionalCanvasShaderChannels:
        return UnityEngineAdditionalCanvasShaderChannels
