from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineObject import UnityEngineObject
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemSingleArray import SystemSingleArray
from . SystemInt32 import SystemInt32
from . UnityEngineAudioClip import UnityEngineAudioClip
from . UnityEngineAudioClipPCMSetPositionCallback import UnityEngineAudioClipPCMSetPositionCallback
from . UnityEngineAudioDataLoadState import UnityEngineAudioDataLoadState
from . SystemString import SystemString
from . UnityEngineAudioClipPCMReaderCallback import UnityEngineAudioClipPCMReaderCallback
from . UnityEngineAudioClipLoadType import UnityEngineAudioClipLoadType
from . SystemBoolean import SystemBoolean


class UnityEngineAudioClip:

    def __new__(cls, input_1: Any) -> UnityEngineAudioClip:
        return UnityEngineAudioClip

    @staticmethod
    def Create(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemBoolean, bool]) -> UnityEngineAudioClip:
        return UnityEngineAudioClip

    @staticmethod
    def Create(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemBoolean, bool], input_5: UnityEngineAudioClipPCMReaderCallback) -> UnityEngineAudioClip:
        return UnityEngineAudioClip

    @staticmethod
    def Create(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemBoolean, bool], input_5: UnityEngineAudioClipPCMReaderCallback, input_6: UnityEngineAudioClipPCMSetPositionCallback) -> UnityEngineAudioClip:
        return UnityEngineAudioClip

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetData(input_1: SystemSingleArray, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def LoadAudioData() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetData(input_1: SystemSingleArray, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def UnloadAudioData() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_ambisonic() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_channels() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_frequency() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_length() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_loadInBackground() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_loadState() -> UnityEngineAudioDataLoadState:
        return UnityEngineAudioDataLoadState

    @staticmethod
    def get_loadType() -> UnityEngineAudioClipLoadType:
        return UnityEngineAudioClipLoadType

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_preloadAudioData() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_samples() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 
