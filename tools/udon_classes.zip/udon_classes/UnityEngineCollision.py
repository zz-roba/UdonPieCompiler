from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineTransform import UnityEngineTransform
from . SystemObject import SystemObject
from . UnityEngineContactPoint import UnityEngineContactPoint
from . SystemInt32 import SystemInt32
from . UnityEngineCollision import UnityEngineCollision
from . SystemCollectionsIEnumerator import SystemCollectionsIEnumerator
from . UnityEngineContactPointArray import UnityEngineContactPointArray
from . UnityEngineCollider import UnityEngineCollider
from . SystemString import SystemString
from . UnityEngineRigidbody import UnityEngineRigidbody
from . UnityEngineGameObject import UnityEngineGameObject
from . SystemBoolean import SystemBoolean


class UnityEngineCollision:

    def __new__(cls, input_1: Any) -> UnityEngineCollision:
        return UnityEngineCollision

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetContact(input_1: Union[SystemInt32, int]) -> UnityEngineContactPoint:
        return UnityEngineContactPoint

    @staticmethod
    def GetContacts(input_1: UnityEngineContactPointArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetEnumerator() -> SystemCollectionsIEnumerator:
        return SystemCollectionsIEnumerator

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineCollision:
        return UnityEngineCollision

    @staticmethod
    def get_collider() -> UnityEngineCollider:
        return UnityEngineCollider

    @staticmethod
    def get_contactCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_contacts() -> UnityEngineContactPointArray:
        return UnityEngineContactPointArray

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_impulse() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_relativeVelocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_rigidbody() -> UnityEngineRigidbody:
        return UnityEngineRigidbody

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform
