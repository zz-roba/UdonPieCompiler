from typing import Any

from . UnityEngineParticleSystemCollisionMode import UnityEngineParticleSystemCollisionMode


class UnityEngineParticleSystemCollisionMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCollisionMode:
        return UnityEngineParticleSystemCollisionMode
