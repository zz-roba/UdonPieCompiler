from typing import Any

from . UnityEngineJointAngleLimits2D import UnityEngineJointAngleLimits2D


class UnityEngineJointAngleLimits2D:

    def __new__(cls, input_1: Any) -> UnityEngineJointAngleLimits2D:
        return UnityEngineJointAngleLimits2D
