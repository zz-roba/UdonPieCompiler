from typing import Any

from . UnityEngineParticleSystemRotationBySpeedModuleArray import UnityEngineParticleSystemRotationBySpeedModuleArray


class UnityEngineParticleSystemRotationBySpeedModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemRotationBySpeedModuleArray:
        return UnityEngineParticleSystemRotationBySpeedModuleArray
