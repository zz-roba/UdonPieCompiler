from typing import Any

from . UnityEngineCameraCameraCallback import UnityEngineCameraCameraCallback


class UnityEngineCameraCameraCallback:

    def __new__(cls, input_1: Any) -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback
