from typing import Any

from . SystemTimeSpan import SystemTimeSpan


class SystemTimeSpan:

    def __new__(cls, input_1: Any) -> SystemTimeSpan:
        return SystemTimeSpan
