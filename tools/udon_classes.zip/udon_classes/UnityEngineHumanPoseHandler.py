from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineAvatar import UnityEngineAvatar
from . UnityEngineTransform import UnityEngineTransform
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineHumanPoseRef import UnityEngineHumanPoseRef
from . UnityEngineHumanPoseHandler import UnityEngineHumanPoseHandler
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineHumanPoseHandler:

    def __new__(cls, input_1: Any) -> UnityEngineHumanPoseHandler:
        return UnityEngineHumanPoseHandler

    @staticmethod
    def Dispose() -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHumanPose(input_1: UnityEngineHumanPoseRef) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def SetHumanPose(input_1: UnityEngineHumanPoseRef) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: UnityEngineAvatar, input_1: UnityEngineTransform) -> UnityEngineHumanPoseHandler:
        return UnityEngineHumanPoseHandler
