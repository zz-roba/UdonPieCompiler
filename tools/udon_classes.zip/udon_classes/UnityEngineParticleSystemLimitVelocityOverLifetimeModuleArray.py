from typing import Any

from . UnityEngineParticleSystemLimitVelocityOverLifetimeModuleArray import UnityEngineParticleSystemLimitVelocityOverLifetimeModuleArray


class UnityEngineParticleSystemLimitVelocityOverLifetimeModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemLimitVelocityOverLifetimeModuleArray:
        return UnityEngineParticleSystemLimitVelocityOverLifetimeModuleArray
