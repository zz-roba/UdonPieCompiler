from typing import Any

from . UnityEngineHeadDof import UnityEngineHeadDof


class UnityEngineHeadDof:

    def __new__(cls, input_1: Any) -> UnityEngineHeadDof:
        return UnityEngineHeadDof
