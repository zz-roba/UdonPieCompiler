from typing import Any

from . SystemCollectionsGenericListUnityEngineBoneWeight import SystemCollectionsGenericListUnityEngineBoneWeight


class SystemCollectionsGenericListUnityEngineBoneWeight:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineBoneWeight:
        return SystemCollectionsGenericListUnityEngineBoneWeight
