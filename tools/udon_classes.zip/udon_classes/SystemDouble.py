from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemGlobalizationNumberStyles import SystemGlobalizationNumberStyles
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemDoubleRef import SystemDoubleRef
from . SystemDouble import SystemDouble
from . SystemBoolean import SystemBoolean


class SystemDouble:

    def __new__(cls, input_1: Any) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def CompareTo(input_1: SystemObject) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: SystemDouble) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsInfinity(input_0: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNaN(input_0: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNegativeInfinity(input_0: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsPositiveInfinity(input_0: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Parse(input_0: Union[SystemString, str]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles, input_2: SystemIFormatProvider) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str], input_2: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemDoubleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles, input_2: SystemIFormatProvider, input_3: SystemDoubleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_Epsilon() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def get_MaxValue() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def get_MinValue() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def get_NaN() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def get_NegativeInfinity() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def get_PositiveInfinity() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def op_Addition(input_0: SystemDouble, input_1: SystemDouble) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def op_Division(input_0: SystemDouble, input_1: SystemDouble) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def op_Equality(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThan(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThanOrEqual(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThan(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThanOrEqual(input_0: SystemDouble, input_1: SystemDouble) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Multiplication(input_0: SystemDouble, input_1: SystemDouble) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def op_Subtraction(input_0: SystemDouble, input_1: SystemDouble) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def op_UnaryMinus(input_0: SystemDouble) -> SystemDouble:
        return SystemDouble
