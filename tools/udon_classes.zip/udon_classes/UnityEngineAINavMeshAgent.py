from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . SystemBoolean import SystemBoolean
from . UnityEngineAINavMeshPath import UnityEngineAINavMeshPath
from . UnityEngineAINavMeshPathStatus import UnityEngineAINavMeshPathStatus
from . T import T
from . SystemInt32 import SystemInt32
from . UnityEngineAINavMeshAgent import UnityEngineAINavMeshAgent
from . UnityEngineAIObstacleAvoidanceType import UnityEngineAIObstacleAvoidanceType
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . UnityEngineAINavMeshHitRef import UnityEngineAINavMeshHitRef
from . SystemString import SystemString
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineAIOffMeshLinkData import UnityEngineAIOffMeshLinkData


class UnityEngineAINavMeshAgent:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshAgent:
        return UnityEngineAINavMeshAgent

    @staticmethod
    def ActivateCurrentOffMeshLink(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def CalculatePath(input_1: UnityEngineVector3, input_2: UnityEngineAINavMeshPath) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CompleteOffMeshLink() -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FindClosestEdge(input_1: UnityEngineAINavMeshHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAreaCost(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAINavMeshAgent, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAINavMeshAgent, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAINavMeshAgent, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAINavMeshAgent, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Move(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def Raycast(input_1: UnityEngineVector3, input_2: UnityEngineAINavMeshHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ResetPath() -> None:
        return 

    @staticmethod
    def SamplePathPosition(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: UnityEngineAINavMeshHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetAreaCost(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetDestination(input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetPath(input_1: UnityEngineAINavMeshPath) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Warp(input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_acceleration() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_agentTypeID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_angularSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_areaMask() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_autoBraking() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_autoRepath() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_autoTraverseOffMeshLink() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_avoidancePriority() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_baseOffset() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_currentOffMeshLinkData() -> UnityEngineAIOffMeshLinkData:
        return UnityEngineAIOffMeshLinkData

    @staticmethod
    def get_desiredVelocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_destination() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_hasPath() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_height() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_isOnNavMesh() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isOnOffMeshLink() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isPathStale() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isStopped() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_navMeshOwner() -> UnityEngineObject:
        return UnityEngineObject

    @staticmethod
    def get_nextOffMeshLinkData() -> UnityEngineAIOffMeshLinkData:
        return UnityEngineAIOffMeshLinkData

    @staticmethod
    def get_nextPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_obstacleAvoidanceType() -> UnityEngineAIObstacleAvoidanceType:
        return UnityEngineAIObstacleAvoidanceType

    @staticmethod
    def get_path() -> UnityEngineAINavMeshPath:
        return UnityEngineAINavMeshPath

    @staticmethod
    def get_pathEndPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_pathPending() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_pathStatus() -> UnityEngineAINavMeshPathStatus:
        return UnityEngineAINavMeshPathStatus

    @staticmethod
    def get_radius() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_remainingDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_speed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_steeringTarget() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_stoppingDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_updatePosition() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_updateRotation() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_updateUpAxis() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_velocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_acceleration(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_agentTypeID(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_angularSpeed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_areaMask(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_autoBraking(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_autoRepath(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_autoTraverseOffMeshLink(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_avoidancePriority(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_baseOffset(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_destination(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_height(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_isStopped(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_nextPosition(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_obstacleAvoidanceType(input_1: UnityEngineAIObstacleAvoidanceType) -> None:
        return 

    @staticmethod
    def set_path(input_1: UnityEngineAINavMeshPath) -> None:
        return 

    @staticmethod
    def set_radius(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_speed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_stoppingDistance(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_updatePosition(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_updateRotation(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_updateUpAxis(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_velocity(input_1: UnityEngineVector3) -> None:
        return 
