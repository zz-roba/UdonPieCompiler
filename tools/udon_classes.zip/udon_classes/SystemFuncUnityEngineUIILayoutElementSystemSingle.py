from typing import Any

from . SystemFuncUnityEngineUIILayoutElementSystemSingle import SystemFuncUnityEngineUIILayoutElementSystemSingle


class SystemFuncUnityEngineUIILayoutElementSystemSingle:

    def __new__(cls, input_1: Any) -> SystemFuncUnityEngineUIILayoutElementSystemSingle:
        return SystemFuncUnityEngineUIILayoutElementSystemSingle
