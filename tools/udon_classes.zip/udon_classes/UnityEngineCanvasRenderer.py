from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . ListT import ListT
from . SystemCollectionsGenericListUnityEngineVector2 import SystemCollectionsGenericListUnityEngineVector2
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineMaterial import UnityEngineMaterial
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineColor import UnityEngineColor
from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4
from . SystemInt32 import SystemInt32
from . T import T
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineCanvasRenderer import UnityEngineCanvasRenderer
from . SystemBoolean import SystemBoolean
from . UnityEngineRect import UnityEngineRect
from . UnityEngineMesh import UnityEngineMesh
from . UnityEngineTexture import UnityEngineTexture
from . SystemCollectionsGenericListUnityEngineUIVertex import SystemCollectionsGenericListUnityEngineUIVertex
from . SystemCollectionsGenericListUnityEngineVector3 import SystemCollectionsGenericListUnityEngineVector3
from . UnityEngineComponent import UnityEngineComponent
from . SystemCollectionsGenericListUnityEngineColor32 import SystemCollectionsGenericListUnityEngineColor32
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemString import SystemString
from . SystemCollectionsGenericListSystemInt32 import SystemCollectionsGenericListSystemInt32


class UnityEngineCanvasRenderer:

    def __new__(cls, input_1: Any) -> UnityEngineCanvasRenderer:
        return UnityEngineCanvasRenderer

    @staticmethod
    def AddUIVertexStream(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector3, input_6: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def AddUIVertexStream(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector2, input_6: SystemCollectionsGenericListUnityEngineVector2, input_7: SystemCollectionsGenericListUnityEngineVector3, input_8: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def Clear() -> None:
        return 

    @staticmethod
    def CreateUIVertexStream(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector3, input_6: SystemCollectionsGenericListUnityEngineVector4, input_7: SystemCollectionsGenericListSystemInt32) -> None:
        return 

    @staticmethod
    def CreateUIVertexStream(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector2, input_6: SystemCollectionsGenericListUnityEngineVector2, input_7: SystemCollectionsGenericListUnityEngineVector3, input_8: SystemCollectionsGenericListUnityEngineVector4, input_9: SystemCollectionsGenericListSystemInt32) -> None:
        return 

    @staticmethod
    def DisableRectClipping() -> None:
        return 

    @staticmethod
    def EnableRectClipping(input_1: UnityEngineRect) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAlpha() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineCanvasRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineCanvasRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineCanvasRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineCanvasRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInheritedAlpha() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMaterial(input_1: Union[SystemInt32, int]) -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def GetMaterial() -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def GetPopMaterial(input_1: Union[SystemInt32, int]) -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def SetAlpha(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetAlphaTexture(input_1: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetColor(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def SetMaterial(input_1: UnityEngineMaterial, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetMaterial(input_1: UnityEngineMaterial, input_2: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetMesh(input_1: UnityEngineMesh) -> None:
        return 

    @staticmethod
    def SetPopMaterial(input_1: UnityEngineMaterial, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetTexture(input_1: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SplitUIVertexStreams(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector3, input_6: SystemCollectionsGenericListUnityEngineVector4, input_7: SystemCollectionsGenericListSystemInt32) -> None:
        return 

    @staticmethod
    def SplitUIVertexStreams(input_0: SystemCollectionsGenericListUnityEngineUIVertex, input_1: SystemCollectionsGenericListUnityEngineVector3, input_2: SystemCollectionsGenericListUnityEngineColor32, input_3: SystemCollectionsGenericListUnityEngineVector2, input_4: SystemCollectionsGenericListUnityEngineVector2, input_5: SystemCollectionsGenericListUnityEngineVector2, input_6: SystemCollectionsGenericListUnityEngineVector2, input_7: SystemCollectionsGenericListUnityEngineVector3, input_8: SystemCollectionsGenericListUnityEngineVector4, input_9: SystemCollectionsGenericListSystemInt32) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_absoluteDepth() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_cull() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_cullTransparentMesh() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_hasMoved() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasPopInstruction() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasRectClipping() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_materialCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_popMaterialCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_relativeDepth() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_cull(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_cullTransparentMesh(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_hasPopInstruction(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_materialCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_popMaterialCount(input_1: Union[SystemInt32, int]) -> None:
        return 
