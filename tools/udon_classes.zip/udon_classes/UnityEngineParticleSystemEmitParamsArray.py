from typing import Any

from . UnityEngineParticleSystemEmitParamsArray import UnityEngineParticleSystemEmitParamsArray


class UnityEngineParticleSystemEmitParamsArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemEmitParamsArray:
        return UnityEngineParticleSystemEmitParamsArray
