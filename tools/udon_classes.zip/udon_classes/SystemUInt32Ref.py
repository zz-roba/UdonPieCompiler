from typing import Any

from . SystemUInt32Ref import SystemUInt32Ref


class SystemUInt32Ref:

    def __new__(cls, input_1: Any) -> SystemUInt32Ref:
        return SystemUInt32Ref
