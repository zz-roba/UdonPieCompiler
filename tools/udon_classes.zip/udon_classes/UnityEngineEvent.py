from typing import Any

from . UnityEngineEvent import UnityEngineEvent


class UnityEngineEvent:

    def __new__(cls, input_1: Any) -> UnityEngineEvent:
        return UnityEngineEvent
