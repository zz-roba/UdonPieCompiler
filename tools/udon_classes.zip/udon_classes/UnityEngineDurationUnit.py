from typing import Any

from . UnityEngineDurationUnit import UnityEngineDurationUnit


class UnityEngineDurationUnit:

    def __new__(cls, input_1: Any) -> UnityEngineDurationUnit:
        return UnityEngineDurationUnit
