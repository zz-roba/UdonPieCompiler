from typing import Union
from typing import Any

from . UnityEngineAnimationCurve import UnityEngineAnimationCurve
from . UnityEngineWrapMode import UnityEngineWrapMode
from . UnityEngineObject import UnityEngineObject
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineBounds import UnityEngineBounds
from . SystemSingle import SystemSingle
from . SystemString import SystemString
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineVector3 import UnityEngineVector3
from . SystemInt32 import SystemInt32
from . SystemType import SystemType
from . UnityEngineAnimationClip import UnityEngineAnimationClip


class UnityEngineAnimationClip:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def ClearCurves() -> None:
        return 

    @staticmethod
    def EnsureQuaternionContinuity() -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def SampleAnimation(input_1: UnityEngineGameObject, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetCurve(input_1: Union[SystemString, str], input_2: SystemType, input_3: Union[SystemString, str], input_4: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_apparentSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_averageAngularSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_averageDuration() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_averageSpeed() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_empty() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_frameRate() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_hasGenericRootTransform() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasMotionCurves() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasMotionFloatCurves() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasRootCurves() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_humanMotion() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isHumanMotion() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isLooping() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_length() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_localBounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_wrapMode() -> UnityEngineWrapMode:
        return UnityEngineWrapMode

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_frameRate(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_localBounds(input_1: UnityEngineBounds) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_wrapMode(input_1: UnityEngineWrapMode) -> None:
        return 
