from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemInt64 import SystemInt64
from . SystemObject import SystemObject
from . SystemInt32Array import SystemInt32Array
from . SystemInt32 import SystemInt32
from . SystemCollectionsIEnumerator import SystemCollectionsIEnumerator
from . UnityEngineAnimationsParentConstraint import UnityEngineAnimationsParentConstraint
from . SystemString import SystemString
from . SystemArray import SystemArray
from . SystemInt64Array import SystemInt64Array
from . SystemBoolean import SystemBoolean
from . UnityEngineAnimationsParentConstraintArray import UnityEngineAnimationsParentConstraintArray


class UnityEngineAnimationsParentConstraintArray:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationsParentConstraintArray:
        return UnityEngineAnimationsParentConstraintArray

    @staticmethod
    def Clone() -> SystemObject:
        return SystemObject

    @staticmethod
    def CopyTo(input_1: SystemArray, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CopyTo(input_1: SystemArray, input_2: SystemInt64) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Get(input_1: Union[SystemInt32, int]) -> UnityEngineAnimationsParentConstraint:
        return UnityEngineAnimationsParentConstraint

    @staticmethod
    def GetEnumerator() -> SystemCollectionsIEnumerator:
        return SystemCollectionsIEnumerator

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetLength(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetLongLength(input_1: Union[SystemInt32, int]) -> SystemInt64:
        return SystemInt64

    @staticmethod
    def GetLowerBound(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetUpperBound(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetValue(input_1: SystemInt32Array) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: Union[SystemInt32, int]) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: SystemInt64) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: SystemInt64, input_2: SystemInt64) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: SystemInt64, input_2: SystemInt64, input_3: SystemInt64) -> SystemObject:
        return SystemObject

    @staticmethod
    def GetValue(input_1: SystemInt64Array) -> SystemObject:
        return SystemObject

    @staticmethod
    def Initialize() -> None:
        return 

    @staticmethod
    def Set(input_1: Union[SystemInt32, int], input_2: UnityEngineAnimationsParentConstraint) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: SystemInt32Array) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: SystemInt64) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: SystemInt64, input_3: SystemInt64) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: SystemInt64, input_3: SystemInt64, input_4: SystemInt64) -> None:
        return 

    @staticmethod
    def SetValue(input_1: SystemObject, input_2: SystemInt64Array) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int]) -> UnityEngineAnimationsParentConstraintArray:
        return UnityEngineAnimationsParentConstraintArray

    @staticmethod
    def get_IsFixedSize() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_IsReadOnly() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_IsSynchronized() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_Length() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_LongLength() -> SystemInt64:
        return SystemInt64

    @staticmethod
    def get_Rank() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_SyncRoot() -> SystemObject:
        return SystemObject
