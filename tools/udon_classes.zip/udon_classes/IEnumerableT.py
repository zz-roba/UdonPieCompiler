from typing import Any

from . IEnumerableT import IEnumerableT


class IEnumerableT:

    def __new__(cls, input_1: Any) -> IEnumerableT:
        return IEnumerableT
