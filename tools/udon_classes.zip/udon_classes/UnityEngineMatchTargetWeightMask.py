from typing import Union
from typing import Any

from . UnityEngineMatchTargetWeightMask import UnityEngineMatchTargetWeightMask
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class UnityEngineMatchTargetWeightMask:

    def __new__(cls, input_1: Any) -> UnityEngineMatchTargetWeightMask:
        return UnityEngineMatchTargetWeightMask

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float]) -> UnityEngineMatchTargetWeightMask:
        return UnityEngineMatchTargetWeightMask

    @staticmethod
    def get_positionXYZWeight() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_rotationWeight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_positionXYZWeight(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_rotationWeight(input_1: Union[SystemSingle, int, float]) -> None:
        return 
