from typing import Any

from . SystemUInt16Ref import SystemUInt16Ref


class SystemUInt16Ref:

    def __new__(cls, input_1: Any) -> SystemUInt16Ref:
        return SystemUInt16Ref
