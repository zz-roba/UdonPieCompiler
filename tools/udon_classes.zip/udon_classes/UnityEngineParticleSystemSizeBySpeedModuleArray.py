from typing import Any

from . UnityEngineParticleSystemSizeBySpeedModuleArray import UnityEngineParticleSystemSizeBySpeedModuleArray


class UnityEngineParticleSystemSizeBySpeedModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSizeBySpeedModuleArray:
        return UnityEngineParticleSystemSizeBySpeedModuleArray
