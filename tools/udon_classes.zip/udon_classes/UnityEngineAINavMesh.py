from typing import Union
from typing import Any

from . UnityEngineAINavMeshBuildSettings import UnityEngineAINavMeshBuildSettings
from . UnityEngineAINavMeshDataInstance import UnityEngineAINavMeshDataInstance
from . UnityEngineAINavMeshQueryFilter import UnityEngineAINavMeshQueryFilter
from . UnityEngineAINavMeshTriangulation import UnityEngineAINavMeshTriangulation
from . UnityEngineAINavMesh import UnityEngineAINavMesh
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineAINavMeshOnNavMeshPreUpdate import UnityEngineAINavMeshOnNavMeshPreUpdate
from . UnityEngineAINavMeshLinkInstance import UnityEngineAINavMeshLinkInstance
from . UnityEngineAINavMeshPath import UnityEngineAINavMeshPath
from . SystemString import SystemString
from . UnityEngineAINavMeshLinkData import UnityEngineAINavMeshLinkData
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineAINavMeshData import UnityEngineAINavMeshData
from . SystemType import SystemType
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemSingle import SystemSingle
from . SystemInt32 import SystemInt32
from . UnityEngineAINavMeshHitRef import UnityEngineAINavMeshHitRef


class UnityEngineAINavMesh:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMesh:
        return UnityEngineAINavMesh

    @staticmethod
    def AddLink(input_0: UnityEngineAINavMeshLinkData) -> UnityEngineAINavMeshLinkInstance:
        return UnityEngineAINavMeshLinkInstance

    @staticmethod
    def AddLink(input_0: UnityEngineAINavMeshLinkData, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion) -> UnityEngineAINavMeshLinkInstance:
        return UnityEngineAINavMeshLinkInstance

    @staticmethod
    def AddNavMeshData(input_0: UnityEngineAINavMeshData) -> UnityEngineAINavMeshDataInstance:
        return UnityEngineAINavMeshDataInstance

    @staticmethod
    def AddNavMeshData(input_0: UnityEngineAINavMeshData, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion) -> UnityEngineAINavMeshDataInstance:
        return UnityEngineAINavMeshDataInstance

    @staticmethod
    def CalculatePath(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemInt32, int], input_3: UnityEngineAINavMeshPath) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CalculatePath(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineAINavMeshQueryFilter, input_3: UnityEngineAINavMeshPath) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CalculateTriangulation() -> UnityEngineAINavMeshTriangulation:
        return UnityEngineAINavMeshTriangulation

    @staticmethod
    def CreateSettings() -> UnityEngineAINavMeshBuildSettings:
        return UnityEngineAINavMeshBuildSettings

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FindClosestEdge(input_0: UnityEngineVector3, input_1: UnityEngineAINavMeshHitRef, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FindClosestEdge(input_0: UnityEngineVector3, input_1: UnityEngineAINavMeshHitRef, input_2: UnityEngineAINavMeshQueryFilter) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAreaCost(input_0: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetAreaFromName(input_0: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetSettingsByID(input_0: Union[SystemInt32, int]) -> UnityEngineAINavMeshBuildSettings:
        return UnityEngineAINavMeshBuildSettings

    @staticmethod
    def GetSettingsByIndex(input_0: Union[SystemInt32, int]) -> UnityEngineAINavMeshBuildSettings:
        return UnityEngineAINavMeshBuildSettings

    @staticmethod
    def GetSettingsCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetSettingsNameFromID(input_0: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineAINavMeshHitRef, input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineAINavMeshHitRef, input_3: UnityEngineAINavMeshQueryFilter) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RemoveAllNavMeshData() -> None:
        return 

    @staticmethod
    def RemoveLink(input_0: UnityEngineAINavMeshLinkInstance) -> None:
        return 

    @staticmethod
    def RemoveNavMeshData(input_0: UnityEngineAINavMeshDataInstance) -> None:
        return 

    @staticmethod
    def RemoveSettings(input_0: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SamplePosition(input_0: UnityEngineVector3, input_1: UnityEngineAINavMeshHitRef, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SamplePosition(input_0: UnityEngineVector3, input_1: UnityEngineAINavMeshHitRef, input_2: Union[SystemSingle, int, float], input_3: UnityEngineAINavMeshQueryFilter) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetAreaCost(input_0: Union[SystemInt32, int], input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_AllAreas() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_avoidancePredictionTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_onPreUpdate() -> UnityEngineAINavMeshOnNavMeshPreUpdate:
        return UnityEngineAINavMeshOnNavMeshPreUpdate

    @staticmethod
    def set_avoidancePredictionTime(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_onPreUpdate() -> UnityEngineAINavMeshOnNavMeshPreUpdate:
        return UnityEngineAINavMeshOnNavMeshPreUpdate
