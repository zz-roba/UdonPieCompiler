from typing import Any

from . UnityEngineParticleSystemOverlapAction import UnityEngineParticleSystemOverlapAction


class UnityEngineParticleSystemOverlapAction:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemOverlapAction:
        return UnityEngineParticleSystemOverlapAction
