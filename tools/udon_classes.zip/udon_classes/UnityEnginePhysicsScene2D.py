from typing import Any

from . UnityEnginePhysicsScene2D import UnityEnginePhysicsScene2D


class UnityEnginePhysicsScene2D:

    def __new__(cls, input_1: Any) -> UnityEnginePhysicsScene2D:
        return UnityEnginePhysicsScene2D
