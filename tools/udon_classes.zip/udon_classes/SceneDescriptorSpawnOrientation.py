from typing import Any

from . SceneDescriptorSpawnOrientation import SceneDescriptorSpawnOrientation


class SceneDescriptorSpawnOrientation:

    def __new__(cls, input_1: Any) -> SceneDescriptorSpawnOrientation:
        return SceneDescriptorSpawnOrientation
