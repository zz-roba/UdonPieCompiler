from typing import Any

from . UnityEngineAINavMeshLinkData import UnityEngineAINavMeshLinkData


class UnityEngineAINavMeshLinkData:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshLinkData:
        return UnityEngineAINavMeshLinkData
