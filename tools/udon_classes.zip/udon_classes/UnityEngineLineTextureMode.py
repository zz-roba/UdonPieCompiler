from typing import Any

from . UnityEngineLineTextureMode import UnityEngineLineTextureMode


class UnityEngineLineTextureMode:

    def __new__(cls, input_1: Any) -> UnityEngineLineTextureMode:
        return UnityEngineLineTextureMode
