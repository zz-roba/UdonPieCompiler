from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemStringArray import SystemStringArray
from . UnityEngineVector4 import UnityEngineVector4
from . SystemCollectionsGenericListSystemSingle import SystemCollectionsGenericListSystemSingle
from . SystemCollectionsGenericListSystemString import SystemCollectionsGenericListSystemString
from . UnityEngineMaterial import UnityEngineMaterial
from . UnityEngineColor import UnityEngineColor
from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4
from . SystemInt32 import SystemInt32
from . UnityEngineVector4Array import UnityEngineVector4Array
from . UnityEngineMatrix4x4Array import UnityEngineMatrix4x4Array
from . UnityEngineShader import UnityEngineShader
from . SystemBoolean import SystemBoolean
from . UnityEngineComputeBuffer import UnityEngineComputeBuffer
from . UnityEngineMaterialGlobalIlluminationFlags import UnityEngineMaterialGlobalIlluminationFlags
from . UnityEngineTexture import UnityEngineTexture
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . UnityEngineColorArray import UnityEngineColorArray
from . SystemInt32Array import SystemInt32Array
from . SystemSingleArray import SystemSingleArray
from . SystemString import SystemString
from . SystemCollectionsGenericListUnityEngineColor import SystemCollectionsGenericListUnityEngineColor
from . SystemCollectionsGenericListSystemInt32 import SystemCollectionsGenericListSystemInt32
from . SystemCollectionsGenericListUnityEngineMatrix4x4 import SystemCollectionsGenericListUnityEngineMatrix4x4
from . UnityEngineMatrix4x4 import UnityEngineMatrix4x4


class UnityEngineMaterial:

    def __new__(cls, input_1: Any) -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def CopyPropertiesFromMaterial(input_1: UnityEngineMaterial) -> None:
        return 

    @staticmethod
    def DisableKeyword(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def EnableKeyword(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FindPass(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetColor(input_1: Union[SystemString, str]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetColor(input_1: Union[SystemInt32, int]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetColorArray(input_1: Union[SystemString, str]) -> UnityEngineColorArray:
        return UnityEngineColorArray

    @staticmethod
    def GetColorArray(input_1: Union[SystemInt32, int]) -> UnityEngineColorArray:
        return UnityEngineColorArray

    @staticmethod
    def GetColorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def GetColorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def GetFloat(input_1: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetFloat(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetFloatArray(input_1: Union[SystemString, str]) -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def GetFloatArray(input_1: Union[SystemInt32, int]) -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def GetFloatArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def GetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInt(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInt(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMatrix(input_1: Union[SystemString, str]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetMatrix(input_1: Union[SystemInt32, int]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemString, str]) -> UnityEngineMatrix4x4Array:
        return UnityEngineMatrix4x4Array

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemInt32, int]) -> UnityEngineMatrix4x4Array:
        return UnityEngineMatrix4x4Array

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def GetPassName(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetShaderPassEnabled(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetTag(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool], input_3: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetTag(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetTexture(input_1: Union[SystemString, str]) -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def GetTexture(input_1: Union[SystemInt32, int]) -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def GetTextureOffset(input_1: Union[SystemString, str]) -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def GetTextureOffset(input_1: Union[SystemInt32, int]) -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def GetTexturePropertyNameIDs() -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def GetTexturePropertyNameIDs(input_1: SystemCollectionsGenericListSystemInt32) -> None:
        return 

    @staticmethod
    def GetTexturePropertyNames() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetTexturePropertyNames(input_1: SystemCollectionsGenericListSystemString) -> None:
        return 

    @staticmethod
    def GetTextureScale(input_1: Union[SystemString, str]) -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def GetTextureScale(input_1: Union[SystemInt32, int]) -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetVector(input_1: Union[SystemString, str]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetVector(input_1: Union[SystemInt32, int]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetVectorArray(input_1: Union[SystemString, str]) -> UnityEngineVector4Array:
        return UnityEngineVector4Array

    @staticmethod
    def GetVectorArray(input_1: Union[SystemInt32, int]) -> UnityEngineVector4Array:
        return UnityEngineVector4Array

    @staticmethod
    def GetVectorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def GetVectorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def HasProperty(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def HasProperty(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsKeywordEnabled(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Lerp(input_1: UnityEngineMaterial, input_2: UnityEngineMaterial, input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetBuffer(input_1: Union[SystemString, str], input_2: UnityEngineComputeBuffer) -> None:
        return 

    @staticmethod
    def SetBuffer(input_1: Union[SystemInt32, int], input_2: UnityEngineComputeBuffer) -> None:
        return 

    @staticmethod
    def SetColor(input_1: Union[SystemString, str], input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColor(input_1: Union[SystemInt32, int], input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColorArray(input_1: Union[SystemString, str], input_2: UnityEngineColorArray) -> None:
        return 

    @staticmethod
    def SetColorArray(input_1: Union[SystemInt32, int], input_2: UnityEngineColorArray) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemString, str], input_2: SystemSingleArray) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemSingleArray) -> None:
        return 

    @staticmethod
    def SetInt(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetInt(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetMatrix(input_1: Union[SystemString, str], input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrix(input_1: Union[SystemInt32, int], input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemString, str], input_2: UnityEngineMatrix4x4Array) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemInt32, int], input_2: UnityEngineMatrix4x4Array) -> None:
        return 

    @staticmethod
    def SetOverrideTag(input_1: Union[SystemString, str], input_2: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def SetPass(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetShaderPassEnabled(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetTexture(input_1: Union[SystemString, str], input_2: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetTexture(input_1: Union[SystemInt32, int], input_2: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetTextureOffset(input_1: Union[SystemString, str], input_2: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def SetTextureOffset(input_1: Union[SystemInt32, int], input_2: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def SetTextureScale(input_1: Union[SystemString, str], input_2: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def SetTextureScale(input_1: Union[SystemInt32, int], input_2: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def SetVector(input_1: Union[SystemString, str], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVector(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemString, str], input_2: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_color() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_doubleSidedGI() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enableInstancing() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_globalIlluminationFlags() -> UnityEngineMaterialGlobalIlluminationFlags:
        return UnityEngineMaterialGlobalIlluminationFlags

    @staticmethod
    def get_mainTexture() -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def get_mainTextureOffset() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_mainTextureScale() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_passCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_renderQueue() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_shader() -> UnityEngineShader:
        return UnityEngineShader

    @staticmethod
    def get_shaderKeywords() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_color(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_doubleSidedGI(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enableInstancing(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_globalIlluminationFlags(input_1: UnityEngineMaterialGlobalIlluminationFlags) -> None:
        return 

    @staticmethod
    def set_mainTexture(input_1: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def set_mainTextureOffset(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_mainTextureScale(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_renderQueue(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_shader(input_1: UnityEngineShader) -> None:
        return 

    @staticmethod
    def set_shaderKeywords(input_1: SystemStringArray) -> None:
        return 
