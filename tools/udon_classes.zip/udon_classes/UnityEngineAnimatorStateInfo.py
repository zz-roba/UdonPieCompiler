from typing import Union
from typing import Any

from . UnityEngineAnimatorStateInfo import UnityEngineAnimatorStateInfo
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . SystemSingle import SystemSingle
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class UnityEngineAnimatorStateInfo:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorStateInfo:
        return UnityEngineAnimatorStateInfo

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsName(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTag(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_fullPathHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_length() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_loop() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_normalizedTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shortNameHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_speed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_speedMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_tagHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]
