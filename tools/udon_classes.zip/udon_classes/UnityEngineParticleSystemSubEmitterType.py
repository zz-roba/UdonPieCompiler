from typing import Any

from . UnityEngineParticleSystemSubEmitterType import UnityEngineParticleSystemSubEmitterType


class UnityEngineParticleSystemSubEmitterType:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSubEmitterType:
        return UnityEngineParticleSystemSubEmitterType
