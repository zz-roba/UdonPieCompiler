from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineAINavMeshData import UnityEngineAINavMeshData
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . UnityEngineBounds import UnityEngineBounds
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemBoolean import SystemBoolean


class UnityEngineAINavMeshData:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshData:
        return UnityEngineAINavMeshData

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_position() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_rotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_sourceBounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_position(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_rotation(input_1: UnityEngineQuaternion) -> None:
        return 
