from typing import Union
from typing import Any

from . UnityEngineParticleSystemTrailModule import UnityEngineParticleSystemTrailModule
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient
from . UnityEngineParticleSystemTrailTextureMode import UnityEngineParticleSystemTrailTextureMode
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemString import SystemString
from . UnityEngineParticleSystemTrailMode import UnityEngineParticleSystemTrailMode
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemTrailModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemTrailModule:
        return UnityEngineParticleSystemTrailModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_attachRibbonsToTransform() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_colorOverLifetime() -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_colorOverTrail() -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_dieWithParticles() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_generateLightingData() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_inheritParticleColor() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lifetime() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_lifetimeMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_minVertexDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemTrailMode:
        return UnityEngineParticleSystemTrailMode

    @staticmethod
    def get_ratio() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_ribbonCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_shadowBias() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_sizeAffectsLifetime() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_sizeAffectsWidth() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_splitSubEmitterRibbons() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_textureMode() -> UnityEngineParticleSystemTrailTextureMode:
        return UnityEngineParticleSystemTrailTextureMode

    @staticmethod
    def get_widthOverTrail() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_widthOverTrailMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_worldSpace() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_attachRibbonsToTransform(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_colorOverLifetime(input_1: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def set_colorOverTrail(input_1: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def set_dieWithParticles(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_generateLightingData(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_inheritParticleColor(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_lifetime(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_lifetimeMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_minVertexDistance(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemTrailMode) -> None:
        return 

    @staticmethod
    def set_ratio(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_ribbonCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_shadowBias(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_sizeAffectsLifetime(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_sizeAffectsWidth(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_splitSubEmitterRibbons(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_textureMode(input_1: UnityEngineParticleSystemTrailTextureMode) -> None:
        return 

    @staticmethod
    def set_widthOverTrail(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_widthOverTrailMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_worldSpace(input_1: Union[SystemBoolean, bool]) -> None:
        return 
