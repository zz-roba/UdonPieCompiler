from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineHumanLimit import UnityEngineHumanLimit
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineHumanLimit:

    def __new__(cls, input_1: Any) -> UnityEngineHumanLimit:
        return UnityEngineHumanLimit

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_axisLength() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_center() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_max() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_min() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_useDefaultValues() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_axisLength(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_center(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_max(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_min(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_useDefaultValues(input_1: Union[SystemBoolean, bool]) -> None:
        return 
