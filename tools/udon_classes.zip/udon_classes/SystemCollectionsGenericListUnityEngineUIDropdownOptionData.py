from typing import Any

from . SystemCollectionsGenericListUnityEngineUIDropdownOptionData import SystemCollectionsGenericListUnityEngineUIDropdownOptionData


class SystemCollectionsGenericListUnityEngineUIDropdownOptionData:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineUIDropdownOptionData:
        return SystemCollectionsGenericListUnityEngineUIDropdownOptionData
