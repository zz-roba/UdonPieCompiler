from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineAnimationClip import UnityEngineAnimationClip
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . UnityEngineAnimatorClipInfo import UnityEngineAnimatorClipInfo
from . SystemBoolean import SystemBoolean


class UnityEngineAnimatorClipInfo:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorClipInfo:
        return UnityEngineAnimatorClipInfo

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_clip() -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def get_weight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]
