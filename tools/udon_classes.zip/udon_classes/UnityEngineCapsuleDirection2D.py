from typing import Any

from . UnityEngineCapsuleDirection2D import UnityEngineCapsuleDirection2D


class UnityEngineCapsuleDirection2D:

    def __new__(cls, input_1: Any) -> UnityEngineCapsuleDirection2D:
        return UnityEngineCapsuleDirection2D
