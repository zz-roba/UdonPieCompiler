from typing import Any

from . ListT import ListT


class ListT:

    def __new__(cls, input_1: Any) -> ListT:
        return ListT
