from typing import Any

from . SystemGlobalizationCalendar import SystemGlobalizationCalendar


class SystemGlobalizationCalendar:

    def __new__(cls, input_1: Any) -> SystemGlobalizationCalendar:
        return SystemGlobalizationCalendar
