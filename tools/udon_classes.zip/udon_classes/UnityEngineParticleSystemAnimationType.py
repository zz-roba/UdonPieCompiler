from typing import Any

from . UnityEngineParticleSystemAnimationType import UnityEngineParticleSystemAnimationType


class UnityEngineParticleSystemAnimationType:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemAnimationType:
        return UnityEngineParticleSystemAnimationType
