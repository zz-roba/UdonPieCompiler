from typing import Any

from . SystemGlobalizationCompareOptions import SystemGlobalizationCompareOptions


class SystemGlobalizationCompareOptions:

    def __new__(cls, input_1: Any) -> SystemGlobalizationCompareOptions:
        return SystemGlobalizationCompareOptions
