from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemTriggerModule import UnityEngineParticleSystemTriggerModule
from . SystemString import SystemString
from . UnityEngineParticleSystemOverlapAction import UnityEngineParticleSystemOverlapAction
from . UnityEngineComponent import UnityEngineComponent
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemTriggerModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemTriggerModule:
        return UnityEngineParticleSystemTriggerModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetCollider(input_1: Union[SystemInt32, int]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def SetCollider(input_1: Union[SystemInt32, int], input_2: UnityEngineComponent) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enter() -> UnityEngineParticleSystemOverlapAction:
        return UnityEngineParticleSystemOverlapAction

    @staticmethod
    def get_exit() -> UnityEngineParticleSystemOverlapAction:
        return UnityEngineParticleSystemOverlapAction

    @staticmethod
    def get_inside() -> UnityEngineParticleSystemOverlapAction:
        return UnityEngineParticleSystemOverlapAction

    @staticmethod
    def get_maxColliderCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_outside() -> UnityEngineParticleSystemOverlapAction:
        return UnityEngineParticleSystemOverlapAction

    @staticmethod
    def get_radiusScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enter(input_1: UnityEngineParticleSystemOverlapAction) -> None:
        return 

    @staticmethod
    def set_exit(input_1: UnityEngineParticleSystemOverlapAction) -> None:
        return 

    @staticmethod
    def set_inside(input_1: UnityEngineParticleSystemOverlapAction) -> None:
        return 

    @staticmethod
    def set_outside(input_1: UnityEngineParticleSystemOverlapAction) -> None:
        return 

    @staticmethod
    def set_radiusScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 
