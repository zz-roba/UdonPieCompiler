from typing import Any

from . UnityEngineParticleSystemMainModuleArray import UnityEngineParticleSystemMainModuleArray


class UnityEngineParticleSystemMainModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMainModuleArray:
        return UnityEngineParticleSystemMainModuleArray
