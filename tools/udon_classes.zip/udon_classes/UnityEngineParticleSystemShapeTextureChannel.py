from typing import Any

from . UnityEngineParticleSystemShapeTextureChannel import UnityEngineParticleSystemShapeTextureChannel


class UnityEngineParticleSystemShapeTextureChannel:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemShapeTextureChannel:
        return UnityEngineParticleSystemShapeTextureChannel
