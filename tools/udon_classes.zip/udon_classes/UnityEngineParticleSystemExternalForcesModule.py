from typing import Any

from . UnityEngineParticleSystemExternalForcesModule import UnityEngineParticleSystemExternalForcesModule


class UnityEngineParticleSystemExternalForcesModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemExternalForcesModule:
        return UnityEngineParticleSystemExternalForcesModule
