from typing import Any

from . UnityEnginePlayablesPlayableGraph import UnityEnginePlayablesPlayableGraph


class UnityEnginePlayablesPlayableGraph:

    def __new__(cls, input_1: Any) -> UnityEnginePlayablesPlayableGraph:
        return UnityEnginePlayablesPlayableGraph
