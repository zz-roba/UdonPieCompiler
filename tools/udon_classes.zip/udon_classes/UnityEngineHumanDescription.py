from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineHumanBoneArray import UnityEngineHumanBoneArray
from . UnityEngineHumanDescription import UnityEngineHumanDescription
from . SystemString import SystemString
from . UnityEngineSkeletonBoneArray import UnityEngineSkeletonBoneArray
from . SystemBoolean import SystemBoolean


class UnityEngineHumanDescription:

    def __new__(cls, input_1: Any) -> UnityEngineHumanDescription:
        return UnityEngineHumanDescription

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_armStretch() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_feetSpacing() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_hasTranslationDoF() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_human() -> UnityEngineHumanBoneArray:
        return UnityEngineHumanBoneArray

    @staticmethod
    def get_legStretch() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_lowerArmTwist() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_lowerLegTwist() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_skeleton() -> UnityEngineSkeletonBoneArray:
        return UnityEngineSkeletonBoneArray

    @staticmethod
    def get_upperArmTwist() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_upperLegTwist() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_armStretch(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_feetSpacing(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_hasTranslationDoF(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_human() -> UnityEngineHumanBoneArray:
        return UnityEngineHumanBoneArray

    @staticmethod
    def set_legStretch(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_lowerArmTwist(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_lowerLegTwist(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_skeleton() -> UnityEngineSkeletonBoneArray:
        return UnityEngineSkeletonBoneArray

    @staticmethod
    def set_upperArmTwist(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_upperLegTwist(input_1: Union[SystemSingle, int, float]) -> None:
        return 
