from typing import Any

from . SystemArray import SystemArray


class SystemArray:

    def __new__(cls, input_1: Any) -> SystemArray:
        return SystemArray
