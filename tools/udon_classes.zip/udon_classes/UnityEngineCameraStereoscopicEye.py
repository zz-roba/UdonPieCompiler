from typing import Any

from . UnityEngineCameraStereoscopicEye import UnityEngineCameraStereoscopicEye


class UnityEngineCameraStereoscopicEye:

    def __new__(cls, input_1: Any) -> UnityEngineCameraStereoscopicEye:
        return UnityEngineCameraStereoscopicEye
