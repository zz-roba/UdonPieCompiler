from typing import Any

from . UnityEngineAINavMeshTriangulation import UnityEngineAINavMeshTriangulation


class UnityEngineAINavMeshTriangulation:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshTriangulation:
        return UnityEngineAINavMeshTriangulation
