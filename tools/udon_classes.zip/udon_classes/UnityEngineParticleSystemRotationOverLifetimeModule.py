from typing import Any

from . UnityEngineParticleSystemRotationOverLifetimeModule import UnityEngineParticleSystemRotationOverLifetimeModule


class UnityEngineParticleSystemRotationOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemRotationOverLifetimeModule:
        return UnityEngineParticleSystemRotationOverLifetimeModule
