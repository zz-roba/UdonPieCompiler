from typing import Any

from . UnityEnginePlayMode import UnityEnginePlayMode


class UnityEnginePlayMode:

    def __new__(cls, input_1: Any) -> UnityEnginePlayMode:
        return UnityEnginePlayMode
