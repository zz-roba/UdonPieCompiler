from typing import Any

from . UnityEngineParticleSystemCustomDataModule import UnityEngineParticleSystemCustomDataModule


class UnityEngineParticleSystemCustomDataModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCustomDataModule:
        return UnityEngineParticleSystemCustomDataModule
