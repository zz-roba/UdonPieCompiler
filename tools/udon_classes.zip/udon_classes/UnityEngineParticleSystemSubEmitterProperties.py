from typing import Any

from . UnityEngineParticleSystemSubEmitterProperties import UnityEngineParticleSystemSubEmitterProperties


class UnityEngineParticleSystemSubEmitterProperties:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSubEmitterProperties:
        return UnityEngineParticleSystemSubEmitterProperties
