from typing import Any

from . UnityEngineAINavMeshDataInstance import UnityEngineAINavMeshDataInstance


class UnityEngineAINavMeshDataInstance:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshDataInstance:
        return UnityEngineAINavMeshDataInstance
