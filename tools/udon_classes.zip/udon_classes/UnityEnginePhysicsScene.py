from typing import Any

from . UnityEnginePhysicsScene import UnityEnginePhysicsScene


class UnityEnginePhysicsScene:

    def __new__(cls, input_1: Any) -> UnityEnginePhysicsScene:
        return UnityEnginePhysicsScene
