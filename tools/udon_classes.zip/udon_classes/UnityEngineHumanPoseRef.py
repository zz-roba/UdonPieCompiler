from typing import Any

from . UnityEngineHumanPoseRef import UnityEngineHumanPoseRef


class UnityEngineHumanPoseRef:

    def __new__(cls, input_1: Any) -> UnityEngineHumanPoseRef:
        return UnityEngineHumanPoseRef
