from typing import Any

from . UnityEngineParticleSystemCollisionType import UnityEngineParticleSystemCollisionType


class UnityEngineParticleSystemCollisionType:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCollisionType:
        return UnityEngineParticleSystemCollisionType
