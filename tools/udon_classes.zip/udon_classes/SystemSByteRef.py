from typing import Any

from . SystemSByteRef import SystemSByteRef


class SystemSByteRef:

    def __new__(cls, input_1: Any) -> SystemSByteRef:
        return SystemSByteRef
