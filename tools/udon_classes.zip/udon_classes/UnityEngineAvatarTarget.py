from typing import Any

from . UnityEngineAvatarTarget import UnityEngineAvatarTarget


class UnityEngineAvatarTarget:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarTarget:
        return UnityEngineAvatarTarget
