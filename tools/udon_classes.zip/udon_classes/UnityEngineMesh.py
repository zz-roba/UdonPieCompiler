from typing import Union
from typing import Any

from . UnityEngineBounds import UnityEngineBounds
from . SystemCollectionsGenericListUnityEngineBoneWeight import SystemCollectionsGenericListUnityEngineBoneWeight
from . SystemCollectionsGenericListUnityEngineMatrix4x4 import SystemCollectionsGenericListUnityEngineMatrix4x4
from . UnityEngineVector2Array import UnityEngineVector2Array
from . SystemBoolean import SystemBoolean
from . SystemCollectionsGenericListSystemInt32 import SystemCollectionsGenericListSystemInt32
from . UnityEngineRenderingIndexFormat import UnityEngineRenderingIndexFormat
from . SystemUInt32 import SystemUInt32
from . SystemInt32 import SystemInt32
from . UnityEngineBoneWeightArray import UnityEngineBoneWeightArray
from . SystemCollectionsGenericListUnityEngineColor32 import SystemCollectionsGenericListUnityEngineColor32
from . UnityEngineMesh import UnityEngineMesh
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4
from . SystemInt32Array import SystemInt32Array
from . UnityEngineVector4Array import UnityEngineVector4Array
from . SystemCollectionsGenericListUnityEngineVector3 import SystemCollectionsGenericListUnityEngineVector3
from . UnityEngineVector3Array import UnityEngineVector3Array
from . UnityEngineMatrix4x4Array import UnityEngineMatrix4x4Array
from . SystemSingle import SystemSingle
from . UnityEngineColorArray import UnityEngineColorArray
from . SystemCollectionsGenericListUnityEngineVector2 import SystemCollectionsGenericListUnityEngineVector2
from . SystemString import SystemString
from . UnityEngineColor32Array import UnityEngineColor32Array
from . SystemCollectionsGenericListUnityEngineColor import SystemCollectionsGenericListUnityEngineColor
from . SystemType import SystemType
from . UnityEngineCombineInstanceArray import UnityEngineCombineInstanceArray
from . UnityEngineMeshTopology import UnityEngineMeshTopology


class UnityEngineMesh:

    def __new__(cls, input_1: Any) -> UnityEngineMesh:
        return UnityEngineMesh

    @staticmethod
    def AddBlendShapeFrame(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3Array, input_4: UnityEngineVector3Array, input_5: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def Clear(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Clear() -> None:
        return 

    @staticmethod
    def ClearBlendShapes() -> None:
        return 

    @staticmethod
    def CombineMeshes(input_1: UnityEngineCombineInstanceArray, input_2: Union[SystemBoolean, bool], input_3: Union[SystemBoolean, bool], input_4: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def CombineMeshes(input_1: UnityEngineCombineInstanceArray, input_2: Union[SystemBoolean, bool], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def CombineMeshes(input_1: UnityEngineCombineInstanceArray, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def CombineMeshes(input_1: UnityEngineCombineInstanceArray) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetBaseVertex(input_1: Union[SystemInt32, int]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def GetBindposes(input_1: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def GetBlendShapeFrameCount(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetBlendShapeFrameVertices(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: UnityEngineVector3Array, input_4: UnityEngineVector3Array, input_5: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def GetBlendShapeFrameWeight(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetBlendShapeIndex(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetBlendShapeName(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetBoneWeights(input_1: SystemCollectionsGenericListUnityEngineBoneWeight) -> None:
        return 

    @staticmethod
    def GetColors(input_1: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def GetColors(input_1: SystemCollectionsGenericListUnityEngineColor32) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetIndexCount(input_1: Union[SystemInt32, int]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def GetIndexStart(input_1: Union[SystemInt32, int]) -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def GetIndices(input_1: Union[SystemInt32, int]) -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def GetIndices(input_1: Union[SystemInt32, int], input_2: Union[SystemBoolean, bool]) -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def GetIndices(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def GetIndices(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetNormals(input_1: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def GetTangents(input_1: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def GetTopology(input_1: Union[SystemInt32, int]) -> UnityEngineMeshTopology:
        return UnityEngineMeshTopology

    @staticmethod
    def GetTriangles(input_1: Union[SystemInt32, int]) -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def GetTriangles(input_1: Union[SystemInt32, int], input_2: Union[SystemBoolean, bool]) -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def GetTriangles(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def GetTriangles(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetUVDistributionMetric(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector2) -> None:
        return 

    @staticmethod
    def GetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def GetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def GetVertices(input_1: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def MarkDynamic() -> None:
        return 

    @staticmethod
    def RecalculateBounds() -> None:
        return 

    @staticmethod
    def RecalculateNormals() -> None:
        return 

    @staticmethod
    def RecalculateTangents() -> None:
        return 

    @staticmethod
    def SetColors(input_1: SystemCollectionsGenericListUnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColors(input_1: SystemCollectionsGenericListUnityEngineColor32) -> None:
        return 

    @staticmethod
    def SetIndices(input_1: SystemInt32Array, input_2: UnityEngineMeshTopology, input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetIndices(input_1: SystemInt32Array, input_2: UnityEngineMeshTopology, input_3: Union[SystemInt32, int], input_4: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetIndices(input_1: SystemInt32Array, input_2: UnityEngineMeshTopology, input_3: Union[SystemInt32, int], input_4: Union[SystemBoolean, bool], input_5: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetNormals(input_1: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetTangents(input_1: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemInt32Array, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemInt32Array, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemInt32Array, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetTriangles(input_1: SystemCollectionsGenericListSystemInt32, input_2: Union[SystemInt32, int], input_3: Union[SystemBoolean, bool], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector2) -> None:
        return 

    @staticmethod
    def SetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetUVs(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVertices(input_1: SystemCollectionsGenericListUnityEngineVector3) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def UploadMeshData(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def get_bindposes() -> UnityEngineMatrix4x4Array:
        return UnityEngineMatrix4x4Array

    @staticmethod
    def get_blendShapeCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_boneWeights() -> UnityEngineBoneWeightArray:
        return UnityEngineBoneWeightArray

    @staticmethod
    def get_bounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_colors() -> UnityEngineColorArray:
        return UnityEngineColorArray

    @staticmethod
    def get_colors32() -> UnityEngineColor32Array:
        return UnityEngineColor32Array

    @staticmethod
    def get_indexFormat() -> UnityEngineRenderingIndexFormat:
        return UnityEngineRenderingIndexFormat

    @staticmethod
    def get_isReadable() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_normals() -> UnityEngineVector3Array:
        return UnityEngineVector3Array

    @staticmethod
    def get_subMeshCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_tangents() -> UnityEngineVector4Array:
        return UnityEngineVector4Array

    @staticmethod
    def get_triangles() -> SystemInt32Array:
        return SystemInt32Array

    @staticmethod
    def get_uv() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv2() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv3() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv4() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv5() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv6() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv7() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_uv8() -> UnityEngineVector2Array:
        return UnityEngineVector2Array

    @staticmethod
    def get_vertexBufferCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_vertexCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_vertices() -> UnityEngineVector3Array:
        return UnityEngineVector3Array

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_bindposes(input_1: UnityEngineMatrix4x4Array) -> None:
        return 

    @staticmethod
    def set_boneWeights(input_1: UnityEngineBoneWeightArray) -> None:
        return 

    @staticmethod
    def set_bounds(input_1: UnityEngineBounds) -> None:
        return 

    @staticmethod
    def set_colors(input_1: UnityEngineColorArray) -> None:
        return 

    @staticmethod
    def set_colors32(input_1: UnityEngineColor32Array) -> None:
        return 

    @staticmethod
    def set_indexFormat(input_1: UnityEngineRenderingIndexFormat) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_normals(input_1: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def set_subMeshCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_tangents(input_1: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def set_triangles(input_1: SystemInt32Array) -> None:
        return 

    @staticmethod
    def set_uv(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv2(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv3(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv4(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv5(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv6(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv7(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_uv8(input_1: UnityEngineVector2Array) -> None:
        return 

    @staticmethod
    def set_vertices(input_1: UnityEngineVector3Array) -> None:
        return 
