from typing import Any

from . UnityEngineAnimationsAimConstraintWorldUpType import UnityEngineAnimationsAimConstraintWorldUpType


class UnityEngineAnimationsAimConstraintWorldUpType:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationsAimConstraintWorldUpType:
        return UnityEngineAnimationsAimConstraintWorldUpType
