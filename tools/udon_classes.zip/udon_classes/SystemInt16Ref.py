from typing import Any

from . SystemInt16Ref import SystemInt16Ref


class SystemInt16Ref:

    def __new__(cls, input_1: Any) -> SystemInt16Ref:
        return SystemInt16Ref
