from typing import Any

from . SystemUInt64Ref import SystemUInt64Ref


class SystemUInt64Ref:

    def __new__(cls, input_1: Any) -> SystemUInt64Ref:
        return SystemUInt64Ref
