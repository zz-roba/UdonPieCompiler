from typing import Any

from . UnityEngineParticleSystemForceField import UnityEngineParticleSystemForceField


class UnityEngineParticleSystemForceField:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemForceField:
        return UnityEngineParticleSystemForceField
