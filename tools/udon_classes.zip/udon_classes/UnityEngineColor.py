from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineColor import UnityEngineColor
from . SystemSingleRef import SystemSingleRef
from . SystemInt32 import SystemInt32
from . UnityEngineVector4 import UnityEngineVector4
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineColor:

    def __new__(cls, input_1: Any) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: UnityEngineColor) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def HSVToRGB(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def HSVToRGB(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemBoolean, bool]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def Lerp(input_0: UnityEngineColor, input_1: UnityEngineColor, input_2: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def LerpUnclamped(input_0: UnityEngineColor, input_1: UnityEngineColor, input_2: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def RGBToHSV(input_0: UnityEngineColor, input_1: SystemSingleRef, input_2: SystemSingleRef, input_3: SystemSingleRef) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_Item(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_a() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_b() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_black() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_blue() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_clear() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_cyan() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_g() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_gamma() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_gray() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_grayscale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_green() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_grey() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_linear() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_magenta() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_maxColorComponent() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_r() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_red() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_white() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_yellow() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Addition(input_0: UnityEngineColor, input_1: UnityEngineColor) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Division(input_0: UnityEngineColor, input_1: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Equality(input_0: UnityEngineColor, input_1: UnityEngineColor) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineColor) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def op_Implicit(input_0: UnityEngineVector4) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Inequality(input_0: UnityEngineColor, input_1: UnityEngineColor) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Multiply(input_0: UnityEngineColor, input_1: UnityEngineColor) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Multiply(input_0: UnityEngineColor, input_1: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Multiply(input_0: Union[SystemSingle, int, float], input_1: UnityEngineColor) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def op_Subtraction(input_0: UnityEngineColor, input_1: UnityEngineColor) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def set_Item(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_a() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_b() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_g() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_r() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]
