from typing import Any

from . UnityEngineAIObstacleAvoidanceType import UnityEngineAIObstacleAvoidanceType


class UnityEngineAIObstacleAvoidanceType:

    def __new__(cls, input_1: Any) -> UnityEngineAIObstacleAvoidanceType:
        return UnityEngineAIObstacleAvoidanceType
