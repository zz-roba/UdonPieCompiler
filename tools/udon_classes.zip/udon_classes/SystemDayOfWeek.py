from typing import Any

from . SystemDayOfWeek import SystemDayOfWeek


class SystemDayOfWeek:

    def __new__(cls, input_1: Any) -> SystemDayOfWeek:
        return SystemDayOfWeek
