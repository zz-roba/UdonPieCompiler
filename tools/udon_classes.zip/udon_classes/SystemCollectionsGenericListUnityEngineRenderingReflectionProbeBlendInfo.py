from typing import Any

from . SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo import SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo


class SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo:
        return SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo
