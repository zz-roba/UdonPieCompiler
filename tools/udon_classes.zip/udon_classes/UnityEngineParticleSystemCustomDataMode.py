from typing import Any

from . UnityEngineParticleSystemCustomDataMode import UnityEngineParticleSystemCustomDataMode


class UnityEngineParticleSystemCustomDataMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCustomDataMode:
        return UnityEngineParticleSystemCustomDataMode
