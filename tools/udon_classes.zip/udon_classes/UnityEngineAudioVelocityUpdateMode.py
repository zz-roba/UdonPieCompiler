from typing import Any

from . UnityEngineAudioVelocityUpdateMode import UnityEngineAudioVelocityUpdateMode


class UnityEngineAudioVelocityUpdateMode:

    def __new__(cls, input_1: Any) -> UnityEngineAudioVelocityUpdateMode:
        return UnityEngineAudioVelocityUpdateMode
