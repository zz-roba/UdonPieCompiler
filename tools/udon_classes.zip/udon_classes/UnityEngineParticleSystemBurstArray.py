from typing import Any

from . UnityEngineParticleSystemBurstArray import UnityEngineParticleSystemBurstArray


class UnityEngineParticleSystemBurstArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemBurstArray:
        return UnityEngineParticleSystemBurstArray
