from typing import Any

from . UnityEngineParticleSystemExternalForcesModuleArray import UnityEngineParticleSystemExternalForcesModuleArray


class UnityEngineParticleSystemExternalForcesModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemExternalForcesModuleArray:
        return UnityEngineParticleSystemExternalForcesModuleArray
