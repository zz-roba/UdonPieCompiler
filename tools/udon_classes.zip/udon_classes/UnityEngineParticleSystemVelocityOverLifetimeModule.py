from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemString import SystemString
from . UnityEngineParticleSystemSimulationSpace import UnityEngineParticleSystemSimulationSpace
from . UnityEngineParticleSystemVelocityOverLifetimeModule import UnityEngineParticleSystemVelocityOverLifetimeModule
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemVelocityOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemVelocityOverLifetimeModule:
        return UnityEngineParticleSystemVelocityOverLifetimeModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_orbitalOffsetX() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalOffsetXMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_orbitalOffsetY() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalOffsetYMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_orbitalOffsetZ() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalOffsetZMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_orbitalX() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalXMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_orbitalY() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalYMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_orbitalZ() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_orbitalZMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_radial() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_radialMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_space() -> UnityEngineParticleSystemSimulationSpace:
        return UnityEngineParticleSystemSimulationSpace

    @staticmethod
    def get_speedModifier() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_speedModifierMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_x() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_xMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_y() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_yMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_z() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_zMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetX(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetXMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetY(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetYMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetZ(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalOffsetZMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_orbitalX(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalXMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_orbitalY(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalYMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_orbitalZ(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_orbitalZMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_radial(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_radialMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_space(input_1: UnityEngineParticleSystemSimulationSpace) -> None:
        return 

    @staticmethod
    def set_speedModifier(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_speedModifierMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_x(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_xMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_y(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_yMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_z(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_zMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 
