from typing import Any

from . SystemCollectionsIEnumerator import SystemCollectionsIEnumerator


class SystemCollectionsIEnumerator:

    def __new__(cls, input_1: Any) -> SystemCollectionsIEnumerator:
        return SystemCollectionsIEnumerator
