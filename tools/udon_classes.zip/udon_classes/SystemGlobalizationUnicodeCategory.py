from typing import Any

from . SystemGlobalizationUnicodeCategory import SystemGlobalizationUnicodeCategory


class SystemGlobalizationUnicodeCategory:

    def __new__(cls, input_1: Any) -> SystemGlobalizationUnicodeCategory:
        return SystemGlobalizationUnicodeCategory
