from typing import Any

from . UnityEngineLightBakingOutput import UnityEngineLightBakingOutput


class UnityEngineLightBakingOutput:

    def __new__(cls, input_1: Any) -> UnityEngineLightBakingOutput:
        return UnityEngineLightBakingOutput
