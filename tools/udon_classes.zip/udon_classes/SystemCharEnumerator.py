from typing import Any

from . SystemCharEnumerator import SystemCharEnumerator


class SystemCharEnumerator:

    def __new__(cls, input_1: Any) -> SystemCharEnumerator:
        return SystemCharEnumerator
