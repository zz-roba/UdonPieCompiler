from typing import Any

from . UnityEngineAINavMeshOnNavMeshPreUpdate import UnityEngineAINavMeshOnNavMeshPreUpdate


class UnityEngineAINavMeshOnNavMeshPreUpdate:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshOnNavMeshPreUpdate:
        return UnityEngineAINavMeshOnNavMeshPreUpdate
