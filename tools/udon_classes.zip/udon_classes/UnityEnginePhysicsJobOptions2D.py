from typing import Any

from . UnityEnginePhysicsJobOptions2D import UnityEnginePhysicsJobOptions2D


class UnityEnginePhysicsJobOptions2D:

    def __new__(cls, input_1: Any) -> UnityEnginePhysicsJobOptions2D:
        return UnityEnginePhysicsJobOptions2D
