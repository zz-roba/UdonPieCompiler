from typing import Union
from typing import Any

from . UnityEngineObject import UnityEngineObject
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineObject:

    def __new__(cls, input_1: Any) -> UnityEngineObject:
        return UnityEngineObject

    @staticmethod
    def Destroy(input_0: UnityEngineObject, input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Destroy(input_0: UnityEngineObject) -> None:
        return 

    @staticmethod
    def DestroyImmediate(input_0: UnityEngineObject, input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def DestroyImmediate(input_0: UnityEngineObject) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 
