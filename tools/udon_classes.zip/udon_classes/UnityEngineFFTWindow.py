from typing import Any

from . UnityEngineFFTWindow import UnityEngineFFTWindow


class UnityEngineFFTWindow:

    def __new__(cls, input_1: Any) -> UnityEngineFFTWindow:
        return UnityEngineFFTWindow
