from typing import Any

from . UnityEngineFogMode import UnityEngineFogMode


class UnityEngineFogMode:

    def __new__(cls, input_1: Any) -> UnityEngineFogMode:
        return UnityEngineFogMode
