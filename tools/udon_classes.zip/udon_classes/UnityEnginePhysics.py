from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEnginePhysicsScene import UnityEnginePhysicsScene
from . SystemSingle import SystemSingle
from . SystemSingleRef import SystemSingleRef
from . UnityEnginePhysics import UnityEnginePhysics
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineRaycastHitRef import UnityEngineRaycastHitRef
from . UnityEngineRaycastHitArray import UnityEngineRaycastHitArray
from . UnityEngineCollider import UnityEngineCollider
from . UnityEngineRay import UnityEngineRay
from . UnityEngineBounds import UnityEngineBounds
from . SystemString import SystemString
from . UnityEngineQueryTriggerInteraction import UnityEngineQueryTriggerInteraction
from . UnityEngineColliderArray import UnityEngineColliderArray
from . UnityEngineVector3Ref import UnityEngineVector3Ref
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemBoolean import SystemBoolean


class UnityEnginePhysics:

    def __new__(cls, input_1: Any) -> UnityEnginePhysics:
        return UnityEnginePhysics

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: UnityEngineQuaternion) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion, input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: UnityEngineQuaternion) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: UnityEngineQuaternion, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitRef, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitRef, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitRef, input_5: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitArray, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitArray, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitArray, input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector3, input_4: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CheckBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def CheckSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ClosestPoint(input_0: UnityEngineVector3, input_1: UnityEngineCollider, input_2: UnityEngineVector3, input_3: UnityEngineQuaternion) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def ComputePenetration(input_0: UnityEngineCollider, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: UnityEngineCollider, input_4: UnityEngineVector3, input_5: UnityEngineQuaternion, input_6: UnityEngineVector3Ref, input_7: SystemSingleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetIgnoreLayerCollision(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IgnoreCollision(input_0: UnityEngineCollider, input_1: UnityEngineCollider, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def IgnoreCollision(input_0: UnityEngineCollider, input_1: UnityEngineCollider) -> None:
        return 

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemInt32, int], input_3: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef, input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef, input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: Union[SystemInt32, int]) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineQuaternion) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColliderArray, input_3: UnityEngineQuaternion, input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColliderArray, input_3: UnityEngineQuaternion, input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColliderArray, input_3: UnityEngineQuaternion) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColliderArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float]) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineColliderArray, input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineColliderArray, input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: UnityEngineColliderArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: UnityEngineQueryTriggerInteraction) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapSphere(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float]) -> UnityEngineColliderArray:
        return UnityEngineColliderArray

    @staticmethod
    def OverlapSphereNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineColliderArray, input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapSphereNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineColliderArray, input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapSphereNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineColliderArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitRef, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitRef, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitRef, input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineRay) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitArray, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitArray, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitArray, input_2: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RebuildBroadphaseRegions(input_0: UnityEngineBounds, input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Simulate(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitRef, input_3: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef, input_4: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCast(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SphereCastAll(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: UnityEngineQueryTriggerInteraction) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> UnityEngineRaycastHitArray:
        return UnityEngineRaycastHitArray

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray, input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineVector3, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector3, input_3: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: UnityEngineQueryTriggerInteraction) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitArray, input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SphereCastNonAlloc(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: UnityEngineRaycastHitArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SyncTransforms() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_AllLayers() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_DefaultRaycastLayers() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_IgnoreRaycastLayer() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_defaultPhysicsScene() -> UnityEnginePhysicsScene:
        return UnityEnginePhysicsScene

    @staticmethod
    def get_gravity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_interCollisionDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_interCollisionSettingsToggle() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_interCollisionStiffness() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_reuseCollisionCallbacks() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_gravity(input_0: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_interCollisionDistance(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_interCollisionSettingsToggle(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_interCollisionStiffness(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_reuseCollisionCallbacks(input_0: Union[SystemBoolean, bool]) -> None:
        return 
