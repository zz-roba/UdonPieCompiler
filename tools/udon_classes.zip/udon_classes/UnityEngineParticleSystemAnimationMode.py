from typing import Any

from . UnityEngineParticleSystemAnimationMode import UnityEngineParticleSystemAnimationMode


class UnityEngineParticleSystemAnimationMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemAnimationMode:
        return UnityEngineParticleSystemAnimationMode
