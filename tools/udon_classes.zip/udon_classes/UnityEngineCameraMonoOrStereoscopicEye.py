from typing import Any

from . UnityEngineCameraMonoOrStereoscopicEye import UnityEngineCameraMonoOrStereoscopicEye


class UnityEngineCameraMonoOrStereoscopicEye:

    def __new__(cls, input_1: Any) -> UnityEngineCameraMonoOrStereoscopicEye:
        return UnityEngineCameraMonoOrStereoscopicEye
