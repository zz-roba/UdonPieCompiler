from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent


class SystemCollectionsGenericListUnityEngineComponent:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineComponent:
        return SystemCollectionsGenericListUnityEngineComponent
