from typing import Any

from . SystemGlobalizationDateTimeStyles import SystemGlobalizationDateTimeStyles


class SystemGlobalizationDateTimeStyles:

    def __new__(cls, input_1: Any) -> SystemGlobalizationDateTimeStyles:
        return SystemGlobalizationDateTimeStyles
