from typing import Any

from . UnityEngineParticleSystemNoiseModuleArray import UnityEngineParticleSystemNoiseModuleArray


class UnityEngineParticleSystemNoiseModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemNoiseModuleArray:
        return UnityEngineParticleSystemNoiseModuleArray
