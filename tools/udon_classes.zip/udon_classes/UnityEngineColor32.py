from typing import Any

from . UnityEngineColor32 import UnityEngineColor32


class UnityEngineColor32:

    def __new__(cls, input_1: Any) -> UnityEngineColor32:
        return UnityEngineColor32
