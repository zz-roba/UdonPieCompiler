from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemString import SystemString
from . UnityEngineAnimationCurve import UnityEngineAnimationCurve
from . UnityEngineParticleSystemCurveMode import UnityEngineParticleSystemCurveMode
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemMinMaxCurve:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Evaluate(input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Evaluate(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float]) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: UnityEngineAnimationCurve) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: UnityEngineAnimationCurve, input_2: UnityEngineAnimationCurve) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def ctor(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_constant() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_constantMax() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_constantMin() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_curve() -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve

    @staticmethod
    def get_curveMax() -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve

    @staticmethod
    def get_curveMin() -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve

    @staticmethod
    def get_curveMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemCurveMode:
        return UnityEngineParticleSystemCurveMode

    @staticmethod
    def op_Implicit(input_0: Union[SystemSingle, int, float]) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def set_constant(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_constantMax(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_constantMin(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_curve(input_1: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def set_curveMax(input_1: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def set_curveMin(input_1: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def set_curveMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemCurveMode) -> None:
        return 
