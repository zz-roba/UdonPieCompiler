from typing import Any

from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve


class UnityEngineParticleSystemMinMaxCurve:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve
