from typing import Union
from typing import Any

from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineHumanTrait import UnityEngineHumanTrait
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemInt32 import SystemInt32


class UnityEngineHumanTrait:

    def __new__(cls, input_1: Any) -> UnityEngineHumanTrait:
        return UnityEngineHumanTrait

    @staticmethod
    def BoneFromMuscle(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetBoneDefaultHierarchyMass(input_0: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMuscleDefaultMax(input_0: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetMuscleDefaultMin(input_0: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetParentBone(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def MuscleFromBone(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RequiredBone(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineHumanTrait:
        return UnityEngineHumanTrait

    @staticmethod
    def get_BoneCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_BoneName() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def get_MuscleCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_MuscleName() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def get_RequiredBoneCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]
