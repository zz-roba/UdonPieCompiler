from typing import Any

from . SystemTextEncoding import SystemTextEncoding


class SystemTextEncoding:

    def __new__(cls, input_1: Any) -> SystemTextEncoding:
        return SystemTextEncoding
