from typing import Any

from . UnityEngineParticleSystemMinMaxCurveArray import UnityEngineParticleSystemMinMaxCurveArray


class UnityEngineParticleSystemMinMaxCurveArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxCurveArray:
        return UnityEngineParticleSystemMinMaxCurveArray
