from typing import Union
from typing import Any

from . UnityEngineAvatar import UnityEngineAvatar
from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineAvatarBuilder import UnityEngineAvatarBuilder
from . UnityEngineHumanDescription import UnityEngineHumanDescription
from . SystemString import SystemString
from . UnityEngineGameObject import UnityEngineGameObject
from . SystemBoolean import SystemBoolean


class UnityEngineAvatarBuilder:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarBuilder:
        return UnityEngineAvatarBuilder

    @staticmethod
    def BuildGenericAvatar(input_0: UnityEngineGameObject, input_1: Union[SystemString, str]) -> UnityEngineAvatar:
        return UnityEngineAvatar

    @staticmethod
    def BuildHumanAvatar(input_0: UnityEngineGameObject, input_1: UnityEngineHumanDescription) -> UnityEngineAvatar:
        return UnityEngineAvatar

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAvatarBuilder:
        return UnityEngineAvatarBuilder
