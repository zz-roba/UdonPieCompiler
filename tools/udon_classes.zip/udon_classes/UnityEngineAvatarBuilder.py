from typing import Union
from typing import Any

from . UnityEngineHumanDescription import UnityEngineHumanDescription
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineAvatarBuilder import UnityEngineAvatarBuilder
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . UnityEngineAvatar import UnityEngineAvatar
from . UnityEngineGameObject import UnityEngineGameObject


class UnityEngineAvatarBuilder:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarBuilder:
        return UnityEngineAvatarBuilder

    @staticmethod
    def BuildGenericAvatar(input_0: UnityEngineGameObject, input_1: Union[SystemString, str]) -> UnityEngineAvatar:
        return UnityEngineAvatar

    @staticmethod
    def BuildHumanAvatar(input_0: UnityEngineGameObject, input_1: UnityEngineHumanDescription) -> UnityEngineAvatar:
        return UnityEngineAvatar

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAvatarBuilder:
        return UnityEngineAvatarBuilder
