from typing import Any

from . UnityEngineParticleSystemSubEmittersModule import UnityEngineParticleSystemSubEmittersModule


class UnityEngineParticleSystemSubEmittersModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSubEmittersModule:
        return UnityEngineParticleSystemSubEmittersModule
