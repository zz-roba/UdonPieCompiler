from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemSubEmitterProperties import UnityEngineParticleSystemSubEmitterProperties
from . UnityEngineParticleSystemSubEmittersModule import UnityEngineParticleSystemSubEmittersModule
from . UnityEngineParticleSystemSubEmitterType import UnityEngineParticleSystemSubEmitterType
from . SystemString import SystemString
from . UnityEngineParticleSystem import UnityEngineParticleSystem
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemSubEmittersModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSubEmittersModule:
        return UnityEngineParticleSystemSubEmittersModule

    @staticmethod
    def AddSubEmitter(input_1: UnityEngineParticleSystem, input_2: UnityEngineParticleSystemSubEmitterType, input_3: UnityEngineParticleSystemSubEmitterProperties) -> None:
        return 

    @staticmethod
    def AddSubEmitter(input_1: UnityEngineParticleSystem, input_2: UnityEngineParticleSystemSubEmitterType, input_3: UnityEngineParticleSystemSubEmitterProperties, input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetSubEmitterEmitProbability(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetSubEmitterProperties(input_1: Union[SystemInt32, int]) -> UnityEngineParticleSystemSubEmitterProperties:
        return UnityEngineParticleSystemSubEmitterProperties

    @staticmethod
    def GetSubEmitterSystem(input_1: Union[SystemInt32, int]) -> UnityEngineParticleSystem:
        return UnityEngineParticleSystem

    @staticmethod
    def GetSubEmitterType(input_1: Union[SystemInt32, int]) -> UnityEngineParticleSystemSubEmitterType:
        return UnityEngineParticleSystemSubEmitterType

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def RemoveSubEmitter(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetSubEmitterEmitProbability(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetSubEmitterProperties(input_1: Union[SystemInt32, int], input_2: UnityEngineParticleSystemSubEmitterProperties) -> None:
        return 

    @staticmethod
    def SetSubEmitterSystem(input_1: Union[SystemInt32, int], input_2: UnityEngineParticleSystem) -> None:
        return 

    @staticmethod
    def SetSubEmitterType(input_1: Union[SystemInt32, int], input_2: UnityEngineParticleSystemSubEmitterType) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_subEmittersCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 
