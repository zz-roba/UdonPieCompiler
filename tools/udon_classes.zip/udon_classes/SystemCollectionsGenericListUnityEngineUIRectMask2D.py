from typing import Any

from . SystemCollectionsGenericListUnityEngineUIRectMask2D import SystemCollectionsGenericListUnityEngineUIRectMask2D


class SystemCollectionsGenericListUnityEngineUIRectMask2D:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineUIRectMask2D:
        return SystemCollectionsGenericListUnityEngineUIRectMask2D
