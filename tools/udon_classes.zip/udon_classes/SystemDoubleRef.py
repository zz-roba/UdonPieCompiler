from typing import Any

from . SystemDoubleRef import SystemDoubleRef


class SystemDoubleRef:

    def __new__(cls, input_1: Any) -> SystemDoubleRef:
        return SystemDoubleRef
