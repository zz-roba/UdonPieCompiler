from typing import Any

from . UnityEngineParticleSystemStopBehavior import UnityEngineParticleSystemStopBehavior


class UnityEngineParticleSystemStopBehavior:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemStopBehavior:
        return UnityEngineParticleSystemStopBehavior
