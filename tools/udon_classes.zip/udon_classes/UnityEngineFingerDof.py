from typing import Any

from . UnityEngineFingerDof import UnityEngineFingerDof


class UnityEngineFingerDof:

    def __new__(cls, input_1: Any) -> UnityEngineFingerDof:
        return UnityEngineFingerDof
