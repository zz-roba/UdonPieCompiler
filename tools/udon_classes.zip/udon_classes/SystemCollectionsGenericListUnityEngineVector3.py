from typing import Any

from . SystemCollectionsGenericListUnityEngineVector3 import SystemCollectionsGenericListUnityEngineVector3


class SystemCollectionsGenericListUnityEngineVector3:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineVector3:
        return SystemCollectionsGenericListUnityEngineVector3
