from typing import Any

from . UnityEngineAINavMeshHitRef import UnityEngineAINavMeshHitRef


class UnityEngineAINavMeshHitRef:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshHitRef:
        return UnityEngineAINavMeshHitRef
