from typing import Any

from . SystemSingleRef import SystemSingleRef


class SystemSingleRef:

    def __new__(cls, input_1: Any) -> SystemSingleRef:
        return SystemSingleRef
