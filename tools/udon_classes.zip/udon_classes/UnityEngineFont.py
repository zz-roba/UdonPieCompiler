from typing import Any

from . UnityEngineFont import UnityEngineFont


class UnityEngineFont:

    def __new__(cls, input_1: Any) -> UnityEngineFont:
        return UnityEngineFont
