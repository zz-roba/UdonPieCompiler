from typing import Any

from . UnityEngineGradient import UnityEngineGradient


class UnityEngineGradient:

    def __new__(cls, input_1: Any) -> UnityEngineGradient:
        return UnityEngineGradient
