from typing import Any

from . UnityEngineHumanPartDof import UnityEngineHumanPartDof


class UnityEngineHumanPartDof:

    def __new__(cls, input_1: Any) -> UnityEngineHumanPartDof:
        return UnityEngineHumanPartDof
