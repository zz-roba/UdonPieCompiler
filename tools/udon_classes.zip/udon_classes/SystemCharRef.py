from typing import Any

from . SystemCharRef import SystemCharRef


class SystemCharRef:

    def __new__(cls, input_1: Any) -> SystemCharRef:
        return SystemCharRef
