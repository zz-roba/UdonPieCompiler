from typing import Any

from . UnityEngineAIOffMeshLinkData import UnityEngineAIOffMeshLinkData


class UnityEngineAIOffMeshLinkData:

    def __new__(cls, input_1: Any) -> UnityEngineAIOffMeshLinkData:
        return UnityEngineAIOffMeshLinkData
