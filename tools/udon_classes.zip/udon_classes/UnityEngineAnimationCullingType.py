from typing import Any

from . UnityEngineAnimationCullingType import UnityEngineAnimationCullingType


class UnityEngineAnimationCullingType:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationCullingType:
        return UnityEngineAnimationCullingType
