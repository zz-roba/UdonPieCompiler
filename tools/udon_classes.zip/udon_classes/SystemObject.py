from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class SystemObject:

    def __new__(cls, input_1: Any) -> SystemObject:
        return SystemObject

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_0: SystemObject, input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ReferenceEquals(input_0: SystemObject, input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> SystemObject:
        return SystemObject

    @staticmethod
    def op_Equality(input_0: SystemObject, input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemObject, input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]
