from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . UnityEngineColor import UnityEngineColor
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient
from . UnityEngineGradient import UnityEngineGradient
from . UnityEngineParticleSystemGradientMode import UnityEngineParticleSystemGradientMode
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemMinMaxGradient:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Evaluate(input_1: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def Evaluate(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: UnityEngineColor) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def ctor(input_0: UnityEngineGradient) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def ctor(input_0: UnityEngineColor, input_1: UnityEngineColor) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def ctor(input_0: UnityEngineGradient, input_1: UnityEngineGradient) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_color() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colorMax() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colorMin() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_gradient() -> UnityEngineGradient:
        return UnityEngineGradient

    @staticmethod
    def get_gradientMax() -> UnityEngineGradient:
        return UnityEngineGradient

    @staticmethod
    def get_gradientMin() -> UnityEngineGradient:
        return UnityEngineGradient

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemGradientMode:
        return UnityEngineParticleSystemGradientMode

    @staticmethod
    def op_Implicit(input_0: UnityEngineColor) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def op_Implicit(input_0: UnityEngineGradient) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def set_color(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colorMax(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colorMin(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_gradient(input_1: UnityEngineGradient) -> None:
        return 

    @staticmethod
    def set_gradientMax(input_1: UnityEngineGradient) -> None:
        return 

    @staticmethod
    def set_gradientMin(input_1: UnityEngineGradient) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemGradientMode) -> None:
        return 
