from typing import Any

from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient


class UnityEngineParticleSystemMinMaxGradient:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient
