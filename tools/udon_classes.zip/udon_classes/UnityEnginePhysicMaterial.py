from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineObject import UnityEngineObject
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEnginePhysicMaterialCombine import UnityEnginePhysicMaterialCombine
from . UnityEnginePhysicMaterial import UnityEnginePhysicMaterial
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEnginePhysicMaterial:

    def __new__(cls, input_1: Any) -> UnityEnginePhysicMaterial:
        return UnityEnginePhysicMaterial

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_bounceCombine() -> UnityEnginePhysicMaterialCombine:
        return UnityEnginePhysicMaterialCombine

    @staticmethod
    def get_bounciness() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_dynamicFriction() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_frictionCombine() -> UnityEnginePhysicMaterialCombine:
        return UnityEnginePhysicMaterialCombine

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_staticFriction() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_bounceCombine(input_1: UnityEnginePhysicMaterialCombine) -> None:
        return 

    @staticmethod
    def set_bounciness(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_dynamicFriction(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_frictionCombine(input_1: UnityEnginePhysicMaterialCombine) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_staticFriction(input_1: Union[SystemSingle, int, float]) -> None:
        return 
