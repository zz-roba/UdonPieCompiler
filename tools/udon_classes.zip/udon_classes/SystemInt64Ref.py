from typing import Any

from . SystemInt64Ref import SystemInt64Ref


class SystemInt64Ref:

    def __new__(cls, input_1: Any) -> SystemInt64Ref:
        return SystemInt64Ref
