from typing import Any

from . SystemCollectionsGenericListSystemString import SystemCollectionsGenericListSystemString


class SystemCollectionsGenericListSystemString:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListSystemString:
        return SystemCollectionsGenericListSystemString
