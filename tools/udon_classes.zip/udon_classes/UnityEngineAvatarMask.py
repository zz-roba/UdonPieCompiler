from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineAvatarMask import UnityEngineAvatarMask
from . UnityEngineAvatarMaskBodyPart import UnityEngineAvatarMaskBodyPart
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineAvatarMask:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarMask:
        return UnityEngineAvatarMask

    @staticmethod
    def AddTransformPath(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def AddTransformPath(input_1: UnityEngineTransform, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHumanoidBodyPartActive(input_1: UnityEngineAvatarMaskBodyPart) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetTransformActive(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetTransformPath(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def RemoveTransformPath(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def RemoveTransformPath(input_1: UnityEngineTransform, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetHumanoidBodyPartActive(input_1: UnityEngineAvatarMaskBodyPart, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetTransformActive(input_1: Union[SystemInt32, int], input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetTransformPath(input_1: Union[SystemInt32, int], input_2: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_transformCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_transformCount(input_1: Union[SystemInt32, int]) -> None:
        return 
