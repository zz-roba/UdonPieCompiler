from typing import Any

from . UnityEngineEffectorSelection2D import UnityEngineEffectorSelection2D


class UnityEngineEffectorSelection2D:

    def __new__(cls, input_1: Any) -> UnityEngineEffectorSelection2D:
        return UnityEngineEffectorSelection2D
