from typing import Any

from . UnityEngineLineAlignment import UnityEngineLineAlignment


class UnityEngineLineAlignment:

    def __new__(cls, input_1: Any) -> UnityEngineLineAlignment:
        return UnityEngineLineAlignment
