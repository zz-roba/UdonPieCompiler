from typing import Any

from . SystemGlobalizationCultureInfo import SystemGlobalizationCultureInfo


class SystemGlobalizationCultureInfo:

    def __new__(cls, input_1: Any) -> SystemGlobalizationCultureInfo:
        return SystemGlobalizationCultureInfo
