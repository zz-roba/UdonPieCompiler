from typing import Any

from . UnityEngineAudioClipPCMReaderCallback import UnityEngineAudioClipPCMReaderCallback


class UnityEngineAudioClipPCMReaderCallback:

    def __new__(cls, input_1: Any) -> UnityEngineAudioClipPCMReaderCallback:
        return UnityEngineAudioClipPCMReaderCallback
