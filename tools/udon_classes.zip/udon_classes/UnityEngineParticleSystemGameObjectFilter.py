from typing import Any

from . UnityEngineParticleSystemGameObjectFilter import UnityEngineParticleSystemGameObjectFilter


class UnityEngineParticleSystemGameObjectFilter:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemGameObjectFilter:
        return UnityEngineParticleSystemGameObjectFilter
