from typing import Any

from . UnityEngineLightRenderMode import UnityEngineLightRenderMode


class UnityEngineLightRenderMode:

    def __new__(cls, input_1: Any) -> UnityEngineLightRenderMode:
        return UnityEngineLightRenderMode
