from typing import Any

from . UnityEngineEventSystemsBaseEventData import UnityEngineEventSystemsBaseEventData


class UnityEngineEventSystemsBaseEventData:

    def __new__(cls, input_1: Any) -> UnityEngineEventSystemsBaseEventData:
        return UnityEngineEventSystemsBaseEventData
