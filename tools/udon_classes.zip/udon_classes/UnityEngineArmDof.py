from typing import Any

from . UnityEngineArmDof import UnityEngineArmDof


class UnityEngineArmDof:

    def __new__(cls, input_1: Any) -> UnityEngineArmDof:
        return UnityEngineArmDof
