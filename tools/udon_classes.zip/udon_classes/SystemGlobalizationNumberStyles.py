from typing import Any

from . SystemGlobalizationNumberStyles import SystemGlobalizationNumberStyles


class SystemGlobalizationNumberStyles:

    def __new__(cls, input_1: Any) -> SystemGlobalizationNumberStyles:
        return SystemGlobalizationNumberStyles
