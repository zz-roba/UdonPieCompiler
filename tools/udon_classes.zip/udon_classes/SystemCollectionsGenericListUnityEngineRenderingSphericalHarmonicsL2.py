from typing import Any

from . SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2 import SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2


class SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2:
        return SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2
