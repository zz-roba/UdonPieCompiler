from typing import Any

from . UnityEngineForceMode2D import UnityEngineForceMode2D


class UnityEngineForceMode2D:

    def __new__(cls, input_1: Any) -> UnityEngineForceMode2D:
        return UnityEngineForceMode2D
