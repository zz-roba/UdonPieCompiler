from typing import Any

from . UnityEngineEventSystemsAxisEventData import UnityEngineEventSystemsAxisEventData


class UnityEngineEventSystemsAxisEventData:

    def __new__(cls, input_1: Any) -> UnityEngineEventSystemsAxisEventData:
        return UnityEngineEventSystemsAxisEventData
