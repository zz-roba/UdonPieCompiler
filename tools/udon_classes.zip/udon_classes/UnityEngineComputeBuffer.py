from typing import Any

from . UnityEngineComputeBuffer import UnityEngineComputeBuffer


class UnityEngineComputeBuffer:

    def __new__(cls, input_1: Any) -> UnityEngineComputeBuffer:
        return UnityEngineComputeBuffer
