from typing import Any

from . SystemTypeCode import SystemTypeCode


class SystemTypeCode:

    def __new__(cls, input_1: Any) -> SystemTypeCode:
        return SystemTypeCode
