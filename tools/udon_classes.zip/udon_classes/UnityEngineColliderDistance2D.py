from typing import Any

from . UnityEngineColliderDistance2D import UnityEngineColliderDistance2D


class UnityEngineColliderDistance2D:

    def __new__(cls, input_1: Any) -> UnityEngineColliderDistance2D:
        return UnityEngineColliderDistance2D
