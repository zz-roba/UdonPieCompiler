from typing import Any

from . UnityEngineEffectorForceMode2D import UnityEngineEffectorForceMode2D


class UnityEngineEffectorForceMode2D:

    def __new__(cls, input_1: Any) -> UnityEngineEffectorForceMode2D:
        return UnityEngineEffectorForceMode2D
