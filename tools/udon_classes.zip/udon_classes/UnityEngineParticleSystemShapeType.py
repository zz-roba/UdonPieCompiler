from typing import Any

from . UnityEngineParticleSystemShapeType import UnityEngineParticleSystemShapeType


class UnityEngineParticleSystemShapeType:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemShapeType:
        return UnityEngineParticleSystemShapeType
