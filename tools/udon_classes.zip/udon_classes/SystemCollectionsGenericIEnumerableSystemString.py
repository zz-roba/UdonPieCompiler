from typing import Any

from . SystemCollectionsGenericIEnumerableSystemString import SystemCollectionsGenericIEnumerableSystemString


class SystemCollectionsGenericIEnumerableSystemString:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericIEnumerableSystemString:
        return SystemCollectionsGenericIEnumerableSystemString
