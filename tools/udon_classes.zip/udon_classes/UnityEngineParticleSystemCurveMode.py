from typing import Any

from . UnityEngineParticleSystemCurveMode import UnityEngineParticleSystemCurveMode


class UnityEngineParticleSystemCurveMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCurveMode:
        return UnityEngineParticleSystemCurveMode
