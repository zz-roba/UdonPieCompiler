from typing import Any

from . UnityEngineParticleSystemEmissionModuleArray import UnityEngineParticleSystemEmissionModuleArray


class UnityEngineParticleSystemEmissionModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemEmissionModuleArray:
        return UnityEngineParticleSystemEmissionModuleArray
