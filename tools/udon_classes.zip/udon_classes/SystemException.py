from typing import Any

from . SystemException import SystemException


class SystemException:

    def __new__(cls, input_1: Any) -> SystemException:
        return SystemException
