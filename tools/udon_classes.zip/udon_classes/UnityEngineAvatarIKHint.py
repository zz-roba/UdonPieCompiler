from typing import Any

from . UnityEngineAvatarIKHint import UnityEngineAvatarIKHint


class UnityEngineAvatarIKHint:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarIKHint:
        return UnityEngineAvatarIKHint
