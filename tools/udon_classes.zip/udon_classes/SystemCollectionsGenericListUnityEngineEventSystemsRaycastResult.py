from typing import Any

from . SystemCollectionsGenericListUnityEngineEventSystemsRaycastResult import SystemCollectionsGenericListUnityEngineEventSystemsRaycastResult


class SystemCollectionsGenericListUnityEngineEventSystemsRaycastResult:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineEventSystemsRaycastResult:
        return SystemCollectionsGenericListUnityEngineEventSystemsRaycastResult
