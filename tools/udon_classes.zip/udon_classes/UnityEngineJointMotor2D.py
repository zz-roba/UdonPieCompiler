from typing import Any

from . UnityEngineJointMotor2D import UnityEngineJointMotor2D


class UnityEngineJointMotor2D:

    def __new__(cls, input_1: Any) -> UnityEngineJointMotor2D:
        return UnityEngineJointMotor2D
