from typing import Any

from . UnityEngineJointTranslationLimits2D import UnityEngineJointTranslationLimits2D


class UnityEngineJointTranslationLimits2D:

    def __new__(cls, input_1: Any) -> UnityEngineJointTranslationLimits2D:
        return UnityEngineJointTranslationLimits2D
