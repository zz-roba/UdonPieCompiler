from typing import Any

from . UnityEngineParticleSystemRingBufferMode import UnityEngineParticleSystemRingBufferMode


class UnityEngineParticleSystemRingBufferMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemRingBufferMode:
        return UnityEngineParticleSystemRingBufferMode
