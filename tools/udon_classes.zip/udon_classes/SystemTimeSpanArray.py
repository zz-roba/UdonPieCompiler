from typing import Any

from . SystemTimeSpanArray import SystemTimeSpanArray


class SystemTimeSpanArray:

    def __new__(cls, input_1: Any) -> SystemTimeSpanArray:
        return SystemTimeSpanArray
