from typing import Any

from . UnityEngineAINavMeshBuildSettings import UnityEngineAINavMeshBuildSettings


class UnityEngineAINavMeshBuildSettings:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshBuildSettings:
        return UnityEngineAINavMeshBuildSettings
