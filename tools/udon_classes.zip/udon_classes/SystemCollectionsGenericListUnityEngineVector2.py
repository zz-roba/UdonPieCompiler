from typing import Any

from . SystemCollectionsGenericListUnityEngineVector2 import SystemCollectionsGenericListUnityEngineVector2


class SystemCollectionsGenericListUnityEngineVector2:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineVector2:
        return SystemCollectionsGenericListUnityEngineVector2
