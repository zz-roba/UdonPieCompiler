from typing import Any

from . SystemBooleanRef import SystemBooleanRef


class SystemBooleanRef:

    def __new__(cls, input_1: Any) -> SystemBooleanRef:
        return SystemBooleanRef
