from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineParticleSystemEmitParams import UnityEngineParticleSystemEmitParams
from . SystemInt32 import SystemInt32
from . UnityEngineColor32 import UnityEngineColor32
from . SystemUInt32 import SystemUInt32
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemEmitParams:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemEmitParams:
        return UnityEngineParticleSystemEmitParams

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ResetAngularVelocity() -> None:
        return 

    @staticmethod
    def ResetAxisOfRotation() -> None:
        return 

    @staticmethod
    def ResetPosition() -> None:
        return 

    @staticmethod
    def ResetRandomSeed() -> None:
        return 

    @staticmethod
    def ResetRotation() -> None:
        return 

    @staticmethod
    def ResetStartColor() -> None:
        return 

    @staticmethod
    def ResetStartLifetime() -> None:
        return 

    @staticmethod
    def ResetStartSize() -> None:
        return 

    @staticmethod
    def ResetVelocity() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_angularVelocity() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_angularVelocity3D() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_applyShapeToPosition() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_axisOfRotation() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_position() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_randomSeed() -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def get_rotation() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rotation3D() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_startColor() -> UnityEngineColor32:
        return UnityEngineColor32

    @staticmethod
    def get_startLifetime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSize() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSize3D() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_velocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def set_angularVelocity(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_angularVelocity3D(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_applyShapeToPosition(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_axisOfRotation(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_position(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_randomSeed(input_1: SystemUInt32) -> None:
        return 

    @staticmethod
    def set_rotation(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_rotation3D(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_startColor(input_1: UnityEngineColor32) -> None:
        return 

    @staticmethod
    def set_startLifetime(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSize(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSize3D(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_velocity(input_1: UnityEngineVector3) -> None:
        return 
