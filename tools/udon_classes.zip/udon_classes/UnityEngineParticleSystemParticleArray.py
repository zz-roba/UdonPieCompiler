from typing import Any

from . UnityEngineParticleSystemParticleArray import UnityEngineParticleSystemParticleArray


class UnityEngineParticleSystemParticleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemParticleArray:
        return UnityEngineParticleSystemParticleArray
