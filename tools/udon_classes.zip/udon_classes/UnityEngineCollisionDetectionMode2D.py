from typing import Any

from . UnityEngineCollisionDetectionMode2D import UnityEngineCollisionDetectionMode2D


class UnityEngineCollisionDetectionMode2D:

    def __new__(cls, input_1: Any) -> UnityEngineCollisionDetectionMode2D:
        return UnityEngineCollisionDetectionMode2D
