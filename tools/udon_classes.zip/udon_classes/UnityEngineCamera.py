from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . UnityEngineRenderTexture import UnityEngineRenderTexture
from . UnityEngineVector4 import UnityEngineVector4
from . ListT import ListT
from . UnityEngineCubemap import UnityEngineCubemap
from . UnityEngineCameraGateFitMode import UnityEngineCameraGateFitMode
from . UnityEngineRenderingPath import UnityEngineRenderingPath
from . UnityEngineCameraStereoscopicEye import UnityEngineCameraStereoscopicEye
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineStereoTargetEyeMask import UnityEngineStereoTargetEyeMask
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineMatrix4x4Ref import UnityEngineMatrix4x4Ref
from . UnityEngineVector3Array import UnityEngineVector3Array
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineColor import UnityEngineColor
from . UnityEngineTransparencySortMode import UnityEngineTransparencySortMode
from . SystemInt32 import SystemInt32
from . T import T
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineShader import UnityEngineShader
from . SystemBoolean import SystemBoolean
from . UnityEngineCameraCameraCallback import UnityEngineCameraCameraCallback
from . UnityEngineRect import UnityEngineRect
from . UnityEngineDepthTextureMode import UnityEngineDepthTextureMode
from . UnityEngineMatrix4x4 import UnityEngineMatrix4x4
from . UnityEngineCamera import UnityEngineCamera
from . UnityEngineCameraMonoOrStereoscopicEye import UnityEngineCameraMonoOrStereoscopicEye
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineObject import UnityEngineObject
from . UnityEngineRenderBuffer import UnityEngineRenderBuffer
from . SystemObject import SystemObject
from . UnityEngineCameraClearFlags import UnityEngineCameraClearFlags
from . SystemSingleArray import SystemSingleArray
from . UnityEngineRay import UnityEngineRay
from . SystemString import SystemString
from . UnityEngineRenderBufferArray import UnityEngineRenderBufferArray
from . UnityEngineRenderingOpaqueSortMode import UnityEngineRenderingOpaqueSortMode
from . UnityEngineCameraType import UnityEngineCameraType
from . UnityEngineCameraGateFitParameters import UnityEngineCameraGateFitParameters


class UnityEngineCamera:

    def __new__(cls, input_1: Any) -> UnityEngineCamera:
        return UnityEngineCamera

    @staticmethod
    def CalculateFrustumCorners(input_1: UnityEngineRect, input_2: Union[SystemSingle, int, float], input_3: UnityEngineCameraMonoOrStereoscopicEye, input_4: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def CalculateObliqueMatrix(input_1: UnityEngineVector4) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def CalculateProjectionMatrixFromPhysicalProperties(input_0: UnityEngineMatrix4x4Ref, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float], input_6: UnityEngineCameraGateFitParameters) -> None:
        return 

    @staticmethod
    def CopyFrom(input_1: UnityEngineCamera) -> None:
        return 

    @staticmethod
    def CopyStereoDeviceProjectionMatrixToNonJittered(input_1: UnityEngineCameraStereoscopicEye) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FOVToFocalLength(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def FocalLengthToFOV(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineCamera, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineCamera, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineCamera, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineCamera, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetStereoNonJitteredProjectionMatrix(input_1: UnityEngineCameraStereoscopicEye) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetStereoProjectionMatrix(input_1: UnityEngineCameraStereoscopicEye) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetStereoViewMatrix(input_1: UnityEngineCameraStereoscopicEye) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Render() -> None:
        return 

    @staticmethod
    def RenderDontRestore() -> None:
        return 

    @staticmethod
    def RenderToCubemap(input_1: UnityEngineCubemap, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RenderToCubemap(input_1: UnityEngineCubemap) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RenderToCubemap(input_1: UnityEngineRenderTexture, input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RenderToCubemap(input_1: UnityEngineRenderTexture) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RenderToCubemap(input_1: UnityEngineRenderTexture, input_2: Union[SystemInt32, int], input_3: UnityEngineCameraMonoOrStereoscopicEye) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def RenderWithShader(input_1: UnityEngineShader, input_2: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Reset() -> None:
        return 

    @staticmethod
    def ResetAspect() -> None:
        return 

    @staticmethod
    def ResetCullingMatrix() -> None:
        return 

    @staticmethod
    def ResetProjectionMatrix() -> None:
        return 

    @staticmethod
    def ResetReplacementShader() -> None:
        return 

    @staticmethod
    def ResetStereoProjectionMatrices() -> None:
        return 

    @staticmethod
    def ResetStereoViewMatrices() -> None:
        return 

    @staticmethod
    def ResetTransparencySortSettings() -> None:
        return 

    @staticmethod
    def ResetWorldToCameraMatrix() -> None:
        return 

    @staticmethod
    def ScreenPointToRay(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineRay:
        return UnityEngineRay

    @staticmethod
    def ScreenPointToRay(input_1: UnityEngineVector3) -> UnityEngineRay:
        return UnityEngineRay

    @staticmethod
    def ScreenToViewportPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def ScreenToWorldPoint(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def ScreenToWorldPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def SetReplacementShader(input_1: UnityEngineShader, input_2: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def SetStereoProjectionMatrix(input_1: UnityEngineCameraStereoscopicEye, input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetStereoViewMatrix(input_1: UnityEngineCameraStereoscopicEye, input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetTargetBuffers(input_1: UnityEngineRenderBuffer, input_2: UnityEngineRenderBuffer) -> None:
        return 

    @staticmethod
    def SetTargetBuffers(input_1: UnityEngineRenderBufferArray, input_2: UnityEngineRenderBuffer) -> None:
        return 

    @staticmethod
    def SetupCurrent(input_0: UnityEngineCamera) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ViewportPointToRay(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineRay:
        return UnityEngineRay

    @staticmethod
    def ViewportPointToRay(input_1: UnityEngineVector3) -> UnityEngineRay:
        return UnityEngineRay

    @staticmethod
    def ViewportToScreenPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def ViewportToWorldPoint(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def ViewportToWorldPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def WorldToScreenPoint(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def WorldToScreenPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def WorldToViewportPoint(input_1: UnityEngineVector3, input_2: UnityEngineCameraMonoOrStereoscopicEye) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def WorldToViewportPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_activeTexture() -> UnityEngineRenderTexture:
        return UnityEngineRenderTexture

    @staticmethod
    def get_actualRenderingPath() -> UnityEngineRenderingPath:
        return UnityEngineRenderingPath

    @staticmethod
    def get_allowDynamicResolution() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_allowHDR() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_allowMSAA() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_areVRStereoViewMatricesWithinSingleCullTolerance() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_aspect() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_backgroundColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_cameraToWorldMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_cameraType() -> UnityEngineCameraType:
        return UnityEngineCameraType

    @staticmethod
    def get_clearFlags() -> UnityEngineCameraClearFlags:
        return UnityEngineCameraClearFlags

    @staticmethod
    def get_clearStencilAfterLightingPass() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_cullingMask() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_cullingMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_depth() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_depthTextureMode() -> UnityEngineDepthTextureMode:
        return UnityEngineDepthTextureMode

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_eventMask() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_farClipPlane() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_fieldOfView() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_focalLength() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_forceIntoRenderTexture() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_gateFit() -> UnityEngineCameraGateFitMode:
        return UnityEngineCameraGateFitMode

    @staticmethod
    def get_layerCullDistances() -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def get_layerCullSpherical() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lensShift() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_nearClipPlane() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_nonJitteredProjectionMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_onPostRender() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def get_onPreCull() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def get_onPreRender() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def get_opaqueSortMode() -> UnityEngineRenderingOpaqueSortMode:
        return UnityEngineRenderingOpaqueSortMode

    @staticmethod
    def get_orthographic() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_orthographicSize() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_pixelHeight() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_pixelRect() -> UnityEngineRect:
        return UnityEngineRect

    @staticmethod
    def get_pixelWidth() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_previousViewProjectionMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_projectionMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_rect() -> UnityEngineRect:
        return UnityEngineRect

    @staticmethod
    def get_renderingPath() -> UnityEngineRenderingPath:
        return UnityEngineRenderingPath

    @staticmethod
    def get_scaledPixelHeight() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_scaledPixelWidth() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_sensorSize() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_stereoActiveEye() -> UnityEngineCameraMonoOrStereoscopicEye:
        return UnityEngineCameraMonoOrStereoscopicEye

    @staticmethod
    def get_stereoConvergence() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_stereoEnabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_stereoSeparation() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_stereoTargetEye() -> UnityEngineStereoTargetEyeMask:
        return UnityEngineStereoTargetEyeMask

    @staticmethod
    def get_targetDisplay() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_targetTexture() -> UnityEngineRenderTexture:
        return UnityEngineRenderTexture

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_transparencySortAxis() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_transparencySortMode() -> UnityEngineTransparencySortMode:
        return UnityEngineTransparencySortMode

    @staticmethod
    def get_useJitteredProjectionMatrixForTransparentRendering() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_useOcclusionCulling() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_usePhysicalProperties() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_velocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_worldToCameraMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_allowDynamicResolution(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_allowHDR(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_allowMSAA(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_aspect(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_backgroundColor(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_cameraType(input_1: UnityEngineCameraType) -> None:
        return 

    @staticmethod
    def set_clearFlags(input_1: UnityEngineCameraClearFlags) -> None:
        return 

    @staticmethod
    def set_clearStencilAfterLightingPass(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_cullingMask(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_cullingMatrix(input_1: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def set_depth(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_depthTextureMode(input_1: UnityEngineDepthTextureMode) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_eventMask(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_farClipPlane(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_fieldOfView(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_focalLength(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_forceIntoRenderTexture(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_gateFit(input_1: UnityEngineCameraGateFitMode) -> None:
        return 

    @staticmethod
    def set_layerCullDistances(input_1: SystemSingleArray) -> None:
        return 

    @staticmethod
    def set_layerCullSpherical(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_lensShift(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_nearClipPlane(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_nonJitteredProjectionMatrix(input_1: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def set_onPostRender() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def set_onPreCull() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def set_onPreRender() -> UnityEngineCameraCameraCallback:
        return UnityEngineCameraCameraCallback

    @staticmethod
    def set_opaqueSortMode(input_1: UnityEngineRenderingOpaqueSortMode) -> None:
        return 

    @staticmethod
    def set_orthographic(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_orthographicSize(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_pixelRect(input_1: UnityEngineRect) -> None:
        return 

    @staticmethod
    def set_projectionMatrix(input_1: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def set_rect(input_1: UnityEngineRect) -> None:
        return 

    @staticmethod
    def set_renderingPath(input_1: UnityEngineRenderingPath) -> None:
        return 

    @staticmethod
    def set_sensorSize(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_stereoConvergence(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_stereoSeparation(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_stereoTargetEye(input_1: UnityEngineStereoTargetEyeMask) -> None:
        return 

    @staticmethod
    def set_targetDisplay(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_targetTexture(input_1: UnityEngineRenderTexture) -> None:
        return 

    @staticmethod
    def set_transparencySortAxis(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_transparencySortMode(input_1: UnityEngineTransparencySortMode) -> None:
        return 

    @staticmethod
    def set_useJitteredProjectionMatrixForTransparentRendering(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_useOcclusionCulling(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_usePhysicalProperties(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_worldToCameraMatrix(input_1: UnityEngineMatrix4x4) -> None:
        return 
