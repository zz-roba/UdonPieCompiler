from typing import Any

from . UnityEngineParticleSystemTrailTextureMode import UnityEngineParticleSystemTrailTextureMode


class UnityEngineParticleSystemTrailTextureMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemTrailTextureMode:
        return UnityEngineParticleSystemTrailTextureMode
