from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . UnityEngineAnimatorControllerParameter import UnityEngineAnimatorControllerParameter
from . SystemBoolean import SystemBoolean
from . UnityEngineAnimatorControllerParameterType import UnityEngineAnimatorControllerParameterType


class UnityEngineAnimatorControllerParameter:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorControllerParameter:
        return UnityEngineAnimatorControllerParameter

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAnimatorControllerParameter:
        return UnityEngineAnimatorControllerParameter

    @staticmethod
    def get_defaultBool() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_defaultFloat() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_defaultInt() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_nameHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_type() -> UnityEngineAnimatorControllerParameterType:
        return UnityEngineAnimatorControllerParameterType

    @staticmethod
    def set_defaultBool(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_defaultFloat(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_defaultInt(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_type(input_1: UnityEngineAnimatorControllerParameterType) -> None:
        return 
