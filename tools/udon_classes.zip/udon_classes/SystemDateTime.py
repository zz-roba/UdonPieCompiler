from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemInt64 import SystemInt64
from . SystemObject import SystemObject
from . SystemDateTimeRef import SystemDateTimeRef
from . SystemInt32 import SystemInt32
from . SystemGlobalizationCalendar import SystemGlobalizationCalendar
from . SystemChar import SystemChar
from . SystemGlobalizationDateTimeStyles import SystemGlobalizationDateTimeStyles
from . SystemDayOfWeek import SystemDayOfWeek
from . SystemDateTime import SystemDateTime
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemDateTimeKind import SystemDateTimeKind
from . SystemDouble import SystemDouble
from . SystemTimeSpan import SystemTimeSpan
from . SystemBoolean import SystemBoolean


class SystemDateTime:

    def __new__(cls, input_1: Any) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def Add(input_1: SystemTimeSpan) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddDays(input_1: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddHours(input_1: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddMilliseconds(input_1: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddMinutes(input_1: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddMonths(input_1: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddSeconds(input_1: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddTicks(input_1: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def AddYears(input_1: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def Compare(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: SystemObject) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: SystemDateTime) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def DaysInMonth(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FromBinary(input_0: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def FromFileTime(input_0: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def FromFileTimeUtc(input_0: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def FromOADate(input_0: SystemDouble) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def GetDateTimeFormats() -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetDateTimeFormats(input_1: SystemIFormatProvider) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetDateTimeFormats(input_1: SystemChar) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetDateTimeFormats(input_1: SystemChar, input_2: SystemIFormatProvider) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsDaylightSavingTime() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLeapYear(input_0: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Parse(input_0: Union[SystemString, str]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemIFormatProvider, input_2: SystemGlobalizationDateTimeStyles) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ParseExact(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemIFormatProvider) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ParseExact(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemIFormatProvider, input_3: SystemGlobalizationDateTimeStyles) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ParseExact(input_0: Union[SystemString, str], input_1: SystemStringArray, input_2: SystemIFormatProvider, input_3: SystemGlobalizationDateTimeStyles) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def SpecifyKind(input_0: SystemDateTime, input_1: SystemDateTimeKind) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def Subtract(input_1: SystemDateTime) -> SystemTimeSpan:
        return SystemTimeSpan

    @staticmethod
    def Subtract(input_1: SystemTimeSpan) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToBinary() -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToFileTime() -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToFileTimeUtc() -> SystemInt64:
        return SystemInt64

    @staticmethod
    def ToLocalTime() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ToLongDateString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToLongTimeString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToOADate() -> SystemDouble:
        return SystemDouble

    @staticmethod
    def ToShortDateString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToShortTimeString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str], input_2: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUniversalTime() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemDateTimeRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemIFormatProvider, input_2: SystemGlobalizationDateTimeStyles, input_3: SystemDateTimeRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def TryParseExact(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemIFormatProvider, input_3: SystemGlobalizationDateTimeStyles, input_4: SystemDateTimeRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def TryParseExact(input_0: Union[SystemString, str], input_1: SystemStringArray, input_2: SystemIFormatProvider, input_3: SystemGlobalizationDateTimeStyles, input_4: SystemDateTimeRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ctor(input_0: SystemInt64) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: SystemInt64, input_1: SystemDateTimeKind) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: SystemGlobalizationCalendar) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: SystemDateTimeKind) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: SystemGlobalizationCalendar) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: Union[SystemInt32, int]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: Union[SystemInt32, int], input_7: SystemDateTimeKind) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: Union[SystemInt32, int], input_7: SystemGlobalizationCalendar) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ctor(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemInt32, int], input_6: Union[SystemInt32, int], input_7: SystemGlobalizationCalendar, input_8: SystemDateTimeKind) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Date() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Day() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_DayOfWeek() -> SystemDayOfWeek:
        return SystemDayOfWeek

    @staticmethod
    def get_DayOfYear() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_Hour() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_Kind() -> SystemDateTimeKind:
        return SystemDateTimeKind

    @staticmethod
    def get_MaxValue() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Millisecond() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_MinValue() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Minute() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_Month() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_Now() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Second() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_Ticks() -> SystemInt64:
        return SystemInt64

    @staticmethod
    def get_TimeOfDay() -> SystemTimeSpan:
        return SystemTimeSpan

    @staticmethod
    def get_Today() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_UtcNow() -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def get_Year() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Addition(input_0: SystemDateTime, input_1: SystemTimeSpan) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def op_Equality(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThan(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThanOrEqual(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThan(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThanOrEqual(input_0: SystemDateTime, input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Subtraction(input_0: SystemDateTime, input_1: SystemTimeSpan) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def op_Subtraction(input_0: SystemDateTime, input_1: SystemDateTime) -> SystemTimeSpan:
        return SystemTimeSpan
