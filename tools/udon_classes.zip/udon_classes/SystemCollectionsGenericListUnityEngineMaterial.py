from typing import Any

from . SystemCollectionsGenericListUnityEngineMaterial import SystemCollectionsGenericListUnityEngineMaterial


class SystemCollectionsGenericListUnityEngineMaterial:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineMaterial:
        return SystemCollectionsGenericListUnityEngineMaterial
