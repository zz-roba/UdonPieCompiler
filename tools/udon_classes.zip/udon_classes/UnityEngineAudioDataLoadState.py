from typing import Any

from . UnityEngineAudioDataLoadState import UnityEngineAudioDataLoadState


class UnityEngineAudioDataLoadState:

    def __new__(cls, input_1: Any) -> UnityEngineAudioDataLoadState:
        return UnityEngineAudioDataLoadState
