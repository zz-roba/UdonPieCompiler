from typing import Any

from . SystemDateTimeOffset import SystemDateTimeOffset


class SystemDateTimeOffset:

    def __new__(cls, input_1: Any) -> SystemDateTimeOffset:
        return SystemDateTimeOffset
