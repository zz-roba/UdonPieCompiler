from typing import Any

from . UnityEngineLightShadows import UnityEngineLightShadows


class UnityEngineLightShadows:

    def __new__(cls, input_1: Any) -> UnityEngineLightShadows:
        return UnityEngineLightShadows
