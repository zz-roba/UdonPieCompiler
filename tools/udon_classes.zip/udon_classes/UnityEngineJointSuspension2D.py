from typing import Any

from . UnityEngineJointSuspension2D import UnityEngineJointSuspension2D


class UnityEngineJointSuspension2D:

    def __new__(cls, input_1: Any) -> UnityEngineJointSuspension2D:
        return UnityEngineJointSuspension2D
