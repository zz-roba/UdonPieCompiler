from typing import Any

from . UnityEngineKeyCode import UnityEngineKeyCode


class UnityEngineKeyCode:

    def __new__(cls, input_1: Any) -> UnityEngineKeyCode:
        return UnityEngineKeyCode
