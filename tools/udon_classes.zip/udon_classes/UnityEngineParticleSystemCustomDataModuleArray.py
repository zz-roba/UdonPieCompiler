from typing import Any

from . UnityEngineParticleSystemCustomDataModuleArray import UnityEngineParticleSystemCustomDataModuleArray


class UnityEngineParticleSystemCustomDataModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCustomDataModuleArray:
        return UnityEngineParticleSystemCustomDataModuleArray
