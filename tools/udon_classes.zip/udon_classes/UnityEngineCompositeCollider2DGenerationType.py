from typing import Any

from . UnityEngineCompositeCollider2DGenerationType import UnityEngineCompositeCollider2DGenerationType


class UnityEngineCompositeCollider2DGenerationType:

    def __new__(cls, input_1: Any) -> UnityEngineCompositeCollider2DGenerationType:
        return UnityEngineCompositeCollider2DGenerationType
