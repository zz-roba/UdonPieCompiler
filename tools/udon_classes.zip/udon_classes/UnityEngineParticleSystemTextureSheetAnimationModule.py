from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineParticleSystemTextureSheetAnimationModule import UnityEngineParticleSystemTextureSheetAnimationModule
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineParticleSystemAnimationType import UnityEngineParticleSystemAnimationType
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineSprite import UnityEngineSprite
from . SystemString import SystemString
from . UnityEngineParticleSystemAnimationMode import UnityEngineParticleSystemAnimationMode
from . UnityEngineParticleSystemAnimationTimeMode import UnityEngineParticleSystemAnimationTimeMode
from . SystemBoolean import SystemBoolean
from . UnityEngineRenderingUVChannelFlags import UnityEngineRenderingUVChannelFlags


class UnityEngineParticleSystemTextureSheetAnimationModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemTextureSheetAnimationModule:
        return UnityEngineParticleSystemTextureSheetAnimationModule

    @staticmethod
    def AddSprite(input_1: UnityEngineSprite) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetSprite(input_1: Union[SystemInt32, int]) -> UnityEngineSprite:
        return UnityEngineSprite

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def RemoveSprite(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetSprite(input_1: Union[SystemInt32, int], input_2: UnityEngineSprite) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_animation() -> UnityEngineParticleSystemAnimationType:
        return UnityEngineParticleSystemAnimationType

    @staticmethod
    def get_cycleCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_fps() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_frameOverTime() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_frameOverTimeMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemAnimationMode:
        return UnityEngineParticleSystemAnimationMode

    @staticmethod
    def get_numTilesX() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_numTilesY() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_rowIndex() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_speedRange() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_spriteCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_startFrame() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startFrameMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_timeMode() -> UnityEngineParticleSystemAnimationTimeMode:
        return UnityEngineParticleSystemAnimationTimeMode

    @staticmethod
    def get_useRandomRow() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_uvChannelMask() -> UnityEngineRenderingUVChannelFlags:
        return UnityEngineRenderingUVChannelFlags

    @staticmethod
    def set_animation(input_1: UnityEngineParticleSystemAnimationType) -> None:
        return 

    @staticmethod
    def set_cycleCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_fps(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_frameOverTime(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_frameOverTimeMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemAnimationMode) -> None:
        return 

    @staticmethod
    def set_numTilesX(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_numTilesY(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_rowIndex(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_speedRange(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_startFrame(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startFrameMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_timeMode(input_1: UnityEngineParticleSystemAnimationTimeMode) -> None:
        return 

    @staticmethod
    def set_useRandomRow(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_uvChannelMask(input_1: UnityEngineRenderingUVChannelFlags) -> None:
        return 
