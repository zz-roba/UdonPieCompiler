from typing import Any

from . UnityEngineParticleSystemRotationBySpeedModule import UnityEngineParticleSystemRotationBySpeedModule


class UnityEngineParticleSystemRotationBySpeedModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemRotationBySpeedModule:
        return UnityEngineParticleSystemRotationBySpeedModule
