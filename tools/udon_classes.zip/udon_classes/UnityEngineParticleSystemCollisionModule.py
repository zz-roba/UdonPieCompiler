from typing import Any

from . UnityEngineParticleSystemCollisionModule import UnityEngineParticleSystemCollisionModule


class UnityEngineParticleSystemCollisionModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCollisionModule:
        return UnityEngineParticleSystemCollisionModule
