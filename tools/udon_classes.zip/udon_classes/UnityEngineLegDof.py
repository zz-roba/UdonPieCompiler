from typing import Any

from . UnityEngineLegDof import UnityEngineLegDof


class UnityEngineLegDof:

    def __new__(cls, input_1: Any) -> UnityEngineLegDof:
        return UnityEngineLegDof
