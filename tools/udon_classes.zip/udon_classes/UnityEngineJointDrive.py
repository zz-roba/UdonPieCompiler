from typing import Any

from . UnityEngineJointDrive import UnityEngineJointDrive


class UnityEngineJointDrive:

    def __new__(cls, input_1: Any) -> UnityEngineJointDrive:
        return UnityEngineJointDrive
