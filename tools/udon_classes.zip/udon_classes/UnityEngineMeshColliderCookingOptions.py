from typing import Any

from . UnityEngineMeshColliderCookingOptions import UnityEngineMeshColliderCookingOptions


class UnityEngineMeshColliderCookingOptions:

    def __new__(cls, input_1: Any) -> UnityEngineMeshColliderCookingOptions:
        return UnityEngineMeshColliderCookingOptions
