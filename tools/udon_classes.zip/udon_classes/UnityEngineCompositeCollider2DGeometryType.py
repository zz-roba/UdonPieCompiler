from typing import Any

from . UnityEngineCompositeCollider2DGeometryType import UnityEngineCompositeCollider2DGeometryType


class UnityEngineCompositeCollider2DGeometryType:

    def __new__(cls, input_1: Any) -> UnityEngineCompositeCollider2DGeometryType:
        return UnityEngineCompositeCollider2DGeometryType
