from typing import Any

from . SystemTextNormalizationForm import SystemTextNormalizationForm


class SystemTextNormalizationForm:

    def __new__(cls, input_1: Any) -> SystemTextNormalizationForm:
        return SystemTextNormalizationForm
