from typing import Union
from typing import Any

from . UnityEngineAnimationState import UnityEngineAnimationState
from . UnityEngineTransform import UnityEngineTransform
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineWrapMode import UnityEngineWrapMode
from . SystemInt32 import SystemInt32
from . UnityEngineAnimationBlendMode import UnityEngineAnimationBlendMode
from . SystemString import SystemString
from . UnityEngineTrackedReference import UnityEngineTrackedReference
from . UnityEngineAnimationClip import UnityEngineAnimationClip
from . SystemBoolean import SystemBoolean


class UnityEngineAnimationState:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def AddMixingTransform(input_1: UnityEngineTransform, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def AddMixingTransform(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def RemoveMixingTransform(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAnimationState:
        return UnityEngineAnimationState

    @staticmethod
    def get_blendMode() -> UnityEngineAnimationBlendMode:
        return UnityEngineAnimationBlendMode

    @staticmethod
    def get_clip() -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_layer() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_length() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_normalizedSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_normalizedTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_speed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_time() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_weight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_wrapMode() -> UnityEngineWrapMode:
        return UnityEngineWrapMode

    @staticmethod
    def op_Equality(input_0: UnityEngineTrackedReference, input_1: UnityEngineTrackedReference) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineTrackedReference) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineTrackedReference, input_1: UnityEngineTrackedReference) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_blendMode(input_1: UnityEngineAnimationBlendMode) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_layer(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_normalizedSpeed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_normalizedTime(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_speed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_time(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_weight(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_wrapMode(input_1: UnityEngineWrapMode) -> None:
        return 
