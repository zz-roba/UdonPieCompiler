from typing import Any

from . UnityEngineParticleSystemShapeMultiModeValue import UnityEngineParticleSystemShapeMultiModeValue


class UnityEngineParticleSystemShapeMultiModeValue:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemShapeMultiModeValue:
        return UnityEngineParticleSystemShapeMultiModeValue
