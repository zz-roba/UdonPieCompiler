from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3Array import UnityEngineVector3Array
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . UnityEngineAINavMeshPath import UnityEngineAINavMeshPath
from . UnityEngineAINavMeshPathStatus import UnityEngineAINavMeshPathStatus
from . SystemBoolean import SystemBoolean


class UnityEngineAINavMeshPath:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshPath:
        return UnityEngineAINavMeshPath

    @staticmethod
    def ClearCorners() -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetCornersNonAlloc(input_1: UnityEngineVector3Array) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAINavMeshPath:
        return UnityEngineAINavMeshPath

    @staticmethod
    def get_corners() -> UnityEngineVector3Array:
        return UnityEngineVector3Array

    @staticmethod
    def get_status() -> UnityEngineAINavMeshPathStatus:
        return UnityEngineAINavMeshPathStatus
