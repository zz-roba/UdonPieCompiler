from typing import Any

from . UnityEngineAudioClipPCMSetPositionCallback import UnityEngineAudioClipPCMSetPositionCallback


class UnityEngineAudioClipPCMSetPositionCallback:

    def __new__(cls, input_1: Any) -> UnityEngineAudioClipPCMSetPositionCallback:
        return UnityEngineAudioClipPCMSetPositionCallback
