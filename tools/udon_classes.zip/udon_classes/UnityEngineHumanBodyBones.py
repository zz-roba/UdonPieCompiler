from typing import Any

from . UnityEngineHumanBodyBones import UnityEngineHumanBodyBones


class UnityEngineHumanBodyBones:

    def __new__(cls, input_1: Any) -> UnityEngineHumanBodyBones:
        return UnityEngineHumanBodyBones
