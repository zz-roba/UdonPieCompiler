from typing import Any

from . UnityEnginePlane import UnityEnginePlane


class UnityEnginePlane:

    def __new__(cls, input_1: Any) -> UnityEnginePlane:
        return UnityEnginePlane
