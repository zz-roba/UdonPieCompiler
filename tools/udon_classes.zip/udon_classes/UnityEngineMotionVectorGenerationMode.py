from typing import Any

from . UnityEngineMotionVectorGenerationMode import UnityEngineMotionVectorGenerationMode


class UnityEngineMotionVectorGenerationMode:

    def __new__(cls, input_1: Any) -> UnityEngineMotionVectorGenerationMode:
        return UnityEngineMotionVectorGenerationMode
