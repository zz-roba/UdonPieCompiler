from typing import Any

from . UnityEngineParticleSystemInheritVelocityMode import UnityEngineParticleSystemInheritVelocityMode


class UnityEngineParticleSystemInheritVelocityMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemInheritVelocityMode:
        return UnityEngineParticleSystemInheritVelocityMode
