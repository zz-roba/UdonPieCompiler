from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineParticleSystemTrailModule import UnityEngineParticleSystemTrailModule
from . UnityEngineParticleSystemRotationOverLifetimeModule import UnityEngineParticleSystemRotationOverLifetimeModule
from . UnityEngineParticleSystemRotationBySpeedModule import UnityEngineParticleSystemRotationBySpeedModule
from . UnityEngineParticleSystemMainModule import UnityEngineParticleSystemMainModule
from . SystemCollectionsGenericListUnityEngineParticleSystemParticle import SystemCollectionsGenericListUnityEngineParticleSystemParticle
from . UnityEngineParticleSystemCustomData import UnityEngineParticleSystemCustomData
from . UnityEngineParticleSystemEmitParams import UnityEngineParticleSystemEmitParams
from . SystemBoolean import SystemBoolean
from . UnityEngineParticleSystemEmissionModule import UnityEngineParticleSystemEmissionModule
from . UnityEngineParticleSystemLimitVelocityOverLifetimeModule import UnityEngineParticleSystemLimitVelocityOverLifetimeModule
from . UnityEngineParticleSystemStopBehavior import UnityEngineParticleSystemStopBehavior
from . SystemUInt32 import SystemUInt32
from . T import T
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemVelocityOverLifetimeModule import UnityEngineParticleSystemVelocityOverLifetimeModule
from . UnityEngineParticleSystemExternalForcesModule import UnityEngineParticleSystemExternalForcesModule
from . UnityEngineParticleSystemSubEmittersModule import UnityEngineParticleSystemSubEmittersModule
from . UnityEngineParticleSystemTextureSheetAnimationModule import UnityEngineParticleSystemTextureSheetAnimationModule
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4
from . UnityEngineParticleSystemCustomDataModule import UnityEngineParticleSystemCustomDataModule
from . UnityEngineParticleSystemLightsModule import UnityEngineParticleSystemLightsModule
from . UnityEngineParticleSystemSizeBySpeedModule import UnityEngineParticleSystemSizeBySpeedModule
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . UnityEngineParticleSystemColorOverLifetimeModule import UnityEngineParticleSystemColorOverLifetimeModule
from . UnityEngineParticleSystemCollisionModule import UnityEngineParticleSystemCollisionModule
from . UnityEngineParticleSystemShapeModule import UnityEngineParticleSystemShapeModule
from . UnityEngineParticleSystemSizeOverLifetimeModule import UnityEngineParticleSystemSizeOverLifetimeModule
from . UnityEngineParticleSystemColorBySpeedModule import UnityEngineParticleSystemColorBySpeedModule
from . UnityEngineParticleSystemParticleArray import UnityEngineParticleSystemParticleArray
from . UnityEngineParticleSystemForceOverLifetimeModule import UnityEngineParticleSystemForceOverLifetimeModule
from . UnityEngineParticleSystemInheritVelocityModule import UnityEngineParticleSystemInheritVelocityModule
from . SystemString import SystemString
from . UnityEngineParticleSystemTriggerModule import UnityEngineParticleSystemTriggerModule
from . UnityEngineParticleSystemNoiseModule import UnityEngineParticleSystemNoiseModule
from . UnityEngineParticleSystemParticleRef import UnityEngineParticleSystemParticleRef
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineParticleSystem import UnityEngineParticleSystem


class UnityEngineParticleSystem:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystem:
        return UnityEngineParticleSystem

    @staticmethod
    def Clear(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Clear() -> None:
        return 

    @staticmethod
    def Emit(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Emit(input_1: UnityEngineParticleSystemEmitParams, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineParticleSystem, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineParticleSystem, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineParticleSystem, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineParticleSystem, input_1: T) -> None:
        return 

    @staticmethod
    def GetCustomParticleData(input_1: SystemCollectionsGenericListUnityEngineVector4, input_2: UnityEngineParticleSystemCustomData) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetParticles(input_1: UnityEngineParticleSystemParticleArray, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetParticles(input_1: UnityEngineParticleSystemParticleArray, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetParticles(input_1: UnityEngineParticleSystemParticleArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsAlive(input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsAlive() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Pause(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Pause() -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Play() -> None:
        return 

    @staticmethod
    def SetCustomParticleData(input_1: SystemCollectionsGenericListUnityEngineVector4, input_2: UnityEngineParticleSystemCustomData) -> None:
        return 

    @staticmethod
    def SetParticles(input_1: UnityEngineParticleSystemParticleArray, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetParticles(input_1: UnityEngineParticleSystemParticleArray, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetParticles(input_1: UnityEngineParticleSystemParticleArray) -> None:
        return 

    @staticmethod
    def Simulate(input_1: Union[SystemSingle, int, float], input_2: Union[SystemBoolean, bool], input_3: Union[SystemBoolean, bool], input_4: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Simulate(input_1: Union[SystemSingle, int, float], input_2: Union[SystemBoolean, bool], input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Simulate(input_1: Union[SystemSingle, int, float], input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Simulate(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Stop(input_1: Union[SystemBoolean, bool], input_2: UnityEngineParticleSystemStopBehavior) -> None:
        return 

    @staticmethod
    def Stop(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Stop() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TriggerSubEmitter(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def TriggerSubEmitter(input_1: Union[SystemInt32, int], input_2: UnityEngineParticleSystemParticleRef) -> None:
        return 

    @staticmethod
    def TriggerSubEmitter(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineParticleSystemParticle) -> None:
        return 

    @staticmethod
    def get_collision() -> UnityEngineParticleSystemCollisionModule:
        return UnityEngineParticleSystemCollisionModule

    @staticmethod
    def get_colorBySpeed() -> UnityEngineParticleSystemColorBySpeedModule:
        return UnityEngineParticleSystemColorBySpeedModule

    @staticmethod
    def get_colorOverLifetime() -> UnityEngineParticleSystemColorOverLifetimeModule:
        return UnityEngineParticleSystemColorOverLifetimeModule

    @staticmethod
    def get_customData() -> UnityEngineParticleSystemCustomDataModule:
        return UnityEngineParticleSystemCustomDataModule

    @staticmethod
    def get_emission() -> UnityEngineParticleSystemEmissionModule:
        return UnityEngineParticleSystemEmissionModule

    @staticmethod
    def get_externalForces() -> UnityEngineParticleSystemExternalForcesModule:
        return UnityEngineParticleSystemExternalForcesModule

    @staticmethod
    def get_forceOverLifetime() -> UnityEngineParticleSystemForceOverLifetimeModule:
        return UnityEngineParticleSystemForceOverLifetimeModule

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_inheritVelocity() -> UnityEngineParticleSystemInheritVelocityModule:
        return UnityEngineParticleSystemInheritVelocityModule

    @staticmethod
    def get_isEmitting() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isPaused() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isPlaying() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isStopped() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lights() -> UnityEngineParticleSystemLightsModule:
        return UnityEngineParticleSystemLightsModule

    @staticmethod
    def get_limitVelocityOverLifetime() -> UnityEngineParticleSystemLimitVelocityOverLifetimeModule:
        return UnityEngineParticleSystemLimitVelocityOverLifetimeModule

    @staticmethod
    def get_main() -> UnityEngineParticleSystemMainModule:
        return UnityEngineParticleSystemMainModule

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_noise() -> UnityEngineParticleSystemNoiseModule:
        return UnityEngineParticleSystemNoiseModule

    @staticmethod
    def get_particleCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_proceduralSimulationSupported() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_randomSeed() -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def get_rotationBySpeed() -> UnityEngineParticleSystemRotationBySpeedModule:
        return UnityEngineParticleSystemRotationBySpeedModule

    @staticmethod
    def get_rotationOverLifetime() -> UnityEngineParticleSystemRotationOverLifetimeModule:
        return UnityEngineParticleSystemRotationOverLifetimeModule

    @staticmethod
    def get_shape() -> UnityEngineParticleSystemShapeModule:
        return UnityEngineParticleSystemShapeModule

    @staticmethod
    def get_sizeBySpeed() -> UnityEngineParticleSystemSizeBySpeedModule:
        return UnityEngineParticleSystemSizeBySpeedModule

    @staticmethod
    def get_sizeOverLifetime() -> UnityEngineParticleSystemSizeOverLifetimeModule:
        return UnityEngineParticleSystemSizeOverLifetimeModule

    @staticmethod
    def get_subEmitters() -> UnityEngineParticleSystemSubEmittersModule:
        return UnityEngineParticleSystemSubEmittersModule

    @staticmethod
    def get_textureSheetAnimation() -> UnityEngineParticleSystemTextureSheetAnimationModule:
        return UnityEngineParticleSystemTextureSheetAnimationModule

    @staticmethod
    def get_time() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_trails() -> UnityEngineParticleSystemTrailModule:
        return UnityEngineParticleSystemTrailModule

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_trigger() -> UnityEngineParticleSystemTriggerModule:
        return UnityEngineParticleSystemTriggerModule

    @staticmethod
    def get_useAutoRandomSeed() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_velocityOverLifetime() -> UnityEngineParticleSystemVelocityOverLifetimeModule:
        return UnityEngineParticleSystemVelocityOverLifetimeModule

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_randomSeed(input_1: SystemUInt32) -> None:
        return 

    @staticmethod
    def set_time(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_useAutoRandomSeed(input_1: Union[SystemBoolean, bool]) -> None:
        return 
