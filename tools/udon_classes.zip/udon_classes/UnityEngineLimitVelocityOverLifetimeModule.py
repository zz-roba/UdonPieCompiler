from typing import Union
from typing import Any

from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemSingle import SystemSingle
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemSimulationSpace import UnityEngineParticleSystemSimulationSpace
from . UnityEngineLimitVelocityOverLifetimeModule import UnityEngineLimitVelocityOverLifetimeModule


class UnityEngineLimitVelocityOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineLimitVelocityOverLifetimeModule:
        return UnityEngineLimitVelocityOverLifetimeModule

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_dampen() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_drag() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_dragMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_limit() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_limitMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_limitX() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_limitXMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_limitY() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_limitYMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_limitZ() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_limitZMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_multiplyDragByParticleSize() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_multiplyDragByParticleVelocity() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_separateAxes() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_space() -> UnityEngineParticleSystemSimulationSpace:
        return UnityEngineParticleSystemSimulationSpace

    @staticmethod
    def set_dampen(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_drag(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_dragMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_limit(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_limitMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_limitX(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_limitXMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_limitY(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_limitYMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_limitZ(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_limitZMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_multiplyDragByParticleSize(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_multiplyDragByParticleVelocity(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_separateAxes(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_space(input_1: UnityEngineParticleSystemSimulationSpace) -> None:
        return 
