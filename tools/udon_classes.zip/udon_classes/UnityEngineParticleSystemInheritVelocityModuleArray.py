from typing import Any

from . UnityEngineParticleSystemInheritVelocityModuleArray import UnityEngineParticleSystemInheritVelocityModuleArray


class UnityEngineParticleSystemInheritVelocityModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemInheritVelocityModuleArray:
        return UnityEngineParticleSystemInheritVelocityModuleArray
