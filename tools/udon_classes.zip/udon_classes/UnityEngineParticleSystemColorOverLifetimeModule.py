from typing import Any

from . UnityEngineParticleSystemColorOverLifetimeModule import UnityEngineParticleSystemColorOverLifetimeModule


class UnityEngineParticleSystemColorOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemColorOverLifetimeModule:
        return UnityEngineParticleSystemColorOverLifetimeModule
