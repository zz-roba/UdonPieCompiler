from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient
from . UnityEngineParticleSystemColorOverLifetimeModule import UnityEngineParticleSystemColorOverLifetimeModule
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemColorOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemColorOverLifetimeModule:
        return UnityEngineParticleSystemColorOverLifetimeModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_color() -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_color(input_1: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 
