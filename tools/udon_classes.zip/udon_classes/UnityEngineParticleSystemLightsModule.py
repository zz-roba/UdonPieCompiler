from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . SystemString import SystemString
from . UnityEngineLight import UnityEngineLight
from . UnityEngineParticleSystemLightsModule import UnityEngineParticleSystemLightsModule
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemLightsModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemLightsModule:
        return UnityEngineParticleSystemLightsModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_alphaAffectsIntensity() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_intensity() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_intensityMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_light() -> UnityEngineLight:
        return UnityEngineLight

    @staticmethod
    def get_maxLights() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_range() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_rangeMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_ratio() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_sizeAffectsRange() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_useParticleColor() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_useRandomDistribution() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_alphaAffectsIntensity(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_intensity(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_intensityMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_light(input_1: UnityEngineLight) -> None:
        return 

    @staticmethod
    def set_maxLights(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_range(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_rangeMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_ratio(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_sizeAffectsRange(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_useParticleColor(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_useRandomDistribution(input_1: Union[SystemBoolean, bool]) -> None:
        return 
