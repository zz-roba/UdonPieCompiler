from typing import Any

from . UnityEngineParticleSystemLightsModule import UnityEngineParticleSystemLightsModule


class UnityEngineParticleSystemLightsModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemLightsModule:
        return UnityEngineParticleSystemLightsModule
