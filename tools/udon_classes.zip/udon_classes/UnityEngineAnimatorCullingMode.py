from typing import Any

from . UnityEngineAnimatorCullingMode import UnityEngineAnimatorCullingMode


class UnityEngineAnimatorCullingMode:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorCullingMode:
        return UnityEngineAnimatorCullingMode
