from typing import Any

from . UnityEngineAINavMeshObstacleShape import UnityEngineAINavMeshObstacleShape


class UnityEngineAINavMeshObstacleShape:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshObstacleShape:
        return UnityEngineAINavMeshObstacleShape
