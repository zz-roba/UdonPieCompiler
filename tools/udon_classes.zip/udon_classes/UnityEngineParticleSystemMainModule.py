from typing import Any

from . UnityEngineParticleSystemMainModule import UnityEngineParticleSystemMainModule


class UnityEngineParticleSystemMainModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMainModule:
        return UnityEngineParticleSystemMainModule
