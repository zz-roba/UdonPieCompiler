from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineParticleSystemCullingMode import UnityEngineParticleSystemCullingMode
from . SystemObject import SystemObject
from . SystemSingle import SystemSingle
from . UnityEngineParticleSystemScalingMode import UnityEngineParticleSystemScalingMode
from . UnityEngineParticleSystemStopAction import UnityEngineParticleSystemStopAction
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMainModule import UnityEngineParticleSystemMainModule
from . UnityEngineParticleSystemRingBufferMode import UnityEngineParticleSystemRingBufferMode
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient
from . UnityEngineParticleSystemEmitterVelocityMode import UnityEngineParticleSystemEmitterVelocityMode
from . SystemString import SystemString
from . UnityEngineParticleSystemSimulationSpace import UnityEngineParticleSystemSimulationSpace
from . UnityEngineVector2 import UnityEngineVector2
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemMainModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMainModule:
        return UnityEngineParticleSystemMainModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_cullingMode() -> UnityEngineParticleSystemCullingMode:
        return UnityEngineParticleSystemCullingMode

    @staticmethod
    def get_customSimulationSpace() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_duration() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_emitterVelocityMode() -> UnityEngineParticleSystemEmitterVelocityMode:
        return UnityEngineParticleSystemEmitterVelocityMode

    @staticmethod
    def get_flipRotation() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_gravityModifier() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_gravityModifierMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_loop() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_maxParticles() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_playOnAwake() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_prewarm() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_ringBufferLoopRange() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_ringBufferMode() -> UnityEngineParticleSystemRingBufferMode:
        return UnityEngineParticleSystemRingBufferMode

    @staticmethod
    def get_scalingMode() -> UnityEngineParticleSystemScalingMode:
        return UnityEngineParticleSystemScalingMode

    @staticmethod
    def get_simulationSpace() -> UnityEngineParticleSystemSimulationSpace:
        return UnityEngineParticleSystemSimulationSpace

    @staticmethod
    def get_simulationSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startColor() -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_startDelay() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startDelayMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startLifetime() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startLifetimeMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startRotation() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startRotation3D() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_startRotationMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startRotationX() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startRotationXMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startRotationY() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startRotationYMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startRotationZ() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startRotationZMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSize() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startSize3D() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_startSizeMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSizeX() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startSizeXMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSizeY() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startSizeYMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSizeZ() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startSizeZMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_startSpeed() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_startSpeedMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_stopAction() -> UnityEngineParticleSystemStopAction:
        return UnityEngineParticleSystemStopAction

    @staticmethod
    def get_useUnscaledTime() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_cullingMode(input_1: UnityEngineParticleSystemCullingMode) -> None:
        return 

    @staticmethod
    def set_customSimulationSpace(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def set_duration(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_emitterVelocityMode(input_1: UnityEngineParticleSystemEmitterVelocityMode) -> None:
        return 

    @staticmethod
    def set_flipRotation(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_gravityModifier(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_gravityModifierMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_loop(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_maxParticles(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_playOnAwake(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_prewarm(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_ringBufferLoopRange(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_ringBufferMode(input_1: UnityEngineParticleSystemRingBufferMode) -> None:
        return 

    @staticmethod
    def set_scalingMode(input_1: UnityEngineParticleSystemScalingMode) -> None:
        return 

    @staticmethod
    def set_simulationSpace(input_1: UnityEngineParticleSystemSimulationSpace) -> None:
        return 

    @staticmethod
    def set_simulationSpeed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startColor(input_1: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def set_startDelay(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startDelayMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startLifetime(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startLifetimeMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startRotation(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startRotation3D(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_startRotationMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startRotationX(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startRotationXMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startRotationY(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startRotationYMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startRotationZ(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startRotationZMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSize(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startSize3D(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_startSizeMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSizeX(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startSizeXMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSizeY(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startSizeYMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSizeZ(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startSizeZMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_startSpeed(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_startSpeedMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_stopAction(input_1: UnityEngineParticleSystemStopAction) -> None:
        return 

    @staticmethod
    def set_useUnscaledTime(input_1: Union[SystemBoolean, bool]) -> None:
        return 
