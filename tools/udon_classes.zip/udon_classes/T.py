from typing import Any

from . T import T


class T:

    def __new__(cls, input_1: Any) -> T:
        return T
