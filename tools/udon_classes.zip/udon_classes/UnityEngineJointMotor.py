from typing import Any

from . UnityEngineJointMotor import UnityEngineJointMotor


class UnityEngineJointMotor:

    def __new__(cls, input_1: Any) -> UnityEngineJointMotor:
        return UnityEngineJointMotor
