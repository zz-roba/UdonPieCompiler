from typing import Any

from . SystemIFormatProvider import SystemIFormatProvider


class SystemIFormatProvider:

    def __new__(cls, input_1: Any) -> SystemIFormatProvider:
        return SystemIFormatProvider
