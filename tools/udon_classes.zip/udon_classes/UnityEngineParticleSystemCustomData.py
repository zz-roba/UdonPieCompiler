from typing import Any

from . UnityEngineParticleSystemCustomData import UnityEngineParticleSystemCustomData


class UnityEngineParticleSystemCustomData:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCustomData:
        return UnityEngineParticleSystemCustomData
