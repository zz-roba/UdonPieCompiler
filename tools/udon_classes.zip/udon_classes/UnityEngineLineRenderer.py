from typing import Union
from typing import Any

from . UnityEngineAnimationCurve import UnityEngineAnimationCurve
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineLineAlignment import UnityEngineLineAlignment
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineBounds import UnityEngineBounds
from . UnityEngineMotionVectorGenerationMode import UnityEngineMotionVectorGenerationMode
from . UnityEngineLineRenderer import UnityEngineLineRenderer
from . UnityEngineColor import UnityEngineColor
from . SystemCollectionsGenericListUnityEngineMaterial import SystemCollectionsGenericListUnityEngineMaterial
from . SystemBoolean import SystemBoolean
from . UnityEngineRenderingReflectionProbeUsage import UnityEngineRenderingReflectionProbeUsage
from . UnityEngineMaterialPropertyBlock import UnityEngineMaterialPropertyBlock
from . UnityEngineRenderingLightProbeUsage import UnityEngineRenderingLightProbeUsage
from . UnityEngineMaterial import UnityEngineMaterial
from . UnityEngineMatrix4x4 import UnityEngineMatrix4x4
from . UnityEngineLineTextureMode import UnityEngineLineTextureMode
from . SystemUInt32 import SystemUInt32
from . SystemInt32 import SystemInt32
from . T import T
from . UnityEngineMaterialArray import UnityEngineMaterialArray
from . UnityEngineMesh import UnityEngineMesh
from . UnityEngineRenderingShadowCastingMode import UnityEngineRenderingShadowCastingMode
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo import SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineVector3Array import UnityEngineVector3Array
from . UnityEngineGradient import UnityEngineGradient
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . SystemString import SystemString
from . UnityEngineCamera import UnityEngineCamera
from . UnityEngineVector4 import UnityEngineVector4
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject


class UnityEngineLineRenderer:

    def __new__(cls, input_1: Any) -> UnityEngineLineRenderer:
        return UnityEngineLineRenderer

    @staticmethod
    def BakeMesh(input_1: UnityEngineMesh, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def BakeMesh(input_1: UnityEngineMesh, input_2: UnityEngineCamera, input_3: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetClosestReflectionProbes(input_1: SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineLineRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineLineRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineLineRenderer, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineLineRenderer, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMaterials(input_1: SystemCollectionsGenericListUnityEngineMaterial) -> None:
        return 

    @staticmethod
    def GetPosition(input_1: Union[SystemInt32, int]) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def GetPositions(input_1: UnityEngineVector3Array) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetPropertyBlock(input_1: UnityEngineMaterialPropertyBlock) -> None:
        return 

    @staticmethod
    def GetPropertyBlock(input_1: UnityEngineMaterialPropertyBlock, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def GetSharedMaterials(input_1: SystemCollectionsGenericListUnityEngineMaterial) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def HasPropertyBlock() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetPosition(input_1: Union[SystemInt32, int], input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetPositions(input_1: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def SetPropertyBlock(input_1: UnityEngineMaterialPropertyBlock) -> None:
        return 

    @staticmethod
    def SetPropertyBlock(input_1: UnityEngineMaterialPropertyBlock, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Simplify(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_alignment() -> UnityEngineLineAlignment:
        return UnityEngineLineAlignment

    @staticmethod
    def get_allowOcclusionWhenDynamic() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_bounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_colorGradient() -> UnityEngineGradient:
        return UnityEngineGradient

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_endColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_endWidth() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_generateLightingData() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isPartOfStaticBatch() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isVisible() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lightProbeProxyVolumeOverride() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_lightProbeUsage() -> UnityEngineRenderingLightProbeUsage:
        return UnityEngineRenderingLightProbeUsage

    @staticmethod
    def get_lightmapIndex() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_lightmapScaleOffset() -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def get_localToWorldMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_loop() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_material() -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def get_materials() -> UnityEngineMaterialArray:
        return UnityEngineMaterialArray

    @staticmethod
    def get_motionVectorGenerationMode() -> UnityEngineMotionVectorGenerationMode:
        return UnityEngineMotionVectorGenerationMode

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_numCapVertices() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_numCornerVertices() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_positionCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_probeAnchor() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_realtimeLightmapIndex() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_realtimeLightmapScaleOffset() -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def get_receiveShadows() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_reflectionProbeUsage() -> UnityEngineRenderingReflectionProbeUsage:
        return UnityEngineRenderingReflectionProbeUsage

    @staticmethod
    def get_rendererPriority() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_renderingLayerMask() -> SystemUInt32:
        return SystemUInt32

    @staticmethod
    def get_shadowBias() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shadowCastingMode() -> UnityEngineRenderingShadowCastingMode:
        return UnityEngineRenderingShadowCastingMode

    @staticmethod
    def get_sharedMaterial() -> UnityEngineMaterial:
        return UnityEngineMaterial

    @staticmethod
    def get_sharedMaterials() -> UnityEngineMaterialArray:
        return UnityEngineMaterialArray

    @staticmethod
    def get_sortingLayerID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_sortingLayerName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_sortingOrder() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_startColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_startWidth() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_textureMode() -> UnityEngineLineTextureMode:
        return UnityEngineLineTextureMode

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_useWorldSpace() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_widthCurve() -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve

    @staticmethod
    def get_widthMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_worldToLocalMatrix() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_alignment(input_1: UnityEngineLineAlignment) -> None:
        return 

    @staticmethod
    def set_allowOcclusionWhenDynamic(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_colorGradient(input_1: UnityEngineGradient) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_endColor(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_endWidth(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_generateLightingData(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_lightProbeProxyVolumeOverride(input_1: UnityEngineGameObject) -> None:
        return 

    @staticmethod
    def set_lightProbeUsage(input_1: UnityEngineRenderingLightProbeUsage) -> None:
        return 

    @staticmethod
    def set_lightmapIndex(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_lightmapScaleOffset(input_1: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def set_loop(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_material(input_1: UnityEngineMaterial) -> None:
        return 

    @staticmethod
    def set_materials(input_1: UnityEngineMaterialArray) -> None:
        return 

    @staticmethod
    def set_motionVectorGenerationMode(input_1: UnityEngineMotionVectorGenerationMode) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_numCapVertices(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_numCornerVertices(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_positionCount(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_probeAnchor(input_1: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def set_realtimeLightmapIndex(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_realtimeLightmapScaleOffset(input_1: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def set_receiveShadows(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_reflectionProbeUsage(input_1: UnityEngineRenderingReflectionProbeUsage) -> None:
        return 

    @staticmethod
    def set_rendererPriority(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_renderingLayerMask(input_1: SystemUInt32) -> None:
        return 

    @staticmethod
    def set_shadowBias(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_shadowCastingMode(input_1: UnityEngineRenderingShadowCastingMode) -> None:
        return 

    @staticmethod
    def set_sharedMaterial(input_1: UnityEngineMaterial) -> None:
        return 

    @staticmethod
    def set_sharedMaterials(input_1: UnityEngineMaterialArray) -> None:
        return 

    @staticmethod
    def set_sortingLayerID(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_sortingLayerName(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_sortingOrder(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_startColor(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_startWidth(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_textureMode(input_1: UnityEngineLineTextureMode) -> None:
        return 

    @staticmethod
    def set_useWorldSpace(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_widthCurve(input_1: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def set_widthMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 
