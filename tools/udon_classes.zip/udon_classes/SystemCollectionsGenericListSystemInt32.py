from typing import Any

from . SystemCollectionsGenericListSystemInt32 import SystemCollectionsGenericListSystemInt32


class SystemCollectionsGenericListSystemInt32:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListSystemInt32:
        return SystemCollectionsGenericListSystemInt32
