from typing import Any

from . SystemStringSplitOptions import SystemStringSplitOptions


class SystemStringSplitOptions:

    def __new__(cls, input_1: Any) -> SystemStringSplitOptions:
        return SystemStringSplitOptions
