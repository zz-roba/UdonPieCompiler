from typing import Any

from . UnityEngineParticleSystemNoiseModule import UnityEngineParticleSystemNoiseModule


class UnityEngineParticleSystemNoiseModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemNoiseModule:
        return UnityEngineParticleSystemNoiseModule
