from typing import Any

from . UnityEngineParticleSystemMinMaxGradientArray import UnityEngineParticleSystemMinMaxGradientArray


class UnityEngineParticleSystemMinMaxGradientArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMinMaxGradientArray:
        return UnityEngineParticleSystemMinMaxGradientArray
