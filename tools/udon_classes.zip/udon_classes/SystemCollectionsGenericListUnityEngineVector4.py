from typing import Any

from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4


class SystemCollectionsGenericListUnityEngineVector4:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineVector4:
        return SystemCollectionsGenericListUnityEngineVector4
