from typing import Any

from . SystemDecimal import SystemDecimal


class SystemDecimal:

    def __new__(cls, input_1: Any) -> SystemDecimal:
        return SystemDecimal
