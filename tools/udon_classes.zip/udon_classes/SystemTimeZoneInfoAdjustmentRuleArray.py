from typing import Any

from . SystemTimeZoneInfoAdjustmentRuleArray import SystemTimeZoneInfoAdjustmentRuleArray


class SystemTimeZoneInfoAdjustmentRuleArray:

    def __new__(cls, input_1: Any) -> SystemTimeZoneInfoAdjustmentRuleArray:
        return SystemTimeZoneInfoAdjustmentRuleArray
