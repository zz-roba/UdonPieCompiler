from typing import Any

from . SystemGuid import SystemGuid


class SystemGuid:

    def __new__(cls, input_1: Any) -> SystemGuid:
        return SystemGuid
