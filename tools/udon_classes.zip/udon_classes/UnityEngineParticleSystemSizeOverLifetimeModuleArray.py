from typing import Any

from . UnityEngineParticleSystemSizeOverLifetimeModuleArray import UnityEngineParticleSystemSizeOverLifetimeModuleArray


class UnityEngineParticleSystemSizeOverLifetimeModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSizeOverLifetimeModuleArray:
        return UnityEngineParticleSystemSizeOverLifetimeModuleArray
