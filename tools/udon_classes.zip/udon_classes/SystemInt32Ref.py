from typing import Any

from . SystemInt32Ref import SystemInt32Ref


class SystemInt32Ref:

    def __new__(cls, input_1: Any) -> SystemInt32Ref:
        return SystemInt32Ref
