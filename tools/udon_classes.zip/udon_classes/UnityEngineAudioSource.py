from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . ListT import ListT
from . UnityEngineAudioRolloffMode import UnityEngineAudioRolloffMode
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineAudioVelocityUpdateMode import UnityEngineAudioVelocityUpdateMode
from . SystemInt32 import SystemInt32
from . UnityEngineAudioClip import UnityEngineAudioClip
from . T import T
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . SystemDouble import SystemDouble
from . SystemBoolean import SystemBoolean
from . UnityEngineAudioSource import UnityEngineAudioSource
from . UnityEngineAudioSourceCurveType import UnityEngineAudioSourceCurveType
from . UnityEngineAnimationCurve import UnityEngineAnimationCurve
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineObject import UnityEngineObject
from . SystemSingleRef import SystemSingleRef
from . SystemObject import SystemObject
from . SystemSingleArray import SystemSingleArray
from . UnityEngineFFTWindow import UnityEngineFFTWindow
from . SystemString import SystemString
from . SystemUInt64 import SystemUInt64


class UnityEngineAudioSource:

    def __new__(cls, input_1: Any) -> UnityEngineAudioSource:
        return UnityEngineAudioSource

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAmbisonicDecoderFloat(input_1: Union[SystemInt32, int], input_2: SystemSingleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAudioSource, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAudioSource, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAudioSource, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAudioSource, input_1: T) -> None:
        return 

    @staticmethod
    def GetCustomCurve(input_1: UnityEngineAudioSourceCurveType) -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetOutputData(input_1: SystemSingleArray, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def GetSpatializerFloat(input_1: Union[SystemInt32, int], input_2: SystemSingleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetSpectrumData(input_1: SystemSingleArray, input_2: Union[SystemInt32, int], input_3: UnityEngineFFTWindow) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Pause() -> None:
        return 

    @staticmethod
    def Play(input_1: SystemUInt64) -> None:
        return 

    @staticmethod
    def Play() -> None:
        return 

    @staticmethod
    def PlayClipAtPoint(input_0: UnityEngineAudioClip, input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def PlayClipAtPoint(input_0: UnityEngineAudioClip, input_1: UnityEngineVector3, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def PlayDelayed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def PlayOneShot(input_1: UnityEngineAudioClip) -> None:
        return 

    @staticmethod
    def PlayOneShot(input_1: UnityEngineAudioClip, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def PlayScheduled(input_1: SystemDouble) -> None:
        return 

    @staticmethod
    def SetAmbisonicDecoderFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetCustomCurve(input_1: UnityEngineAudioSourceCurveType, input_2: UnityEngineAnimationCurve) -> None:
        return 

    @staticmethod
    def SetScheduledEndTime(input_1: SystemDouble) -> None:
        return 

    @staticmethod
    def SetScheduledStartTime(input_1: SystemDouble) -> None:
        return 

    @staticmethod
    def SetSpatializerFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Stop() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def UnPause() -> None:
        return 

    @staticmethod
    def get_bypassReverbZones() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_clip() -> UnityEngineAudioClip:
        return UnityEngineAudioClip

    @staticmethod
    def get_dopplerLevel() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_isPlaying() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isVirtual() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_loop() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_maxDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_minDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mute() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_panStereo() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_pitch() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_playOnAwake() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_priority() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_reverbZoneMix() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rolloffMode() -> UnityEngineAudioRolloffMode:
        return UnityEngineAudioRolloffMode

    @staticmethod
    def get_spatialBlend() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_spatialize() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_spatializePostEffects() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_spread() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_time() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_timeSamples() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_velocityUpdateMode() -> UnityEngineAudioVelocityUpdateMode:
        return UnityEngineAudioVelocityUpdateMode

    @staticmethod
    def get_volume() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_bypassReverbZones(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_clip(input_1: UnityEngineAudioClip) -> None:
        return 

    @staticmethod
    def set_dopplerLevel(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_loop(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_maxDistance(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_minDistance(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mute(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_panStereo(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_pitch(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_playOnAwake(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_priority(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_reverbZoneMix(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_rolloffMode(input_1: UnityEngineAudioRolloffMode) -> None:
        return 

    @staticmethod
    def set_spatialBlend(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_spatialize(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_spatializePostEffects(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_spread(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_time(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_timeSamples(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_velocityUpdateMode(input_1: UnityEngineAudioVelocityUpdateMode) -> None:
        return 

    @staticmethod
    def set_volume(input_1: Union[SystemSingle, int, float]) -> None:
        return 
