from typing import Any

from . UnityEngineParticleSystemSimulationSpace import UnityEngineParticleSystemSimulationSpace


class UnityEngineParticleSystemSimulationSpace:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSimulationSpace:
        return UnityEngineParticleSystemSimulationSpace
