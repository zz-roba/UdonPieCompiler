from typing import Union
from typing import Any

from . UnityEngineObject import UnityEngineObject
from . UnityEngineVector3 import UnityEngineVector3
from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineColor import UnityEngineColor
from . SystemInt32 import SystemInt32
from . SystemException import SystemException
from . SystemString import SystemString
from . UnityEngineDebug import UnityEngineDebug
from . SystemObjectArray import SystemObjectArray
from . SystemBoolean import SystemBoolean


class UnityEngineDebug:

    def __new__(cls, input_1: Any) -> UnityEngineDebug:
        return UnityEngineDebug

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool], input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool], input_1: SystemObject) -> None:
        return 

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool], input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool], input_1: SystemObject, input_2: UnityEngineObject) -> None:
        return 

    @staticmethod
    def Assert(input_0: Union[SystemBoolean, bool], input_1: Union[SystemString, str], input_2: UnityEngineObject) -> None:
        return 

    @staticmethod
    def AssertFormat(input_0: Union[SystemBoolean, bool], input_1: Union[SystemString, str], input_2: SystemObjectArray) -> None:
        return 

    @staticmethod
    def AssertFormat(input_0: Union[SystemBoolean, bool], input_1: UnityEngineObject, input_2: Union[SystemString, str], input_3: SystemObjectArray) -> None:
        return 

    @staticmethod
    def DebugBreak() -> None:
        return 

    @staticmethod
    def DrawLine(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor, input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def DrawLine(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def DrawLine(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def DrawLine(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor, input_3: Union[SystemSingle, int, float], input_4: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def DrawRay(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor, input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def DrawRay(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def DrawRay(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def DrawRay(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineColor, input_3: Union[SystemSingle, int, float], input_4: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Log(input_0: SystemObject) -> None:
        return 

    @staticmethod
    def Log(input_0: SystemObject, input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def LogAssertion(input_0: SystemObject) -> None:
        return 

    @staticmethod
    def LogAssertion(input_0: SystemObject, input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def LogAssertionFormat(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogAssertionFormat(input_0: UnityEngineObject, input_1: Union[SystemString, str], input_2: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogError(input_0: SystemObject) -> None:
        return 

    @staticmethod
    def LogError(input_0: SystemObject, input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def LogErrorFormat(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogErrorFormat(input_0: UnityEngineObject, input_1: Union[SystemString, str], input_2: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogException(input_0: SystemException) -> None:
        return 

    @staticmethod
    def LogException(input_0: SystemException, input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def LogFormat(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogFormat(input_0: UnityEngineObject, input_1: Union[SystemString, str], input_2: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogWarning(input_0: SystemObject) -> None:
        return 

    @staticmethod
    def LogWarning(input_0: SystemObject, input_1: UnityEngineObject) -> None:
        return 

    @staticmethod
    def LogWarningFormat(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> None:
        return 

    @staticmethod
    def LogWarningFormat(input_0: UnityEngineObject, input_1: Union[SystemString, str], input_2: SystemObjectArray) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineDebug:
        return UnityEngineDebug

    @staticmethod
    def get_developerConsoleVisible() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_developerConsoleVisible(input_0: Union[SystemBoolean, bool]) -> None:
        return 
