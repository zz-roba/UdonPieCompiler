from typing import Any

from . UnityEngineParticleSystemCullingMode import UnityEngineParticleSystemCullingMode


class UnityEngineParticleSystemCullingMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCullingMode:
        return UnityEngineParticleSystemCullingMode
