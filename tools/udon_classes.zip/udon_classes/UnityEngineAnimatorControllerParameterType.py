from typing import Any

from . UnityEngineAnimatorControllerParameterType import UnityEngineAnimatorControllerParameterType


class UnityEngineAnimatorControllerParameterType:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorControllerParameterType:
        return UnityEngineAnimatorControllerParameterType
