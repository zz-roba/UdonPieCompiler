from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . SystemCollectionsGenericListUnityEngineAnimatorClipInfo import SystemCollectionsGenericListUnityEngineAnimatorClipInfo
from . UnityEngineAnimatorControllerParameter import UnityEngineAnimatorControllerParameter
from . UnityEngineQuaternion import UnityEngineQuaternion
from . UnityEngineRuntimeAnimatorController import UnityEngineRuntimeAnimatorController
from . UnityEngineAvatarIKGoal import UnityEngineAvatarIKGoal
from . SystemBoolean import SystemBoolean
from . UnityEngineAnimator import UnityEngineAnimator
from . UnityEngineAnimatorTransitionInfo import UnityEngineAnimatorTransitionInfo
from . UnityEngineAvatarIKHint import UnityEngineAvatarIKHint
from . T import T
from . SystemInt32 import SystemInt32
from . UnityEngineAnimatorRecorderMode import UnityEngineAnimatorRecorderMode
from . UnityEngineMatchTargetWeightMask import UnityEngineMatchTargetWeightMask
from . ListT import ListT
from . UnityEngineAnimatorStateInfo import UnityEngineAnimatorStateInfo
from . SystemObject import SystemObject
from . UnityEngineObject import UnityEngineObject
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineHumanBodyBones import UnityEngineHumanBodyBones
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . UnityEngineAnimatorCullingMode import UnityEngineAnimatorCullingMode
from . UnityEngineAnimatorClipInfoArray import UnityEngineAnimatorClipInfoArray
from . UnityEngineAnimatorUpdateMode import UnityEngineAnimatorUpdateMode
from . UnityEngineAnimatorControllerParameterArray import UnityEngineAnimatorControllerParameterArray
from . SystemString import SystemString
from . UnityEngineAvatarTarget import UnityEngineAvatarTarget
from . UnityEnginePlayablesPlayableGraph import UnityEnginePlayablesPlayableGraph
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineAvatar import UnityEngineAvatar


class UnityEngineAnimator:

    def __new__(cls, input_1: Any) -> UnityEngineAnimator:
        return UnityEngineAnimator

    @staticmethod
    def ApplyBuiltinRootMotion() -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CrossFade(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def CrossFadeInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetAnimatorTransitionInfo(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorTransitionInfo:
        return UnityEngineAnimatorTransitionInfo

    @staticmethod
    def GetBool(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetBool(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimator, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimator, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimator, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimator, input_1: T) -> None:
        return 

    @staticmethod
    def GetCurrentAnimatorClipInfo(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorClipInfoArray:
        return UnityEngineAnimatorClipInfoArray

    @staticmethod
    def GetCurrentAnimatorClipInfo(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineAnimatorClipInfo) -> None:
        return 

    @staticmethod
    def GetCurrentAnimatorClipInfoCount(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetCurrentAnimatorStateInfo(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorStateInfo:
        return UnityEngineAnimatorStateInfo

    @staticmethod
    def GetFloat(input_1: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetFloat(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetIKHintPosition(input_1: UnityEngineAvatarIKHint) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def GetIKHintPositionWeight(input_1: UnityEngineAvatarIKHint) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetIKPosition(input_1: UnityEngineAvatarIKGoal) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def GetIKPositionWeight(input_1: UnityEngineAvatarIKGoal) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetIKRotation(input_1: UnityEngineAvatarIKGoal) -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def GetIKRotationWeight(input_1: UnityEngineAvatarIKGoal) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInteger(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInteger(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetLayerIndex(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetLayerName(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetLayerWeight(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetNextAnimatorClipInfo(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorClipInfoArray:
        return UnityEngineAnimatorClipInfoArray

    @staticmethod
    def GetNextAnimatorClipInfo(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineAnimatorClipInfo) -> None:
        return 

    @staticmethod
    def GetNextAnimatorClipInfoCount(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetNextAnimatorStateInfo(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorStateInfo:
        return UnityEngineAnimatorStateInfo

    @staticmethod
    def GetParameter(input_1: Union[SystemInt32, int]) -> UnityEngineAnimatorControllerParameter:
        return UnityEngineAnimatorControllerParameter

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def HasState(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def InterruptMatchTarget() -> None:
        return 

    @staticmethod
    def InterruptMatchTarget(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def IsInTransition(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsParameterControlledByCurve(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsParameterControlledByCurve(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def MatchTarget(input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: UnityEngineAvatarTarget, input_4: UnityEngineMatchTargetWeightMask, input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def MatchTarget(input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: UnityEngineAvatarTarget, input_4: UnityEngineMatchTargetWeightMask, input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Play(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def PlayInFixedTime(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Rebind() -> None:
        return 

    @staticmethod
    def ResetTrigger(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def ResetTrigger(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetBoneLocalRotation(input_1: UnityEngineHumanBodyBones, input_2: UnityEngineQuaternion) -> None:
        return 

    @staticmethod
    def SetBool(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetBool(input_1: Union[SystemInt32, int], input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetIKHintPosition(input_1: UnityEngineAvatarIKHint, input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetIKHintPositionWeight(input_1: UnityEngineAvatarIKHint, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetIKPosition(input_1: UnityEngineAvatarIKGoal, input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetIKPositionWeight(input_1: UnityEngineAvatarIKGoal, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetIKRotation(input_1: UnityEngineAvatarIKGoal, input_2: UnityEngineQuaternion) -> None:
        return 

    @staticmethod
    def SetIKRotationWeight(input_1: UnityEngineAvatarIKGoal, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetInteger(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetInteger(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetLayerWeight(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetLookAtPosition(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetLookAtWeight(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetLookAtWeight(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetLookAtWeight(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetLookAtWeight(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetLookAtWeight(input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetTarget(input_1: UnityEngineAvatarTarget, input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetTrigger(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def SetTrigger(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def StartPlayback() -> None:
        return 

    @staticmethod
    def StartRecording(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def StopPlayback() -> None:
        return 

    @staticmethod
    def StopRecording() -> None:
        return 

    @staticmethod
    def StringToHash(input_0: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def WriteDefaultValues() -> None:
        return 

    @staticmethod
    def get_angularVelocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_applyRootMotion() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_avatar() -> UnityEngineAvatar:
        return UnityEngineAvatar

    @staticmethod
    def get_bodyPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_bodyRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_cullingMode() -> UnityEngineAnimatorCullingMode:
        return UnityEngineAnimatorCullingMode

    @staticmethod
    def get_deltaPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_deltaRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_feetPivotActive() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_gravityWeight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_hasBoundPlayables() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasRootMotion() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_hasTransformHierarchy() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_humanScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_isHuman() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isInitialized() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isMatchingTarget() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_isOptimizable() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_keepAnimatorControllerStateOnDisable() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_layerCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_layersAffectMassCenter() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_leftFeetBottomHeight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_logWarnings() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_parameterCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_parameters() -> UnityEngineAnimatorControllerParameterArray:
        return UnityEngineAnimatorControllerParameterArray

    @staticmethod
    def get_pivotPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_pivotWeight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_playableGraph() -> UnityEnginePlayablesPlayableGraph:
        return UnityEnginePlayablesPlayableGraph

    @staticmethod
    def get_playbackTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_recorderMode() -> UnityEngineAnimatorRecorderMode:
        return UnityEngineAnimatorRecorderMode

    @staticmethod
    def get_recorderStartTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_recorderStopTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rightFeetBottomHeight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rootPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_rootRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_runtimeAnimatorController() -> UnityEngineRuntimeAnimatorController:
        return UnityEngineRuntimeAnimatorController

    @staticmethod
    def get_speed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_stabilizeFeet() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_targetPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_targetRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_updateMode() -> UnityEngineAnimatorUpdateMode:
        return UnityEngineAnimatorUpdateMode

    @staticmethod
    def get_velocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_applyRootMotion(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_avatar(input_1: UnityEngineAvatar) -> None:
        return 

    @staticmethod
    def set_bodyPosition(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_bodyRotation(input_1: UnityEngineQuaternion) -> None:
        return 

    @staticmethod
    def set_cullingMode(input_1: UnityEngineAnimatorCullingMode) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_feetPivotActive(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_keepAnimatorControllerStateOnDisable(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_layersAffectMassCenter(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_logWarnings(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_playbackTime(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_recorderStartTime(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_recorderStopTime(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_rootPosition(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_rootRotation(input_1: UnityEngineQuaternion) -> None:
        return 

    @staticmethod
    def set_runtimeAnimatorController(input_1: UnityEngineRuntimeAnimatorController) -> None:
        return 

    @staticmethod
    def set_speed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_stabilizeFeet(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_updateMode(input_1: UnityEngineAnimatorUpdateMode) -> None:
        return 
