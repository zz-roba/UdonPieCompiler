from typing import Any

from . UnityEngineParticleSystemMeshShapeType import UnityEngineParticleSystemMeshShapeType


class UnityEngineParticleSystemMeshShapeType:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemMeshShapeType:
        return UnityEngineParticleSystemMeshShapeType
