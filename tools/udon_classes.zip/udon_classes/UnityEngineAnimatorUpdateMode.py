from typing import Any

from . UnityEngineAnimatorUpdateMode import UnityEngineAnimatorUpdateMode


class UnityEngineAnimatorUpdateMode:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorUpdateMode:
        return UnityEngineAnimatorUpdateMode
