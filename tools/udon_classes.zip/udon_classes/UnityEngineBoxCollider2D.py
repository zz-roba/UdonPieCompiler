from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineCompositeCollider2D import UnityEngineCompositeCollider2D
from . SystemSingle import SystemSingle
from . UnityEngineColliderDistance2D import UnityEngineColliderDistance2D
from . ListT import ListT
from . UnityEngineRaycastHit2DArray import UnityEngineRaycastHit2DArray
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineContactFilter2D import UnityEngineContactFilter2D
from . SystemInt32 import SystemInt32
from . UnityEnginePhysicsMaterial2D import UnityEnginePhysicsMaterial2D
from . T import T
from . UnityEngineCollider2D import UnityEngineCollider2D
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . SystemBoolean import SystemBoolean
from . UnityEngineBoxCollider2D import UnityEngineBoxCollider2D
from . UnityEngineRigidbody2D import UnityEngineRigidbody2D
from . UnityEngineBounds import UnityEngineBounds
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . UnityEngineCollider2DArray import UnityEngineCollider2DArray
from . SystemString import SystemString
from . UnityEngineContactPoint2DArray import UnityEngineContactPoint2DArray


class UnityEngineBoxCollider2D:

    def __new__(cls, input_1: Any) -> UnityEngineBoxCollider2D:
        return UnityEngineBoxCollider2D

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Cast(input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Distance(input_1: UnityEngineCollider2D) -> UnityEngineColliderDistance2D:
        return UnityEngineColliderDistance2D

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineBoxCollider2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineBoxCollider2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineBoxCollider2D, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineBoxCollider2D, input_1: T) -> None:
        return 

    @staticmethod
    def GetContacts(input_1: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_1: UnityEngineContactFilter2D, input_2: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_1: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsTouching(input_1: UnityEngineCollider2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouching(input_1: UnityEngineCollider2D, input_2: UnityEngineContactFilter2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouching(input_1: UnityEngineContactFilter2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouchingLayers() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouchingLayers(input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def OverlapCollider(input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPoint(input_1: UnityEngineVector2) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_attachedRigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_autoTiling() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_bounciness() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_bounds() -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_composite() -> UnityEngineCompositeCollider2D:
        return UnityEngineCompositeCollider2D

    @staticmethod
    def get_density() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_edgeRadius() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_friction() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_isTrigger() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_offset() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_shapeCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_sharedMaterial() -> UnityEnginePhysicsMaterial2D:
        return UnityEnginePhysicsMaterial2D

    @staticmethod
    def get_size() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_usedByComposite() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_usedByEffector() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_autoTiling(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_density(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_edgeRadius(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_isTrigger(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_offset(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_sharedMaterial(input_1: UnityEnginePhysicsMaterial2D) -> None:
        return 

    @staticmethod
    def set_size(input_1: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_usedByComposite(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_usedByEffector(input_1: Union[SystemBoolean, bool]) -> None:
        return 
