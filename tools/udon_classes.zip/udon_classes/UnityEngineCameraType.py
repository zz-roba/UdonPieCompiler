from typing import Any

from . UnityEngineCameraType import UnityEngineCameraType


class UnityEngineCameraType:

    def __new__(cls, input_1: Any) -> UnityEngineCameraType:
        return UnityEngineCameraType
