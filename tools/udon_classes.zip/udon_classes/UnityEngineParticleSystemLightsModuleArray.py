from typing import Any

from . UnityEngineParticleSystemLightsModuleArray import UnityEngineParticleSystemLightsModuleArray


class UnityEngineParticleSystemLightsModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemLightsModuleArray:
        return UnityEngineParticleSystemLightsModuleArray
