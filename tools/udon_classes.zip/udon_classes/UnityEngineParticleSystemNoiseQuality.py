from typing import Any

from . UnityEngineParticleSystemNoiseQuality import UnityEngineParticleSystemNoiseQuality


class UnityEngineParticleSystemNoiseQuality:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemNoiseQuality:
        return UnityEngineParticleSystemNoiseQuality
