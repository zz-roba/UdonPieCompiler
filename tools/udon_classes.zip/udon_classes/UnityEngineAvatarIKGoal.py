from typing import Any

from . UnityEngineAvatarIKGoal import UnityEngineAvatarIKGoal


class UnityEngineAvatarIKGoal:

    def __new__(cls, input_1: Any) -> UnityEngineAvatarIKGoal:
        return UnityEngineAvatarIKGoal
