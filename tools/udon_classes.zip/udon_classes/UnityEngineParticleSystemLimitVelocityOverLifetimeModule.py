from typing import Any

from . UnityEngineParticleSystemLimitVelocityOverLifetimeModule import UnityEngineParticleSystemLimitVelocityOverLifetimeModule


class UnityEngineParticleSystemLimitVelocityOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemLimitVelocityOverLifetimeModule:
        return UnityEngineParticleSystemLimitVelocityOverLifetimeModule
