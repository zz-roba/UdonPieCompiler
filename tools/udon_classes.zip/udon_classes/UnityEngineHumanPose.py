from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineHumanPose import UnityEngineHumanPose
from . SystemObject import SystemObject
from . SystemSingleArray import SystemSingleArray
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemBoolean import SystemBoolean


class UnityEngineHumanPose:

    def __new__(cls, input_1: Any) -> UnityEngineHumanPose:
        return UnityEngineHumanPose

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_bodyPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_bodyRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_muscles() -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def set_bodyPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def set_bodyRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def set_muscles() -> SystemSingleArray:
        return SystemSingleArray
