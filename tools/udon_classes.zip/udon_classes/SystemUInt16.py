from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemGlobalizationNumberStyles import SystemGlobalizationNumberStyles
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemUInt16Ref import SystemUInt16Ref
from . SystemUInt16 import SystemUInt16
from . SystemBoolean import SystemBoolean


class SystemUInt16:

    def __new__(cls, input_1: Any) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def CompareTo(input_1: SystemObject) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Parse(input_0: Union[SystemString, str]) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemIFormatProvider) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def Parse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles, input_2: SystemIFormatProvider) -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str], input_2: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemUInt16Ref) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemGlobalizationNumberStyles, input_2: SystemIFormatProvider, input_3: SystemUInt16Ref) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_MaxValue() -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def get_MinValue() -> SystemUInt16:
        return SystemUInt16

    @staticmethod
    def op_Addition(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Division(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Equality(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThan(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThanOrEqual(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LeftShift(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LessThan(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThanOrEqual(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LogicalAnd(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LogicalOr(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LogicalXor(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Multiplication(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_RightShift(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Subtraction(input_0: SystemUInt16, input_1: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_UnaryMinus(input_0: SystemUInt16) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]
