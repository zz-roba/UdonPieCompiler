from typing import Any

from . UnityEngineCameraClearFlags import UnityEngineCameraClearFlags


class UnityEngineCameraClearFlags:

    def __new__(cls, input_1: Any) -> UnityEngineCameraClearFlags:
        return UnityEngineCameraClearFlags
