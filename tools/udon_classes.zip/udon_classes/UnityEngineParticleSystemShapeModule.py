from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineParticleSystemShapeMultiModeValue import UnityEngineParticleSystemShapeMultiModeValue
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineMesh import UnityEngineMesh
from . UnityEngineParticleSystemShapeType import UnityEngineParticleSystemShapeType
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemShapeTextureChannel import UnityEngineParticleSystemShapeTextureChannel
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineSkinnedMeshRenderer import UnityEngineSkinnedMeshRenderer
from . UnityEngineMeshRenderer import UnityEngineMeshRenderer
from . UnityEngineSprite import UnityEngineSprite
from . SystemString import SystemString
from . UnityEngineSpriteRenderer import UnityEngineSpriteRenderer
from . UnityEngineTexture2D import UnityEngineTexture2D
from . UnityEngineParticleSystemMeshShapeType import UnityEngineParticleSystemMeshShapeType
from . UnityEngineParticleSystemShapeModule import UnityEngineParticleSystemShapeModule
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemShapeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemShapeModule:
        return UnityEngineParticleSystemShapeModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_alignToDirection() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_angle() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_arc() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_arcMode() -> UnityEngineParticleSystemShapeMultiModeValue:
        return UnityEngineParticleSystemShapeMultiModeValue

    @staticmethod
    def get_arcSpeed() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_arcSpeedMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_arcSpread() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_boxThickness() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_donutRadius() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_length() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mesh() -> UnityEngineMesh:
        return UnityEngineMesh

    @staticmethod
    def get_meshMaterialIndex() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_meshRenderer() -> UnityEngineMeshRenderer:
        return UnityEngineMeshRenderer

    @staticmethod
    def get_meshShapeType() -> UnityEngineParticleSystemMeshShapeType:
        return UnityEngineParticleSystemMeshShapeType

    @staticmethod
    def get_meshSpawnMode() -> UnityEngineParticleSystemShapeMultiModeValue:
        return UnityEngineParticleSystemShapeMultiModeValue

    @staticmethod
    def get_meshSpawnSpeed() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_meshSpawnSpeedMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_meshSpawnSpread() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_normalOffset() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_position() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_radius() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_radiusMode() -> UnityEngineParticleSystemShapeMultiModeValue:
        return UnityEngineParticleSystemShapeMultiModeValue

    @staticmethod
    def get_radiusSpeed() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_radiusSpeedMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_radiusSpread() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_radiusThickness() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_randomDirectionAmount() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_randomPositionAmount() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rotation() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_scale() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_shapeType() -> UnityEngineParticleSystemShapeType:
        return UnityEngineParticleSystemShapeType

    @staticmethod
    def get_skinnedMeshRenderer() -> UnityEngineSkinnedMeshRenderer:
        return UnityEngineSkinnedMeshRenderer

    @staticmethod
    def get_sphericalDirectionAmount() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_sprite() -> UnityEngineSprite:
        return UnityEngineSprite

    @staticmethod
    def get_spriteRenderer() -> UnityEngineSpriteRenderer:
        return UnityEngineSpriteRenderer

    @staticmethod
    def get_texture() -> UnityEngineTexture2D:
        return UnityEngineTexture2D

    @staticmethod
    def get_textureAlphaAffectsParticles() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_textureBilinearFiltering() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_textureClipChannel() -> UnityEngineParticleSystemShapeTextureChannel:
        return UnityEngineParticleSystemShapeTextureChannel

    @staticmethod
    def get_textureClipThreshold() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_textureColorAffectsParticles() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_textureUVChannel() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_useMeshColors() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_useMeshMaterialIndex() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_alignToDirection(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_angle(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_arc(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_arcMode(input_1: UnityEngineParticleSystemShapeMultiModeValue) -> None:
        return 

    @staticmethod
    def set_arcSpeed(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_arcSpeedMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_arcSpread(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_boxThickness(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_donutRadius(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_length(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mesh(input_1: UnityEngineMesh) -> None:
        return 

    @staticmethod
    def set_meshMaterialIndex(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_meshRenderer(input_1: UnityEngineMeshRenderer) -> None:
        return 

    @staticmethod
    def set_meshShapeType(input_1: UnityEngineParticleSystemMeshShapeType) -> None:
        return 

    @staticmethod
    def set_meshSpawnMode(input_1: UnityEngineParticleSystemShapeMultiModeValue) -> None:
        return 

    @staticmethod
    def set_meshSpawnSpeed(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_meshSpawnSpeedMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_meshSpawnSpread(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_normalOffset(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_position(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_radius(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_radiusMode(input_1: UnityEngineParticleSystemShapeMultiModeValue) -> None:
        return 

    @staticmethod
    def set_radiusSpeed(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_radiusSpeedMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_radiusSpread(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_radiusThickness(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_randomDirectionAmount(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_randomPositionAmount(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_rotation(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_scale(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_shapeType(input_1: UnityEngineParticleSystemShapeType) -> None:
        return 

    @staticmethod
    def set_skinnedMeshRenderer(input_1: UnityEngineSkinnedMeshRenderer) -> None:
        return 

    @staticmethod
    def set_sphericalDirectionAmount(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_sprite(input_1: UnityEngineSprite) -> None:
        return 

    @staticmethod
    def set_spriteRenderer(input_1: UnityEngineSpriteRenderer) -> None:
        return 

    @staticmethod
    def set_texture(input_1: UnityEngineTexture2D) -> None:
        return 

    @staticmethod
    def set_textureAlphaAffectsParticles(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_textureBilinearFiltering(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_textureClipChannel(input_1: UnityEngineParticleSystemShapeTextureChannel) -> None:
        return 

    @staticmethod
    def set_textureClipThreshold(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_textureColorAffectsParticles(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_textureUVChannel(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_useMeshColors(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_useMeshMaterialIndex(input_1: Union[SystemBoolean, bool]) -> None:
        return 
