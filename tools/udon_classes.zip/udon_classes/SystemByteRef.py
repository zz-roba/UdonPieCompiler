from typing import Any

from . SystemByteRef import SystemByteRef


class SystemByteRef:

    def __new__(cls, input_1: Any) -> SystemByteRef:
        return SystemByteRef
