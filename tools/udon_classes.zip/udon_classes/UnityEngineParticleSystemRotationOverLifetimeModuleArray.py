from typing import Any

from . UnityEngineParticleSystemRotationOverLifetimeModuleArray import UnityEngineParticleSystemRotationOverLifetimeModuleArray


class UnityEngineParticleSystemRotationOverLifetimeModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemRotationOverLifetimeModuleArray:
        return UnityEngineParticleSystemRotationOverLifetimeModuleArray
