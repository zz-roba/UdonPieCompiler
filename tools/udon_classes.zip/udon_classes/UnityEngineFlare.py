from typing import Any

from . UnityEngineFlare import UnityEngineFlare


class UnityEngineFlare:

    def __new__(cls, input_1: Any) -> UnityEngineFlare:
        return UnityEngineFlare
