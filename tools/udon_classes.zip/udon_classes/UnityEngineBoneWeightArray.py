from typing import Any

from . UnityEngineBoneWeightArray import UnityEngineBoneWeightArray


class UnityEngineBoneWeightArray:

    def __new__(cls, input_1: Any) -> UnityEngineBoneWeightArray:
        return UnityEngineBoneWeightArray
