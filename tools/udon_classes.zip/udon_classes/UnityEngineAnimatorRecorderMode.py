from typing import Any

from . UnityEngineAnimatorRecorderMode import UnityEngineAnimatorRecorderMode


class UnityEngineAnimatorRecorderMode:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorRecorderMode:
        return UnityEngineAnimatorRecorderMode
