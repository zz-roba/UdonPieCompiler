from typing import Any

from . UnityEngineForceMode import UnityEngineForceMode


class UnityEngineForceMode:

    def __new__(cls, input_1: Any) -> UnityEngineForceMode:
        return UnityEngineForceMode
