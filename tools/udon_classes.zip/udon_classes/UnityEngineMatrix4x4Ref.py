from typing import Any

from . UnityEngineMatrix4x4Ref import UnityEngineMatrix4x4Ref


class UnityEngineMatrix4x4Ref:

    def __new__(cls, input_1: Any) -> UnityEngineMatrix4x4Ref:
        return UnityEngineMatrix4x4Ref
