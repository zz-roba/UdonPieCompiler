from typing import Any

from . SystemDateTimeRef import SystemDateTimeRef


class SystemDateTimeRef:

    def __new__(cls, input_1: Any) -> SystemDateTimeRef:
        return SystemDateTimeRef
