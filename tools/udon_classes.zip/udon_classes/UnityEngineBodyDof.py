from typing import Any

from . UnityEngineBodyDof import UnityEngineBodyDof


class UnityEngineBodyDof:

    def __new__(cls, input_1: Any) -> UnityEngineBodyDof:
        return UnityEngineBodyDof
