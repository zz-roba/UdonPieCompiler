from typing import Union
from typing import Any

from . SystemDouble import SystemDouble
from . SystemGlobalizationUnicodeCategory import SystemGlobalizationUnicodeCategory
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemCharRef import SystemCharRef
from . SystemString import SystemString
from . SystemChar import SystemChar
from . SystemGlobalizationCultureInfo import SystemGlobalizationCultureInfo
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class SystemChar:

    def __new__(cls, input_1: Any) -> SystemChar:
        return SystemChar

    @staticmethod
    def CompareTo(input_1: Union[SystemObject, Any]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ConvertFromUtf32(input_0: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ConvertToUtf32(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def ConvertToUtf32(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetNumericValue(input_0: SystemChar) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def GetNumericValue(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemDouble:
        return SystemDouble

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetUnicodeCategory(input_0: SystemChar) -> SystemGlobalizationUnicodeCategory:
        return SystemGlobalizationUnicodeCategory

    @staticmethod
    def GetUnicodeCategory(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> SystemGlobalizationUnicodeCategory:
        return SystemGlobalizationUnicodeCategory

    @staticmethod
    def IsControl(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsControl(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsDigit(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsDigit(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsHighSurrogate(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsHighSurrogate(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLetter(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLetter(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLetterOrDigit(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLetterOrDigit(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLowSurrogate(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLowSurrogate(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLower(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsLower(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNumber(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNumber(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsPunctuation(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsPunctuation(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSeparator(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSeparator(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSurrogate(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSurrogate(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSurrogatePair(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSurrogatePair(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSymbol(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsSymbol(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsUpper(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsUpper(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsWhiteSpace(input_0: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsWhiteSpace(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Parse(input_0: Union[SystemString, str]) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToLower(input_0: SystemChar, input_1: SystemGlobalizationCultureInfo) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToLower(input_0: SystemChar) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToLowerInvariant(input_0: SystemChar) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_0: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUpper(input_0: SystemChar, input_1: SystemGlobalizationCultureInfo) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToUpper(input_0: SystemChar) -> SystemChar:
        return SystemChar

    @staticmethod
    def ToUpperInvariant(input_0: SystemChar) -> SystemChar:
        return SystemChar

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemCharRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_MaxValue() -> SystemChar:
        return SystemChar

    @staticmethod
    def get_MinValue() -> SystemChar:
        return SystemChar

    @staticmethod
    def op_Addition(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Division(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Equality(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThan(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_GreaterThanOrEqual(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LeftShift(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LessThan(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LessThanOrEqual(input_0: SystemChar, input_1: SystemChar) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LogicalAnd(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LogicalOr(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_LogicalXor(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Multiplication(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_RightShift(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Subtraction(input_0: SystemChar, input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_UnaryMinus(input_0: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]
