from typing import Any

from . SystemCollectionsGenericListUnityEngineMatrix4x4 import SystemCollectionsGenericListUnityEngineMatrix4x4


class SystemCollectionsGenericListUnityEngineMatrix4x4:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineMatrix4x4:
        return SystemCollectionsGenericListUnityEngineMatrix4x4
