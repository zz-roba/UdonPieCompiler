from typing import Union
from typing import Any

from . UnityEngineCollisionModule import UnityEngineCollisionModule
from . UnityEngineParticleSystemCollisionQuality import UnityEngineParticleSystemCollisionQuality
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineLayerMask import UnityEngineLayerMask
from . SystemString import SystemString
from . UnityEngineParticleSystemCollisionType import UnityEngineParticleSystemCollisionType
from . UnityEngineParticleSystemCollisionMode import UnityEngineParticleSystemCollisionMode
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class UnityEngineCollisionModule:

    def __new__(cls, input_1: Any) -> UnityEngineCollisionModule:
        return UnityEngineCollisionModule

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetPlane(input_1: Union[SystemInt32, int]) -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def SetPlane(input_1: Union[SystemInt32, int], input_2: UnityEngineTransform) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_bounce() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_bounceMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_colliderForce() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_collidesWith() -> UnityEngineLayerMask:
        return UnityEngineLayerMask

    @staticmethod
    def get_dampen() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_dampenMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enableDynamicColliders() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lifetimeLoss() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_lifetimeLossMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxCollisionShapes() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_maxKillSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxPlaneCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_minKillSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemCollisionMode:
        return UnityEngineParticleSystemCollisionMode

    @staticmethod
    def get_multiplyColliderForceByCollisionAngle() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_multiplyColliderForceByParticleSize() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_multiplyColliderForceByParticleSpeed() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_quality() -> UnityEngineParticleSystemCollisionQuality:
        return UnityEngineParticleSystemCollisionQuality

    @staticmethod
    def get_radiusScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_sendCollisionMessages() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_type() -> UnityEngineParticleSystemCollisionType:
        return UnityEngineParticleSystemCollisionType

    @staticmethod
    def get_voxelSize() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_bounce(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_bounceMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_colliderForce(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_collidesWith(input_1: UnityEngineLayerMask) -> None:
        return 

    @staticmethod
    def set_dampen(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_dampenMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enableDynamicColliders(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_lifetimeLoss(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_lifetimeLossMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxCollisionShapes(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_maxKillSpeed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_minKillSpeed(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemCollisionMode) -> None:
        return 

    @staticmethod
    def set_multiplyColliderForceByCollisionAngle(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_multiplyColliderForceByParticleSize(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_multiplyColliderForceByParticleSpeed(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_quality(input_1: UnityEngineParticleSystemCollisionQuality) -> None:
        return 

    @staticmethod
    def set_radiusScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_sendCollisionMessages(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_type(input_1: UnityEngineParticleSystemCollisionType) -> None:
        return 

    @staticmethod
    def set_voxelSize(input_1: Union[SystemSingle, int, float]) -> None:
        return 
