from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . UnityEngineObject import UnityEngineObject
from . SystemInt32 import SystemInt32
from . T import T
from . UnityEngineJoint import UnityEngineJoint
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . SystemString import SystemString
from . ListT import ListT
from . UnityEngineRigidbody import UnityEngineRigidbody
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineComponent import UnityEngineComponent
from . SystemBoolean import SystemBoolean


class UnityEngineJoint:

    def __new__(cls, input_1: Any) -> UnityEngineJoint:
        return UnityEngineJoint

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_anchor() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_autoConfigureConnectedAnchor() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_axis() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_breakForce() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_breakTorque() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_connectedAnchor() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_connectedBody() -> UnityEngineRigidbody:
        return UnityEngineRigidbody

    @staticmethod
    def get_connectedMassScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_currentForce() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_currentTorque() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_enableCollision() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enablePreprocessing() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_massScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_anchor(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_autoConfigureConnectedAnchor(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_axis(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_breakForce(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_breakTorque(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_connectedAnchor(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_connectedBody(input_1: UnityEngineRigidbody) -> None:
        return 

    @staticmethod
    def set_connectedMassScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enableCollision(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enablePreprocessing(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_massScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 
