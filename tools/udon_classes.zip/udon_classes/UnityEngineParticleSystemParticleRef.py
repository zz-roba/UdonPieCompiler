from typing import Any

from . UnityEngineParticleSystemParticleRef import UnityEngineParticleSystemParticleRef


class UnityEngineParticleSystemParticleRef:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemParticleRef:
        return UnityEngineParticleSystemParticleRef
