from typing import Any

from . UnityEngineEventSystemsPointerEventData import UnityEngineEventSystemsPointerEventData


class UnityEngineEventSystemsPointerEventData:

    def __new__(cls, input_1: Any) -> UnityEngineEventSystemsPointerEventData:
        return UnityEngineEventSystemsPointerEventData
