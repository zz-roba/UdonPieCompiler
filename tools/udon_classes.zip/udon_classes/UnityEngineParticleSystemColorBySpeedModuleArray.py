from typing import Any

from . UnityEngineParticleSystemColorBySpeedModuleArray import UnityEngineParticleSystemColorBySpeedModuleArray


class UnityEngineParticleSystemColorBySpeedModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemColorBySpeedModuleArray:
        return UnityEngineParticleSystemColorBySpeedModuleArray
