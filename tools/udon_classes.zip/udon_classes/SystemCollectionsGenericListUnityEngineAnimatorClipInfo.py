from typing import Any

from . SystemCollectionsGenericListUnityEngineAnimatorClipInfo import SystemCollectionsGenericListUnityEngineAnimatorClipInfo


class SystemCollectionsGenericListUnityEngineAnimatorClipInfo:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineAnimatorClipInfo:
        return SystemCollectionsGenericListUnityEngineAnimatorClipInfo
