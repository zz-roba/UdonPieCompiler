from typing import Any

from . UnityEngineCubemap import UnityEngineCubemap


class UnityEngineCubemap:

    def __new__(cls, input_1: Any) -> UnityEngineCubemap:
        return UnityEngineCubemap
