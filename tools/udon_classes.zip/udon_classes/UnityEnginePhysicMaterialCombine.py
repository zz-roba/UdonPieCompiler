from typing import Any

from . UnityEnginePhysicMaterialCombine import UnityEnginePhysicMaterialCombine


class UnityEnginePhysicMaterialCombine:

    def __new__(cls, input_1: Any) -> UnityEnginePhysicMaterialCombine:
        return UnityEnginePhysicMaterialCombine
