from typing import Any

from . UnityEngineJointLimits import UnityEngineJointLimits


class UnityEngineJointLimits:

    def __new__(cls, input_1: Any) -> UnityEngineJointLimits:
        return UnityEngineJointLimits
