from typing import Any

from . UnityEngineCombineInstanceArray import UnityEngineCombineInstanceArray


class UnityEngineCombineInstanceArray:

    def __new__(cls, input_1: Any) -> UnityEngineCombineInstanceArray:
        return UnityEngineCombineInstanceArray
