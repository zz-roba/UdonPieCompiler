from typing import Any

from . UnityEngineCameraGateFitMode import UnityEngineCameraGateFitMode


class UnityEngineCameraGateFitMode:

    def __new__(cls, input_1: Any) -> UnityEngineCameraGateFitMode:
        return UnityEngineCameraGateFitMode
