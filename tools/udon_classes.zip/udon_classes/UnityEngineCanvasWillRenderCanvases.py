from typing import Any

from . UnityEngineCanvasWillRenderCanvases import UnityEngineCanvasWillRenderCanvases


class UnityEngineCanvasWillRenderCanvases:

    def __new__(cls, input_1: Any) -> UnityEngineCanvasWillRenderCanvases:
        return UnityEngineCanvasWillRenderCanvases
