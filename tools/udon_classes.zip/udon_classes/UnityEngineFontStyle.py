from typing import Any

from . UnityEngineFontStyle import UnityEngineFontStyle


class UnityEngineFontStyle:

    def __new__(cls, input_1: Any) -> UnityEngineFontStyle:
        return UnityEngineFontStyle
