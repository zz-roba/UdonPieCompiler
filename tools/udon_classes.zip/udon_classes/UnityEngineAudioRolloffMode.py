from typing import Any

from . UnityEngineAudioRolloffMode import UnityEngineAudioRolloffMode


class UnityEngineAudioRolloffMode:

    def __new__(cls, input_1: Any) -> UnityEngineAudioRolloffMode:
        return UnityEngineAudioRolloffMode
