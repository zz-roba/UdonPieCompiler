from typing import Any

from . UnityEngineParticleSystemGradientMode import UnityEngineParticleSystemGradientMode


class UnityEngineParticleSystemGradientMode:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemGradientMode:
        return UnityEngineParticleSystemGradientMode
