from typing import Any

from . UnityEngineParticleSystemEmissionModule import UnityEngineParticleSystemEmissionModule


class UnityEngineParticleSystemEmissionModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemEmissionModule:
        return UnityEngineParticleSystemEmissionModule
