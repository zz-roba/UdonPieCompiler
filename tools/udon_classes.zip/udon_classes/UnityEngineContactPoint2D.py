from typing import Union
from typing import Any

from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineContactPoint2D import UnityEngineContactPoint2D
from . SystemString import SystemString
from . UnityEngineRigidbody2D import UnityEngineRigidbody2D
from . UnityEngineVector2 import UnityEngineVector2
from . SystemSingle import SystemSingle
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . UnityEngineCollider2D import UnityEngineCollider2D


class UnityEngineContactPoint2D:

    def __new__(cls, input_1: Any) -> UnityEngineContactPoint2D:
        return UnityEngineContactPoint2D

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_collider() -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_normal() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_normalImpulse() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_otherCollider() -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def get_otherRigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_point() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_relativeVelocity() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_rigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_separation() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_tangentImpulse() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]
