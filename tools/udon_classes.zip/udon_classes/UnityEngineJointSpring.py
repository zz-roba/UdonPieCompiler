from typing import Any

from . UnityEngineJointSpring import UnityEngineJointSpring


class UnityEngineJointSpring:

    def __new__(cls, input_1: Any) -> UnityEngineJointSpring:
        return UnityEngineJointSpring
