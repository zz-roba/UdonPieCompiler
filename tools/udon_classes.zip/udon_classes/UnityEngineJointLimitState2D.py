from typing import Any

from . UnityEngineJointLimitState2D import UnityEngineJointLimitState2D


class UnityEngineJointLimitState2D:

    def __new__(cls, input_1: Any) -> UnityEngineJointLimitState2D:
        return UnityEngineJointLimitState2D
