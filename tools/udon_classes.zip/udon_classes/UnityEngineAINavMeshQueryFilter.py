from typing import Any

from . UnityEngineAINavMeshQueryFilter import UnityEngineAINavMeshQueryFilter


class UnityEngineAINavMeshQueryFilter:

    def __new__(cls, input_1: Any) -> UnityEngineAINavMeshQueryFilter:
        return UnityEngineAINavMeshQueryFilter
