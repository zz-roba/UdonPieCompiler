from typing import Union
from typing import Any

from . UnityEngineContactPoint2DArray import UnityEngineContactPoint2DArray
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . UnityEngineContactPoint2D import UnityEngineContactPoint2D
from . SystemString import SystemString
from . UnityEngineCollision2D import UnityEngineCollision2D
from . UnityEngineRigidbody2D import UnityEngineRigidbody2D
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineTransform import UnityEngineTransform
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . UnityEngineCollider2D import UnityEngineCollider2D


class UnityEngineCollision2D:

    def __new__(cls, input_1: Any) -> UnityEngineCollision2D:
        return UnityEngineCollision2D

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetContact(input_1: Union[SystemInt32, int]) -> UnityEngineContactPoint2D:
        return UnityEngineContactPoint2D

    @staticmethod
    def GetContacts(input_1: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineCollision2D:
        return UnityEngineCollision2D

    @staticmethod
    def get_collider() -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def get_contactCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_contacts() -> UnityEngineContactPoint2DArray:
        return UnityEngineContactPoint2DArray

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_otherCollider() -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def get_otherRigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_relativeVelocity() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_rigidbody() -> UnityEngineRigidbody2D:
        return UnityEngineRigidbody2D

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform
