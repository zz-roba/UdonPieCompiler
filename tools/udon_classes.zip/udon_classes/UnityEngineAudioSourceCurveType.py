from typing import Any

from . UnityEngineAudioSourceCurveType import UnityEngineAudioSourceCurveType


class UnityEngineAudioSourceCurveType:

    def __new__(cls, input_1: Any) -> UnityEngineAudioSourceCurveType:
        return UnityEngineAudioSourceCurveType
