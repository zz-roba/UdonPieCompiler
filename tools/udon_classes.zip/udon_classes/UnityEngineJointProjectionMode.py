from typing import Any

from . UnityEngineJointProjectionMode import UnityEngineJointProjectionMode


class UnityEngineJointProjectionMode:

    def __new__(cls, input_1: Any) -> UnityEngineJointProjectionMode:
        return UnityEngineJointProjectionMode
