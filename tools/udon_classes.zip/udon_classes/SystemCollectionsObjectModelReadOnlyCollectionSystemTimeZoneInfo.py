from typing import Any

from . SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo import SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo


class SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo:

    def __new__(cls, input_1: Any) -> SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo:
        return SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo
