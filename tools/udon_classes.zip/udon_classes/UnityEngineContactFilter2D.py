from typing import Any

from . UnityEngineContactFilter2D import UnityEngineContactFilter2D


class UnityEngineContactFilter2D:

    def __new__(cls, input_1: Any) -> UnityEngineContactFilter2D:
        return UnityEngineContactFilter2D
