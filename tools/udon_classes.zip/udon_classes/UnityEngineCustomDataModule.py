from typing import Union
from typing import Any

from . UnityEngineParticleSystemCustomData import UnityEngineParticleSystemCustomData
from . UnityEngineParticleSystemCustomDataMode import UnityEngineParticleSystemCustomDataMode
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineCustomDataModule import UnityEngineCustomDataModule
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient


class UnityEngineCustomDataModule:

    def __new__(cls, input_1: Any) -> UnityEngineCustomDataModule:
        return UnityEngineCustomDataModule

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetColor(input_1: UnityEngineParticleSystemCustomData) -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMode(input_1: UnityEngineParticleSystemCustomData) -> UnityEngineParticleSystemCustomDataMode:
        return UnityEngineParticleSystemCustomDataMode

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetVector(input_1: UnityEngineParticleSystemCustomData, input_2: Union[SystemInt32, int]) -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def GetVectorComponentCount(input_1: UnityEngineParticleSystemCustomData) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SetColor(input_1: UnityEngineParticleSystemCustomData, input_2: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def SetMode(input_1: UnityEngineParticleSystemCustomData, input_2: UnityEngineParticleSystemCustomDataMode) -> None:
        return 

    @staticmethod
    def SetVector(input_1: UnityEngineParticleSystemCustomData, input_2: Union[SystemInt32, int], input_3: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def SetVectorComponentCount(input_1: UnityEngineParticleSystemCustomData, input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 
