from typing import Union
from typing import Any

from . UnityEngineFrustumPlanes import UnityEngineFrustumPlanes
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineMatrix4x4 import UnityEngineMatrix4x4
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEnginePlane import UnityEnginePlane
from . UnityEngineVector4 import UnityEngineVector4
from . SystemType import SystemType
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemSingle import SystemSingle
from . SystemInt32 import SystemInt32


class UnityEngineMatrix4x4:

    def __new__(cls, input_1: Any) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Determinant(input_0: UnityEngineMatrix4x4) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: UnityEngineMatrix4x4) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Frustum(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Frustum(input_0: UnityEngineFrustumPlanes) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetColumn(input_1: Union[SystemInt32, int]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetRow(input_1: Union[SystemInt32, int]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Inverse(input_0: UnityEngineMatrix4x4) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def LookAt(input_0: UnityEngineVector3, input_1: UnityEngineVector3, input_2: UnityEngineVector3) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def MultiplyPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def MultiplyPoint3x4(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def MultiplyVector(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def Ortho(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Perspective(input_0: Union[SystemSingle, int, float], input_1: Union[SystemSingle, int, float], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Rotate(input_0: UnityEngineQuaternion) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Scale(input_0: UnityEngineVector3) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def SetColumn(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetRow(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetTRS(input_1: UnityEngineVector3, input_2: UnityEngineQuaternion, input_3: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def TRS(input_0: UnityEngineVector3, input_1: UnityEngineQuaternion, input_2: UnityEngineVector3) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TransformPlane(input_1: UnityEnginePlane) -> UnityEnginePlane:
        return UnityEnginePlane

    @staticmethod
    def Translate(input_0: UnityEngineVector3) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def Transpose(input_0: UnityEngineMatrix4x4) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def ValidTRS() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ctor(input_0: UnityEngineVector4, input_1: UnityEngineVector4, input_2: UnityEngineVector4, input_3: UnityEngineVector4) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_Item(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_Item(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_decomposeProjection() -> UnityEngineFrustumPlanes:
        return UnityEngineFrustumPlanes

    @staticmethod
    def get_determinant() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_identity() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_inverse() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_isIdentity() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_lossyScale() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_m00() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m01() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m02() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m03() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m10() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m11() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m12() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m13() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m20() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m21() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m22() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m23() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m30() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m31() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m32() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_m33() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_rotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_transpose() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def get_zero() -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def op_Equality(input_0: UnityEngineMatrix4x4, input_1: UnityEngineMatrix4x4) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineMatrix4x4, input_1: UnityEngineMatrix4x4) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Multiply(input_0: UnityEngineMatrix4x4, input_1: UnityEngineMatrix4x4) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def op_Multiply(input_0: UnityEngineMatrix4x4, input_1: UnityEngineVector4) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def set_Item(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_Item(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_m00() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m01() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m02() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m03() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m10() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m11() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m12() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m13() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m20() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m21() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m22() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m23() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m30() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m31() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m32() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_m33() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]
