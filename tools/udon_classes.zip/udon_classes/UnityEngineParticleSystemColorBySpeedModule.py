from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . UnityEngineParticleSystemColorBySpeedModule import UnityEngineParticleSystemColorBySpeedModule
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxGradient import UnityEngineParticleSystemMinMaxGradient
from . SystemString import SystemString
from . UnityEngineVector2 import UnityEngineVector2
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemColorBySpeedModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemColorBySpeedModule:
        return UnityEngineParticleSystemColorBySpeedModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_color() -> UnityEngineParticleSystemMinMaxGradient:
        return UnityEngineParticleSystemMinMaxGradient

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_range() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def set_color(input_1: UnityEngineParticleSystemMinMaxGradient) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_range(input_1: UnityEngineVector2) -> None:
        return 
