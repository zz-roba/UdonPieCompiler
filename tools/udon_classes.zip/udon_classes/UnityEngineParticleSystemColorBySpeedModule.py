from typing import Any

from . UnityEngineParticleSystemColorBySpeedModule import UnityEngineParticleSystemColorBySpeedModule


class UnityEngineParticleSystemColorBySpeedModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemColorBySpeedModule:
        return UnityEngineParticleSystemColorBySpeedModule
