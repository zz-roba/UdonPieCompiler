from typing import Union
from typing import Any

from . UnityEngineRuntimeAnimatorController import UnityEngineRuntimeAnimatorController
from . UnityEngineAnimatorOverrideController import UnityEngineAnimatorOverrideController
from . UnityEngineObject import UnityEngineObject
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemString import SystemString
from . UnityEngineAnimationClipArray import UnityEngineAnimationClipArray
from . SystemCollectionsGenericIListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip import SystemCollectionsGenericIListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip
from . UnityEngineAnimationClip import UnityEngineAnimationClip
from . SystemType import SystemType
from . SystemInt32 import SystemInt32
from . SystemCollectionsGenericListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip import SystemCollectionsGenericListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip


class UnityEngineAnimatorOverrideController:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorOverrideController:
        return UnityEngineAnimatorOverrideController

    @staticmethod
    def ApplyOverrides(input_1: SystemCollectionsGenericIListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetOverrides(input_1: SystemCollectionsGenericListSystemCollectionsGenericKeyValuePairUnityEngineAnimationClipUnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Item(input_1: Union[SystemString, str]) -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def get_Item(input_1: UnityEngineAnimationClip) -> UnityEngineAnimationClip:
        return UnityEngineAnimationClip

    @staticmethod
    def get_animationClips() -> UnityEngineAnimationClipArray:
        return UnityEngineAnimationClipArray

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_overridesCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_runtimeAnimatorController() -> UnityEngineRuntimeAnimatorController:
        return UnityEngineRuntimeAnimatorController

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_Item(input_1: Union[SystemString, str], input_2: UnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def set_Item(input_1: UnityEngineAnimationClip, input_2: UnityEngineAnimationClip) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_runtimeAnimatorController(input_1: UnityEngineRuntimeAnimatorController) -> None:
        return 
