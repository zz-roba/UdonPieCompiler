from typing import Any

from . UnityEngineParticleSystemInheritVelocityModule import UnityEngineParticleSystemInheritVelocityModule


class UnityEngineParticleSystemInheritVelocityModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemInheritVelocityModule:
        return UnityEngineParticleSystemInheritVelocityModule
