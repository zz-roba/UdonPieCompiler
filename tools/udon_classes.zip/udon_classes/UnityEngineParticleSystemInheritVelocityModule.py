from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineParticleSystemInheritVelocityModule import UnityEngineParticleSystemInheritVelocityModule
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineParticleSystemMinMaxCurve import UnityEngineParticleSystemMinMaxCurve
from . UnityEngineParticleSystemInheritVelocityMode import UnityEngineParticleSystemInheritVelocityMode
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineParticleSystemInheritVelocityModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemInheritVelocityModule:
        return UnityEngineParticleSystemInheritVelocityModule

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_curve() -> UnityEngineParticleSystemMinMaxCurve:
        return UnityEngineParticleSystemMinMaxCurve

    @staticmethod
    def get_curveMultiplier() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_mode() -> UnityEngineParticleSystemInheritVelocityMode:
        return UnityEngineParticleSystemInheritVelocityMode

    @staticmethod
    def set_curve(input_1: UnityEngineParticleSystemMinMaxCurve) -> None:
        return 

    @staticmethod
    def set_curveMultiplier(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_mode(input_1: UnityEngineParticleSystemInheritVelocityMode) -> None:
        return 
