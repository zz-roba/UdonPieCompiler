from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . UnityEngineDurationUnit import UnityEngineDurationUnit
from . UnityEngineAnimatorTransitionInfo import UnityEngineAnimatorTransitionInfo
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineAnimatorTransitionInfo:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorTransitionInfo:
        return UnityEngineAnimatorTransitionInfo

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IsName(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsUserName(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_anyState() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_duration() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_durationUnit() -> UnityEngineDurationUnit:
        return UnityEngineDurationUnit

    @staticmethod
    def get_fullPathHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_nameHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_normalizedTime() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_userNameHash() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]
