from typing import Any

from . UnityEngineCollisionDetectionMode import UnityEngineCollisionDetectionMode


class UnityEngineCollisionDetectionMode:

    def __new__(cls, input_1: Any) -> UnityEngineCollisionDetectionMode:
        return UnityEngineCollisionDetectionMode
