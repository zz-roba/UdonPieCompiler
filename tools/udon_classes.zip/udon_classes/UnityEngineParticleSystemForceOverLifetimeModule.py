from typing import Any

from . UnityEngineParticleSystemForceOverLifetimeModule import UnityEngineParticleSystemForceOverLifetimeModule


class UnityEngineParticleSystemForceOverLifetimeModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemForceOverLifetimeModule:
        return UnityEngineParticleSystemForceOverLifetimeModule
