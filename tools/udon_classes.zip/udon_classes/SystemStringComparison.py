from typing import Any

from . SystemStringComparison import SystemStringComparison


class SystemStringComparison:

    def __new__(cls, input_1: Any) -> SystemStringComparison:
        return SystemStringComparison
