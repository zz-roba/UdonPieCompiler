from typing import Any

from . UnityEngineAudioReverbPreset import UnityEngineAudioReverbPreset


class UnityEngineAudioReverbPreset:

    def __new__(cls, input_1: Any) -> UnityEngineAudioReverbPreset:
        return UnityEngineAudioReverbPreset
