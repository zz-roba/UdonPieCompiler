from typing import Any

from . SystemCollectionsGenericListVRCSDKBaseVRCPlayerApi import SystemCollectionsGenericListVRCSDKBaseVRCPlayerApi


class SystemCollectionsGenericListVRCSDKBaseVRCPlayerApi:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListVRCSDKBaseVRCPlayerApi:
        return SystemCollectionsGenericListVRCSDKBaseVRCPlayerApi
