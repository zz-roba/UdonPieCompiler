from typing import Any

from . UnityEngineCameraGateFitParameters import UnityEngineCameraGateFitParameters


class UnityEngineCameraGateFitParameters:

    def __new__(cls, input_1: Any) -> UnityEngineCameraGateFitParameters:
        return UnityEngineCameraGateFitParameters
