from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineAnimationsConstraintSource import UnityEngineAnimationsConstraintSource
from . UnityEngineComponentArray import UnityEngineComponentArray
from . ListT import ListT
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . T import T
from . SystemCollectionsGenericListUnityEngineAnimationsConstraintSource import SystemCollectionsGenericListUnityEngineAnimationsConstraintSource
from . UnityEngineObject import UnityEngineObject
from . SystemSingle import SystemSingle
from . SystemString import SystemString
from . UnityEngineAnimationsAxis import UnityEngineAnimationsAxis
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineVector3Array import UnityEngineVector3Array
from . UnityEngineTransform import UnityEngineTransform
from . UnityEngineAnimationsParentConstraint import UnityEngineAnimationsParentConstraint
from . SystemType import SystemType
from . SystemInt32 import SystemInt32


class UnityEngineAnimationsParentConstraint:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationsParentConstraint:
        return UnityEngineAnimationsParentConstraint

    @staticmethod
    def AddSource(input_1: UnityEngineAnimationsConstraintSource) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineAnimationsParentConstraint, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetRotationOffset(input_1: Union[SystemInt32, int]) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def GetSource(input_1: Union[SystemInt32, int]) -> UnityEngineAnimationsConstraintSource:
        return UnityEngineAnimationsConstraintSource

    @staticmethod
    def GetSources(input_1: SystemCollectionsGenericListUnityEngineAnimationsConstraintSource) -> None:
        return 

    @staticmethod
    def GetTranslationOffset(input_1: Union[SystemInt32, int]) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def RemoveSource(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetRotationOffset(input_1: Union[SystemInt32, int], input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SetSource(input_1: Union[SystemInt32, int], input_2: UnityEngineAnimationsConstraintSource) -> None:
        return 

    @staticmethod
    def SetSources(input_1: SystemCollectionsGenericListUnityEngineAnimationsConstraintSource) -> None:
        return 

    @staticmethod
    def SetTranslationOffset(input_1: Union[SystemInt32, int], input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_constraintActive() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_locked() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_rotationAtRest() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_rotationAxis() -> UnityEngineAnimationsAxis:
        return UnityEngineAnimationsAxis

    @staticmethod
    def get_rotationOffsets() -> UnityEngineVector3Array:
        return UnityEngineVector3Array

    @staticmethod
    def get_sourceCount() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_translationAtRest() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_translationAxis() -> UnityEngineAnimationsAxis:
        return UnityEngineAnimationsAxis

    @staticmethod
    def get_translationOffsets() -> UnityEngineVector3Array:
        return UnityEngineVector3Array

    @staticmethod
    def get_weight() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_constraintActive(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_locked(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_rotationAtRest(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_rotationAxis(input_1: UnityEngineAnimationsAxis) -> None:
        return 

    @staticmethod
    def set_rotationOffsets(input_1: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def set_translationAtRest(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_translationAxis(input_1: UnityEngineAnimationsAxis) -> None:
        return 

    @staticmethod
    def set_translationOffsets(input_1: UnityEngineVector3Array) -> None:
        return 

    @staticmethod
    def set_weight(input_1: Union[SystemSingle, int, float]) -> None:
        return 
