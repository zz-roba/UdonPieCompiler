from typing import Any

from . UnityEngineAudioClipLoadType import UnityEngineAudioClipLoadType


class UnityEngineAudioClipLoadType:

    def __new__(cls, input_1: Any) -> UnityEngineAudioClipLoadType:
        return UnityEngineAudioClipLoadType
