from typing import Any

from . UnityEngineParticleSystemCollisionQuality import UnityEngineParticleSystemCollisionQuality


class UnityEngineParticleSystemCollisionQuality:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCollisionQuality:
        return UnityEngineParticleSystemCollisionQuality
