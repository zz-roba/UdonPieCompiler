from typing import Any

from . UnityEngineDepthTextureMode import UnityEngineDepthTextureMode


class UnityEngineDepthTextureMode:

    def __new__(cls, input_1: Any) -> UnityEngineDepthTextureMode:
        return UnityEngineDepthTextureMode
