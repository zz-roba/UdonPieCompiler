from typing import Any

from . SystemCollectionsGenericListUnityEngineUIVertex import SystemCollectionsGenericListUnityEngineUIVertex


class SystemCollectionsGenericListUnityEngineUIVertex:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineUIVertex:
        return SystemCollectionsGenericListUnityEngineUIVertex
