from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemTimeZoneInfoAdjustmentRuleArray import SystemTimeZoneInfoAdjustmentRuleArray
from . SystemInt32 import SystemInt32
from . SystemDateTimeOffset import SystemDateTimeOffset
from . SystemTimeSpanArray import SystemTimeSpanArray
from . SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo import SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo
from . SystemDateTime import SystemDateTime
from . SystemString import SystemString
from . SystemTimeZoneInfo import SystemTimeZoneInfo
from . SystemTimeSpan import SystemTimeSpan
from . SystemBoolean import SystemBoolean


class SystemTimeZoneInfo:

    def __new__(cls, input_1: Any) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def ClearCachedData() -> None:
        return 

    @staticmethod
    def ConvertTime(input_0: SystemDateTimeOffset, input_1: SystemTimeZoneInfo) -> SystemDateTimeOffset:
        return SystemDateTimeOffset

    @staticmethod
    def ConvertTime(input_0: SystemDateTime, input_1: SystemTimeZoneInfo) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTime(input_0: SystemDateTime, input_1: SystemTimeZoneInfo, input_2: SystemTimeZoneInfo) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTimeBySystemTimeZoneId(input_0: SystemDateTimeOffset, input_1: Union[SystemString, str]) -> SystemDateTimeOffset:
        return SystemDateTimeOffset

    @staticmethod
    def ConvertTimeBySystemTimeZoneId(input_0: SystemDateTime, input_1: Union[SystemString, str]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTimeBySystemTimeZoneId(input_0: SystemDateTime, input_1: Union[SystemString, str], input_2: Union[SystemString, str]) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTimeFromUtc(input_0: SystemDateTime, input_1: SystemTimeZoneInfo) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTimeToUtc(input_0: SystemDateTime) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def ConvertTimeToUtc(input_0: SystemDateTime, input_1: SystemTimeZoneInfo) -> SystemDateTime:
        return SystemDateTime

    @staticmethod
    def CreateCustomTimeZone(input_0: Union[SystemString, str], input_1: SystemTimeSpan, input_2: Union[SystemString, str], input_3: Union[SystemString, str]) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def CreateCustomTimeZone(input_0: Union[SystemString, str], input_1: SystemTimeSpan, input_2: Union[SystemString, str], input_3: Union[SystemString, str], input_4: Union[SystemString, str], input_5: SystemTimeZoneInfoAdjustmentRuleArray) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def CreateCustomTimeZone(input_0: Union[SystemString, str], input_1: SystemTimeSpan, input_2: Union[SystemString, str], input_3: Union[SystemString, str], input_4: Union[SystemString, str], input_5: SystemTimeZoneInfoAdjustmentRuleArray, input_6: Union[SystemBoolean, bool]) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def Equals(input_1: SystemTimeZoneInfo) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def FindSystemTimeZoneById(input_0: Union[SystemString, str]) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def FromSerializedString(input_0: Union[SystemString, str]) -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def GetAdjustmentRules() -> SystemTimeZoneInfoAdjustmentRuleArray:
        return SystemTimeZoneInfoAdjustmentRuleArray

    @staticmethod
    def GetAmbiguousTimeOffsets(input_1: SystemDateTimeOffset) -> SystemTimeSpanArray:
        return SystemTimeSpanArray

    @staticmethod
    def GetAmbiguousTimeOffsets(input_1: SystemDateTime) -> SystemTimeSpanArray:
        return SystemTimeSpanArray

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetSystemTimeZones() -> SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo:
        return SystemCollectionsObjectModelReadOnlyCollectionSystemTimeZoneInfo

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetUtcOffset(input_1: SystemDateTimeOffset) -> SystemTimeSpan:
        return SystemTimeSpan

    @staticmethod
    def GetUtcOffset(input_1: SystemDateTime) -> SystemTimeSpan:
        return SystemTimeSpan

    @staticmethod
    def HasSameRules(input_1: SystemTimeZoneInfo) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsAmbiguousTime(input_1: SystemDateTimeOffset) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsAmbiguousTime(input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsDaylightSavingTime(input_1: SystemDateTimeOffset) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsDaylightSavingTime(input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsInvalidTime(input_1: SystemDateTime) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToSerializedString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_BaseUtcOffset() -> SystemTimeSpan:
        return SystemTimeSpan

    @staticmethod
    def get_DaylightName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_DisplayName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Id() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Local() -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo

    @staticmethod
    def get_StandardName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_SupportsDaylightSavingTime() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_Utc() -> SystemTimeZoneInfo:
        return SystemTimeZoneInfo
