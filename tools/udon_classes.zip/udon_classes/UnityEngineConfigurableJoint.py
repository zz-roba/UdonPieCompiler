from typing import Union
from typing import Any

from . UnityEngineSoftJointLimit import UnityEngineSoftJointLimit
from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineRotationDriveMode import UnityEngineRotationDriveMode
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineJointDrive import UnityEngineJointDrive
from . UnityEngineJointProjectionMode import UnityEngineJointProjectionMode
from . UnityEngineQuaternion import UnityEngineQuaternion
from . SystemBoolean import SystemBoolean
from . SystemInt32 import SystemInt32
from . T import T
from . UnityEngineConfigurableJoint import UnityEngineConfigurableJoint
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . UnityEngineConfigurableJointMotion import UnityEngineConfigurableJointMotion
from . UnityEngineVector3 import UnityEngineVector3
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . UnityEngineRigidbody import UnityEngineRigidbody
from . SystemString import SystemString
from . UnityEngineGameObject import UnityEngineGameObject
from . SystemType import SystemType
from . UnityEngineSoftJointLimitSpring import UnityEngineSoftJointLimitSpring


class UnityEngineConfigurableJoint:

    def __new__(cls, input_1: Any) -> UnityEngineConfigurableJoint:
        return UnityEngineConfigurableJoint

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineConfigurableJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineConfigurableJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineConfigurableJoint, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineConfigurableJoint, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_anchor() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_angularXDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_angularXLimitSpring() -> UnityEngineSoftJointLimitSpring:
        return UnityEngineSoftJointLimitSpring

    @staticmethod
    def get_angularXMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def get_angularYLimit() -> UnityEngineSoftJointLimit:
        return UnityEngineSoftJointLimit

    @staticmethod
    def get_angularYMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def get_angularYZDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_angularYZLimitSpring() -> UnityEngineSoftJointLimitSpring:
        return UnityEngineSoftJointLimitSpring

    @staticmethod
    def get_angularZLimit() -> UnityEngineSoftJointLimit:
        return UnityEngineSoftJointLimit

    @staticmethod
    def get_angularZMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def get_autoConfigureConnectedAnchor() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_axis() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_breakForce() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_breakTorque() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_configuredInWorldSpace() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_connectedAnchor() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_connectedBody() -> UnityEngineRigidbody:
        return UnityEngineRigidbody

    @staticmethod
    def get_connectedMassScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_currentForce() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_currentTorque() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_enableCollision() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_enablePreprocessing() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_highAngularXLimit() -> UnityEngineSoftJointLimit:
        return UnityEngineSoftJointLimit

    @staticmethod
    def get_linearLimit() -> UnityEngineSoftJointLimit:
        return UnityEngineSoftJointLimit

    @staticmethod
    def get_linearLimitSpring() -> UnityEngineSoftJointLimitSpring:
        return UnityEngineSoftJointLimitSpring

    @staticmethod
    def get_lowAngularXLimit() -> UnityEngineSoftJointLimit:
        return UnityEngineSoftJointLimit

    @staticmethod
    def get_massScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_projectionAngle() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_projectionDistance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_projectionMode() -> UnityEngineJointProjectionMode:
        return UnityEngineJointProjectionMode

    @staticmethod
    def get_rotationDriveMode() -> UnityEngineRotationDriveMode:
        return UnityEngineRotationDriveMode

    @staticmethod
    def get_secondaryAxis() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_slerpDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_swapBodies() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_targetAngularVelocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_targetPosition() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_targetRotation() -> UnityEngineQuaternion:
        return UnityEngineQuaternion

    @staticmethod
    def get_targetVelocity() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_xDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_xMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def get_yDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_yMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def get_zDrive() -> UnityEngineJointDrive:
        return UnityEngineJointDrive

    @staticmethod
    def get_zMotion() -> UnityEngineConfigurableJointMotion:
        return UnityEngineConfigurableJointMotion

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_anchor(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_angularXDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_angularXLimitSpring(input_1: UnityEngineSoftJointLimitSpring) -> None:
        return 

    @staticmethod
    def set_angularXMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 

    @staticmethod
    def set_angularYLimit(input_1: UnityEngineSoftJointLimit) -> None:
        return 

    @staticmethod
    def set_angularYMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 

    @staticmethod
    def set_angularYZDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_angularYZLimitSpring(input_1: UnityEngineSoftJointLimitSpring) -> None:
        return 

    @staticmethod
    def set_angularZLimit(input_1: UnityEngineSoftJointLimit) -> None:
        return 

    @staticmethod
    def set_angularZMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 

    @staticmethod
    def set_autoConfigureConnectedAnchor(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_axis(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_breakForce(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_breakTorque(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_configuredInWorldSpace(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_connectedAnchor(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_connectedBody(input_1: UnityEngineRigidbody) -> None:
        return 

    @staticmethod
    def set_connectedMassScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_enableCollision(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_enablePreprocessing(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_highAngularXLimit(input_1: UnityEngineSoftJointLimit) -> None:
        return 

    @staticmethod
    def set_linearLimit(input_1: UnityEngineSoftJointLimit) -> None:
        return 

    @staticmethod
    def set_linearLimitSpring(input_1: UnityEngineSoftJointLimitSpring) -> None:
        return 

    @staticmethod
    def set_lowAngularXLimit(input_1: UnityEngineSoftJointLimit) -> None:
        return 

    @staticmethod
    def set_massScale(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_projectionAngle(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_projectionDistance(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_projectionMode(input_1: UnityEngineJointProjectionMode) -> None:
        return 

    @staticmethod
    def set_rotationDriveMode(input_1: UnityEngineRotationDriveMode) -> None:
        return 

    @staticmethod
    def set_secondaryAxis(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_slerpDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_swapBodies(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_targetAngularVelocity(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_targetPosition(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_targetRotation(input_1: UnityEngineQuaternion) -> None:
        return 

    @staticmethod
    def set_targetVelocity(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_xDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_xMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 

    @staticmethod
    def set_yDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_yMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 

    @staticmethod
    def set_zDrive(input_1: UnityEngineJointDrive) -> None:
        return 

    @staticmethod
    def set_zMotion(input_1: UnityEngineConfigurableJointMotion) -> None:
        return 
