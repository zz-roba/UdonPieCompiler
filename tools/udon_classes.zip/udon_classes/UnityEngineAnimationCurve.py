from typing import Any

from . UnityEngineAnimationCurve import UnityEngineAnimationCurve


class UnityEngineAnimationCurve:

    def __new__(cls, input_1: Any) -> UnityEngineAnimationCurve:
        return UnityEngineAnimationCurve
