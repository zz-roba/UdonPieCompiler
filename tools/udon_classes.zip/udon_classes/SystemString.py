from typing import Union
from typing import Any

from . SystemIFormatProvider import SystemIFormatProvider
from . SystemChar import SystemChar
from . SystemGlobalizationCultureInfo import SystemGlobalizationCultureInfo
from . SystemBoolean import SystemBoolean
from . SystemCharArray import SystemCharArray
from . SystemGlobalizationCompareOptions import SystemGlobalizationCompareOptions
from . SystemTypeCode import SystemTypeCode
from . SystemInt32 import SystemInt32
from . SystemSByte import SystemSByte
from . SystemObject import SystemObject
from . SystemStringSplitOptions import SystemStringSplitOptions
from . SystemCollectionsGenericIEnumerableSystemString import SystemCollectionsGenericIEnumerableSystemString
from . SystemStringComparison import SystemStringComparison
from . IEnumerableT import IEnumerableT
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . SystemTextNormalizationForm import SystemTextNormalizationForm
from . SystemCharEnumerator import SystemCharEnumerator
from . SystemObjectArray import SystemObjectArray
from . SystemTextEncoding import SystemTextEncoding
from . SystemType import SystemType


class SystemString:

    def __new__(cls, input_1: Any) -> SystemString:
        return SystemString

    @staticmethod
    def Clone() -> Union[SystemObject, Any]:
        return Union[SystemObject, Any]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemGlobalizationCultureInfo, input_3: SystemGlobalizationCompareOptions) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool], input_3: SystemGlobalizationCultureInfo) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: Union[SystemBoolean, bool], input_6: SystemGlobalizationCultureInfo) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: SystemGlobalizationCultureInfo, input_6: SystemGlobalizationCompareOptions) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Compare(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int], input_5: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareOrdinal(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareOrdinal(input_0: Union[SystemString, str], input_1: Union[SystemInt32, int], input_2: Union[SystemString, str], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: Union[SystemObject, Any]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Concat(input_0: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemObject, Any], input_1: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemObject, Any], input_1: Union[SystemObject, Any], input_2: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemObject, Any], input_1: Union[SystemObject, Any], input_2: Union[SystemObject, Any], input_3: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: SystemObjectArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: IEnumerableT) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: SystemCollectionsGenericIEnumerableSystemString) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: Union[SystemString, str], input_3: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Concat(input_0: SystemStringArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Contains(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Copy(input_0: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def CopyTo(input_1: Union[SystemInt32, int], input_2: SystemCharArray, input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def EndsWith(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def EndsWith(input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def EndsWith(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool], input_3: SystemGlobalizationCultureInfo) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_0: Union[SystemString, str], input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Format(input_0: Union[SystemString, str], input_1: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: Union[SystemString, str], input_1: Union[SystemObject, Any], input_2: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: Union[SystemString, str], input_1: Union[SystemObject, Any], input_2: Union[SystemObject, Any], input_3: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: SystemIFormatProvider, input_1: Union[SystemString, str], input_2: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: SystemIFormatProvider, input_1: Union[SystemString, str], input_2: Union[SystemObject, Any], input_3: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: SystemIFormatProvider, input_1: Union[SystemString, str], input_2: Union[SystemObject, Any], input_3: Union[SystemObject, Any], input_4: Union[SystemObject, Any]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Format(input_0: SystemIFormatProvider, input_1: Union[SystemString, str], input_2: SystemObjectArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def GetEnumerator() -> SystemCharEnumerator:
        return SystemCharEnumerator

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetTypeCode() -> SystemTypeCode:
        return SystemTypeCode

    @staticmethod
    def IndexOf(input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: SystemChar, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: SystemChar, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOfAny(input_1: SystemCharArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOfAny(input_1: SystemCharArray, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def IndexOfAny(input_1: SystemCharArray, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Insert(input_1: Union[SystemInt32, int], input_2: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Intern(input_0: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def IsInterned(input_0: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def IsNormalized() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNormalized(input_1: SystemTextNormalizationForm) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNullOrEmpty(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsNullOrWhiteSpace(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Join(input_0: Union[SystemString, str], input_1: SystemStringArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Join(input_0: Union[SystemString, str], input_1: SystemObjectArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Join(input_0: Union[SystemString, str], input_1: IEnumerableT) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Join(input_0: Union[SystemString, str], input_1: SystemCollectionsGenericIEnumerableSystemString) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Join(input_0: Union[SystemString, str], input_1: SystemStringArray, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def LastIndexOf(input_1: SystemChar) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: SystemChar, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: SystemChar, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOf(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: SystemStringComparison) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOfAny(input_1: SystemCharArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOfAny(input_1: SystemCharArray, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LastIndexOfAny(input_1: SystemCharArray, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Normalize() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Normalize(input_1: SystemTextNormalizationForm) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def PadLeft(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def PadLeft(input_1: Union[SystemInt32, int], input_2: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def PadRight(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def PadRight(input_1: Union[SystemInt32, int], input_2: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Remove(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Remove(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Replace(input_1: SystemChar, input_2: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Replace(input_1: Union[SystemString, str], input_2: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Split(input_1: SystemCharArray) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def Split(input_1: SystemCharArray, input_2: Union[SystemInt32, int]) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def Split(input_1: SystemCharArray, input_2: SystemStringSplitOptions) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def Split(input_1: SystemCharArray, input_2: Union[SystemInt32, int], input_3: SystemStringSplitOptions) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def Split(input_1: SystemStringArray, input_2: SystemStringSplitOptions) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def Split(input_1: SystemStringArray, input_2: Union[SystemInt32, int], input_3: SystemStringSplitOptions) -> SystemStringArray:
        return SystemStringArray

    @staticmethod
    def StartsWith(input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def StartsWith(input_1: Union[SystemString, str], input_2: SystemStringComparison) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def StartsWith(input_1: Union[SystemString, str], input_2: Union[SystemBoolean, bool], input_3: SystemGlobalizationCultureInfo) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Substring(input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Substring(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToCharArray() -> SystemCharArray:
        return SystemCharArray

    @staticmethod
    def ToCharArray(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> SystemCharArray:
        return SystemCharArray

    @staticmethod
    def ToLower() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToLower(input_1: SystemGlobalizationCultureInfo) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToLowerInvariant() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUpper() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUpper(input_1: SystemGlobalizationCultureInfo) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToUpperInvariant() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Trim(input_1: SystemCharArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def Trim() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TrimEnd(input_1: SystemCharArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TrimStart(input_1: SystemCharArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemChar) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemChar, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemSByte) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemSByte, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemSByte, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int], input_3: SystemTextEncoding) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemCharArray, input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemCharArray) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: SystemChar, input_1: Union[SystemInt32, int]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Chars(input_1: Union[SystemInt32, int]) -> SystemChar:
        return SystemChar

    @staticmethod
    def get_Empty() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Length() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def op_Addition(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def op_Equality(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: Union[SystemString, str], input_1: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]
