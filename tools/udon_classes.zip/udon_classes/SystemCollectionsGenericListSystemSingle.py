from typing import Any

from . SystemCollectionsGenericListSystemSingle import SystemCollectionsGenericListSystemSingle


class SystemCollectionsGenericListSystemSingle:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListSystemSingle:
        return SystemCollectionsGenericListSystemSingle
