from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemBooleanRef import SystemBooleanRef
from . SystemString import SystemString
from . SystemIFormatProvider import SystemIFormatProvider
from . SystemBoolean import SystemBoolean


class SystemBoolean:

    def __new__(cls, input_1: Any) -> SystemBoolean:
        return SystemBoolean

    @staticmethod
    def CompareTo(input_1: SystemObject) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CompareTo(input_1: Union[SystemBoolean, bool]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Parse(input_0: Union[SystemString, str]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: SystemIFormatProvider) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def TryParse(input_0: Union[SystemString, str], input_1: SystemBooleanRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_FalseString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_TrueString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def op_ConditionalAnd(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_ConditionalOr(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_ConditionalXor(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Equality(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LogicalAnd(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LogicalOr(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_LogicalXor(input_0: Union[SystemBoolean, bool], input_1: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_UnaryNegation(input_0: Union[SystemBoolean, bool]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]
