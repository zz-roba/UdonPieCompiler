from typing import Any

from . UnityEngineFrustumPlanes import UnityEngineFrustumPlanes


class UnityEngineFrustumPlanes:

    def __new__(cls, input_1: Any) -> UnityEngineFrustumPlanes:
        return UnityEngineFrustumPlanes
