from typing import Any

from . UnityEngineBillboardAsset import UnityEngineBillboardAsset


class UnityEngineBillboardAsset:

    def __new__(cls, input_1: Any) -> UnityEngineBillboardAsset:
        return UnityEngineBillboardAsset
