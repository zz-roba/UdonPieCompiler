from typing import Union
from typing import Any

from . SystemType import SystemType
from . UnityEngineVector3 import UnityEngineVector3
from . SystemSingle import SystemSingle
from . SystemObject import SystemObject
from . SystemSingleRef import SystemSingleRef
from . SystemInt32 import SystemInt32
from . UnityEngineRay import UnityEngineRay
from . UnityEngineBounds import UnityEngineBounds
from . SystemString import SystemString
from . SystemBoolean import SystemBoolean


class UnityEngineBounds:

    def __new__(cls, input_1: Any) -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def ClosestPoint(input_1: UnityEngineVector3) -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def Contains(input_1: UnityEngineVector3) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Encapsulate(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def Encapsulate(input_1: UnityEngineBounds) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: UnityEngineBounds) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Expand(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def Expand(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IntersectRay(input_1: UnityEngineRay) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IntersectRay(input_1: UnityEngineRay, input_2: SystemSingleRef) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Intersects(input_1: UnityEngineBounds) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SetMinMax(input_1: UnityEngineVector3, input_2: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def SqrDistance(input_1: UnityEngineVector3) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ToString(input_1: Union[SystemString, str]) -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor(input_0: UnityEngineVector3, input_1: UnityEngineVector3) -> UnityEngineBounds:
        return UnityEngineBounds

    @staticmethod
    def get_center() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_extents() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_max() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_min() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def get_size() -> UnityEngineVector3:
        return UnityEngineVector3

    @staticmethod
    def op_Equality(input_0: UnityEngineBounds, input_1: UnityEngineBounds) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineBounds, input_1: UnityEngineBounds) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_center(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_extents(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_max(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_min(input_1: UnityEngineVector3) -> None:
        return 

    @staticmethod
    def set_size(input_1: UnityEngineVector3) -> None:
        return 
