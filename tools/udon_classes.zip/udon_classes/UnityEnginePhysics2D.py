from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemSingle import SystemSingle
from . UnityEngineColliderDistance2D import UnityEngineColliderDistance2D
from . UnityEnginePhysics2D import UnityEnginePhysics2D
from . UnityEngineRaycastHit2DArray import UnityEngineRaycastHit2DArray
from . UnityEngineColor import UnityEngineColor
from . UnityEnginePhysicsScene2D import UnityEnginePhysicsScene2D
from . UnityEngineContactFilter2D import UnityEngineContactFilter2D
from . SystemInt32 import SystemInt32
from . UnityEngineCollider2D import UnityEngineCollider2D
from . SystemBoolean import SystemBoolean
from . UnityEngineRigidbody2D import UnityEngineRigidbody2D
from . UnityEngineRaycastHit2D import UnityEngineRaycastHit2D
from . UnityEngineVector2 import UnityEngineVector2
from . UnityEngineCapsuleDirection2D import UnityEngineCapsuleDirection2D
from . UnityEnginePhysicsJobOptions2D import UnityEnginePhysicsJobOptions2D
from . SystemObject import SystemObject
from . UnityEngineRay import UnityEngineRay
from . UnityEngineCollider2DArray import UnityEngineCollider2DArray
from . SystemString import SystemString
from . UnityEngineContactPoint2DArray import UnityEngineContactPoint2DArray


class UnityEnginePhysics2D:

    def __new__(cls, input_1: Any) -> UnityEnginePhysics2D:
        return UnityEnginePhysics2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float], input_7: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineContactFilter2D, input_5: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineContactFilter2D, input_5: UnityEngineRaycastHit2DArray, input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def BoxCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float], input_7: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineRaycastHit2DArray, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineRaycastHit2DArray, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineRaycastHit2DArray, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float], input_8: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def BoxCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineVector2, input_4: UnityEngineRaycastHit2DArray, input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float], input_8: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineContactFilter2D, input_6: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineContactFilter2D, input_6: UnityEngineRaycastHit2DArray, input_7: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CapsuleCastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: Union[SystemSingle, int, float], input_6: Union[SystemInt32, int], input_7: Union[SystemSingle, int, float], input_8: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineRaycastHit2DArray, input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineRaycastHit2DArray, input_6: Union[SystemSingle, int, float], input_7: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineRaycastHit2DArray, input_6: Union[SystemSingle, int, float], input_7: Union[SystemInt32, int], input_8: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CapsuleCastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineVector2, input_5: UnityEngineRaycastHit2DArray, input_6: Union[SystemSingle, int, float], input_7: Union[SystemInt32, int], input_8: Union[SystemSingle, int, float], input_9: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineContactFilter2D, input_4: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCast(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineContactFilter2D, input_4: UnityEngineRaycastHit2DArray, input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCastAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CircleCastAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CircleCastAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CircleCastAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CircleCastAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def CircleCastNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCastNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCastNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCastNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def CircleCastNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineVector2, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float], input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float], input_7: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Distance(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D) -> UnityEngineColliderDistance2D:
        return UnityEngineColliderDistance2D

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetContacts(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D, input_2: UnityEngineContactFilter2D, input_3: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineCollider2D, input_1: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineCollider2D, input_1: UnityEngineContactFilter2D, input_2: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineCollider2D, input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineRigidbody2D, input_1: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineRigidbody2D, input_1: UnityEngineContactFilter2D, input_2: UnityEngineContactPoint2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineRigidbody2D, input_1: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetContacts(input_0: UnityEngineRigidbody2D, input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetIgnoreCollision(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetIgnoreLayerCollision(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetLayerCollisionMask(input_0: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetRayIntersection(input_0: UnityEngineRay) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def GetRayIntersection(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def GetRayIntersection(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def GetRayIntersectionAll(input_0: UnityEngineRay) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def GetRayIntersectionAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def GetRayIntersectionAll(input_0: UnityEngineRay, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def GetRayIntersectionNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetRayIntersectionNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHit2DArray, input_2: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetRayIntersectionNonAlloc(input_0: UnityEngineRay, input_1: UnityEngineRaycastHit2DArray, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def IgnoreCollision(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D) -> None:
        return 

    @staticmethod
    def IgnoreCollision(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D, input_2: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def IsTouching(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouching(input_0: UnityEngineCollider2D, input_1: UnityEngineCollider2D, input_2: UnityEngineContactFilter2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouching(input_0: UnityEngineCollider2D, input_1: UnityEngineContactFilter2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouchingLayers(input_0: UnityEngineCollider2D) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def IsTouchingLayers(input_0: UnityEngineCollider2D, input_1: Union[SystemInt32, int]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Linecast(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Linecast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Linecast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Linecast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Linecast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LinecastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def LinecastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def LinecastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def LinecastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def LinecastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LinecastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LinecastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def LinecastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapArea(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapArea(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapArea(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapArea(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapArea(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapAreaAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapAreaAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapAreaAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapAreaAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapAreaNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapAreaNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapAreaNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapAreaNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapBox(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineContactFilter2D, input_4: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapBoxAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapBoxAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapBoxAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineCollider2DArray, input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineCollider2DArray, input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapBoxNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: UnityEngineCollider2DArray, input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCapsule(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineContactFilter2D, input_5: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCapsuleAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCapsuleAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCapsuleAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineCollider2DArray, input_5: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineCollider2DArray, input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCapsuleNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineCapsuleDirection2D, input_3: Union[SystemSingle, int, float], input_4: UnityEngineCollider2DArray, input_5: Union[SystemInt32, int], input_6: Union[SystemSingle, int, float], input_7: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCircle(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCircle(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCircle(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCircle(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapCircle(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineContactFilter2D, input_3: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCircleAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCircleAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCircleAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCircleAll(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapCircleNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCircleNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCircleNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCircleNonAlloc(input_0: UnityEngineVector2, input_1: Union[SystemSingle, int, float], input_2: UnityEngineCollider2DArray, input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapCollider(input_0: UnityEngineCollider2D, input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPoint(input_0: UnityEngineVector2) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapPoint(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapPoint(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapPoint(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2D:
        return UnityEngineCollider2D

    @staticmethod
    def OverlapPoint(input_0: UnityEngineVector2, input_1: UnityEngineContactFilter2D, input_2: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPointAll(input_0: UnityEngineVector2) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapPointAll(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapPointAll(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapPointAll(input_0: UnityEngineVector2, input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float], input_3: Union[SystemSingle, int, float]) -> UnityEngineCollider2DArray:
        return UnityEngineCollider2DArray

    @staticmethod
    def OverlapPointNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineCollider2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPointNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineCollider2DArray, input_2: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPointNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineCollider2DArray, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def OverlapPointNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineCollider2DArray, input_2: Union[SystemInt32, int], input_3: Union[SystemSingle, int, float], input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2D:
        return UnityEngineRaycastHit2D

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def Raycast(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineContactFilter2D, input_3: UnityEngineRaycastHit2DArray, input_4: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def RaycastAll(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: Union[SystemSingle, int, float], input_3: Union[SystemInt32, int], input_4: Union[SystemSingle, int, float], input_5: Union[SystemSingle, int, float]) -> UnityEngineRaycastHit2DArray:
        return UnityEngineRaycastHit2DArray

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def RaycastNonAlloc(input_0: UnityEngineVector2, input_1: UnityEngineVector2, input_2: UnityEngineRaycastHit2DArray, input_3: Union[SystemSingle, int, float], input_4: Union[SystemInt32, int], input_5: Union[SystemSingle, int, float], input_6: Union[SystemSingle, int, float]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def SetLayerCollisionMask(input_0: Union[SystemInt32, int], input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Simulate(input_0: Union[SystemSingle, int, float]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def SyncTransforms() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_AllLayers() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_DefaultRaycastLayers() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_IgnoreRaycastLayer() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_alwaysShowColliders() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_angularSleepTolerance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_baumgarteScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_baumgarteTOIScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_callbacksOnDisable() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_colliderAABBColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colliderAsleepColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colliderAwakeColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colliderContactColor() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_contactArrowScale() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_defaultPhysicsScene() -> UnityEnginePhysicsScene2D:
        return UnityEnginePhysicsScene2D

    @staticmethod
    def get_gravity() -> UnityEngineVector2:
        return UnityEngineVector2

    @staticmethod
    def get_jobOptions() -> UnityEnginePhysicsJobOptions2D:
        return UnityEnginePhysicsJobOptions2D

    @staticmethod
    def get_linearSleepTolerance() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxAngularCorrection() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxLinearCorrection() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxRotationSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_maxTranslationSpeed() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_positionIterations() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_queriesStartInColliders() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_reuseCollisionCallbacks() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_showColliderAABB() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_showColliderContacts() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_showColliderSleep() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_timeToSleep() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_velocityIterations() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_velocityThreshold() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def set_alwaysShowColliders(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_angularSleepTolerance(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_baumgarteScale(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_baumgarteTOIScale(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_callbacksOnDisable(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_colliderAABBColor(input_0: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colliderAsleepColor(input_0: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colliderAwakeColor(input_0: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colliderContactColor(input_0: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_contactArrowScale(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_gravity(input_0: UnityEngineVector2) -> None:
        return 

    @staticmethod
    def set_jobOptions(input_0: UnityEnginePhysicsJobOptions2D) -> None:
        return 

    @staticmethod
    def set_linearSleepTolerance(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxAngularCorrection(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxLinearCorrection(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxRotationSpeed(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_maxTranslationSpeed(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_positionIterations(input_0: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_queriesStartInColliders(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_reuseCollisionCallbacks(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_showColliderAABB(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_showColliderContacts(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_showColliderSleep(input_0: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_timeToSleep(input_0: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_velocityIterations(input_0: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_velocityThreshold(input_0: Union[SystemSingle, int, float]) -> None:
        return 
