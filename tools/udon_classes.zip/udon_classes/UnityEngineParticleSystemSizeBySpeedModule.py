from typing import Any

from . UnityEngineParticleSystemSizeBySpeedModule import UnityEngineParticleSystemSizeBySpeedModule


class UnityEngineParticleSystemSizeBySpeedModule:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemSizeBySpeedModule:
        return UnityEngineParticleSystemSizeBySpeedModule
