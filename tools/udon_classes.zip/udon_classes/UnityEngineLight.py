from typing import Union
from typing import Any

from . SystemCollectionsGenericListUnityEngineComponent import SystemCollectionsGenericListUnityEngineComponent
from . UnityEngineComponent import UnityEngineComponent
from . UnityEngineComponentArray import UnityEngineComponentArray
from . UnityEngineLightRenderMode import UnityEngineLightRenderMode
from . UnityEngineLightArray import UnityEngineLightArray
from . UnityEngineColor import UnityEngineColor
from . UnityEngineLightShadows import UnityEngineLightShadows
from . SystemBoolean import SystemBoolean
from . UnityEngineLight import UnityEngineLight
from . UnityEngineLightBakingOutput import UnityEngineLightBakingOutput
from . SystemInt32 import SystemInt32
from . T import T
from . UnityEngineTexture import UnityEngineTexture
from . UnityEngineLightShadowCasterMode import UnityEngineLightShadowCasterMode
from . ListT import ListT
from . UnityEngineObject import UnityEngineObject
from . SystemObject import SystemObject
from . SystemSingleArray import SystemSingleArray
from . UnityEngineLightType import UnityEngineLightType
from . UnityEngineTransform import UnityEngineTransform
from . SystemSingle import SystemSingle
from . SystemString import SystemString
from . UnityEngineRenderingLightShadowResolution import UnityEngineRenderingLightShadowResolution
from . SystemType import SystemType
from . UnityEngineGameObject import UnityEngineGameObject
from . UnityEngineFlare import UnityEngineFlare


class UnityEngineLight:

    def __new__(cls, input_1: Any) -> UnityEngineLight:
        return UnityEngineLight

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponent(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponent(input_1: Union[SystemString, str]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineLight, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentInChildren(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentInParent(input_1: SystemType) -> UnityEngineComponent:
        return UnityEngineComponent

    @staticmethod
    def GetComponentInParent(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponents(input_1: SystemType, input_2: SystemCollectionsGenericListUnityEngineComponent) -> None:
        return 

    @staticmethod
    def GetComponents(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponents(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineLight, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInChildren(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetComponentsInChildren(input_1: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_1: SystemType, input_2: Union[SystemBoolean, bool]) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_1: SystemType) -> UnityEngineComponentArray:
        return UnityEngineComponentArray

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineLight, input_1: T) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetComponentsInParent(input_1: Union[SystemBoolean, bool], input_2: ListT) -> None:
        return 

    @staticmethod
    def GetComponentsInParent(input_0: UnityEngineLight, input_1: T) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInstanceID() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetLights(input_0: UnityEngineLightType, input_1: Union[SystemInt32, int]) -> UnityEngineLightArray:
        return UnityEngineLightArray

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def Reset() -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_bakingOutput() -> UnityEngineLightBakingOutput:
        return UnityEngineLightBakingOutput

    @staticmethod
    def get_bounceIntensity() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_color() -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def get_colorTemperature() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_cookie() -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def get_cookieSize() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_cullingMask() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_enabled() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def get_flare() -> UnityEngineFlare:
        return UnityEngineFlare

    @staticmethod
    def get_gameObject() -> UnityEngineGameObject:
        return UnityEngineGameObject

    @staticmethod
    def get_intensity() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_layerShadowCullDistances() -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def get_lightShadowCasterMode() -> UnityEngineLightShadowCasterMode:
        return UnityEngineLightShadowCasterMode

    @staticmethod
    def get_name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_range() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_renderMode() -> UnityEngineLightRenderMode:
        return UnityEngineLightRenderMode

    @staticmethod
    def get_shadowBias() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shadowCustomResolution() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def get_shadowNearPlane() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shadowNormalBias() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shadowResolution() -> UnityEngineRenderingLightShadowResolution:
        return UnityEngineRenderingLightShadowResolution

    @staticmethod
    def get_shadowStrength() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_shadows() -> UnityEngineLightShadows:
        return UnityEngineLightShadows

    @staticmethod
    def get_spotAngle() -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def get_transform() -> UnityEngineTransform:
        return UnityEngineTransform

    @staticmethod
    def get_type() -> UnityEngineLightType:
        return UnityEngineLightType

    @staticmethod
    def op_Equality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Implicit(input_0: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: UnityEngineObject, input_1: UnityEngineObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def set_bakingOutput(input_1: UnityEngineLightBakingOutput) -> None:
        return 

    @staticmethod
    def set_bounceIntensity(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_color(input_1: UnityEngineColor) -> None:
        return 

    @staticmethod
    def set_colorTemperature(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_cookie(input_1: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def set_cookieSize(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_cullingMask(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_enabled(input_1: Union[SystemBoolean, bool]) -> None:
        return 

    @staticmethod
    def set_flare(input_1: UnityEngineFlare) -> None:
        return 

    @staticmethod
    def set_intensity(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_layerShadowCullDistances(input_1: SystemSingleArray) -> None:
        return 

    @staticmethod
    def set_lightShadowCasterMode(input_1: UnityEngineLightShadowCasterMode) -> None:
        return 

    @staticmethod
    def set_name(input_1: Union[SystemString, str]) -> None:
        return 

    @staticmethod
    def set_range(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_renderMode(input_1: UnityEngineLightRenderMode) -> None:
        return 

    @staticmethod
    def set_shadowBias(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_shadowCustomResolution(input_1: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def set_shadowNearPlane(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_shadowNormalBias(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_shadowResolution(input_1: UnityEngineRenderingLightShadowResolution) -> None:
        return 

    @staticmethod
    def set_shadowStrength(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_shadows(input_1: UnityEngineLightShadows) -> None:
        return 

    @staticmethod
    def set_spotAngle(input_1: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def set_type(input_1: UnityEngineLightType) -> None:
        return 
