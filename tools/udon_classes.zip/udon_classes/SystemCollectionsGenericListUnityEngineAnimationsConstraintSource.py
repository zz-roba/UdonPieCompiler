from typing import Any

from . SystemCollectionsGenericListUnityEngineAnimationsConstraintSource import SystemCollectionsGenericListUnityEngineAnimationsConstraintSource


class SystemCollectionsGenericListUnityEngineAnimationsConstraintSource:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineAnimationsConstraintSource:
        return SystemCollectionsGenericListUnityEngineAnimationsConstraintSource
