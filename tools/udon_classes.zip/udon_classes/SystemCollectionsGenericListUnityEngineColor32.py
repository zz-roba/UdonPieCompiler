from typing import Any

from . SystemCollectionsGenericListUnityEngineColor32 import SystemCollectionsGenericListUnityEngineColor32


class SystemCollectionsGenericListUnityEngineColor32:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericListUnityEngineColor32:
        return SystemCollectionsGenericListUnityEngineColor32
