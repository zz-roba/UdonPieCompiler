from typing import Any

from . SystemCollectionsGenericIEnumerableUnityEngineUIToggle import SystemCollectionsGenericIEnumerableUnityEngineUIToggle


class SystemCollectionsGenericIEnumerableUnityEngineUIToggle:

    def __new__(cls, input_1: Any) -> SystemCollectionsGenericIEnumerableUnityEngineUIToggle:
        return SystemCollectionsGenericIEnumerableUnityEngineUIToggle
