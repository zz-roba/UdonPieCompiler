from typing import Union
from typing import Any

from . UnityEngineMatrix4x4Array import UnityEngineMatrix4x4Array
from . SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2 import SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2
from . SystemBoolean import SystemBoolean
from . SystemObject import SystemObject
from . SystemCollectionsGenericListUnityEngineVector4 import SystemCollectionsGenericListUnityEngineVector4
from . SystemSingleArray import SystemSingleArray
from . UnityEngineMaterialPropertyBlock import UnityEngineMaterialPropertyBlock
from . SystemCollectionsGenericListSystemSingle import SystemCollectionsGenericListSystemSingle
from . SystemString import SystemString
from . UnityEngineVector4Array import UnityEngineVector4Array
from . UnityEngineMatrix4x4 import UnityEngineMatrix4x4
from . UnityEngineComputeBuffer import UnityEngineComputeBuffer
from . UnityEngineRenderingSphericalHarmonicsL2Array import UnityEngineRenderingSphericalHarmonicsL2Array
from . SystemType import SystemType
from . UnityEngineVector4 import UnityEngineVector4
from . SystemSingle import SystemSingle
from . UnityEngineColor import UnityEngineColor
from . SystemInt32 import SystemInt32
from . UnityEngineTexture import UnityEngineTexture
from . SystemCollectionsGenericListUnityEngineMatrix4x4 import SystemCollectionsGenericListUnityEngineMatrix4x4


class UnityEngineMaterialPropertyBlock:

    def __new__(cls, input_1: Any) -> UnityEngineMaterialPropertyBlock:
        return UnityEngineMaterialPropertyBlock

    @staticmethod
    def Clear() -> None:
        return 

    @staticmethod
    def CopyProbeOcclusionArrayFrom(input_1: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def CopyProbeOcclusionArrayFrom(input_1: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def CopyProbeOcclusionArrayFrom(input_1: SystemCollectionsGenericListUnityEngineVector4, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CopyProbeOcclusionArrayFrom(input_1: UnityEngineVector4Array, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CopySHCoefficientArraysFrom(input_1: SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2) -> None:
        return 

    @staticmethod
    def CopySHCoefficientArraysFrom(input_1: UnityEngineRenderingSphericalHarmonicsL2Array) -> None:
        return 

    @staticmethod
    def CopySHCoefficientArraysFrom(input_1: SystemCollectionsGenericListUnityEngineRenderingSphericalHarmonicsL2, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def CopySHCoefficientArraysFrom(input_1: UnityEngineRenderingSphericalHarmonicsL2Array, input_2: Union[SystemInt32, int], input_3: Union[SystemInt32, int], input_4: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def Equals(input_1: Union[SystemObject, Any]) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetColor(input_1: Union[SystemString, str]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetColor(input_1: Union[SystemInt32, int]) -> UnityEngineColor:
        return UnityEngineColor

    @staticmethod
    def GetFloat(input_1: Union[SystemString, str]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetFloat(input_1: Union[SystemInt32, int]) -> Union[SystemSingle, int, float]:
        return Union[SystemSingle, int, float]

    @staticmethod
    def GetFloatArray(input_1: Union[SystemString, str]) -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def GetFloatArray(input_1: Union[SystemInt32, int]) -> SystemSingleArray:
        return SystemSingleArray

    @staticmethod
    def GetFloatArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def GetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInt(input_1: Union[SystemString, str]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetInt(input_1: Union[SystemInt32, int]) -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetMatrix(input_1: Union[SystemString, str]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetMatrix(input_1: Union[SystemInt32, int]) -> UnityEngineMatrix4x4:
        return UnityEngineMatrix4x4

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemString, str]) -> UnityEngineMatrix4x4Array:
        return UnityEngineMatrix4x4Array

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemInt32, int]) -> UnityEngineMatrix4x4Array:
        return UnityEngineMatrix4x4Array

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def GetMatrixArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def GetTexture(input_1: Union[SystemString, str]) -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def GetTexture(input_1: Union[SystemInt32, int]) -> UnityEngineTexture:
        return UnityEngineTexture

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def GetVector(input_1: Union[SystemString, str]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetVector(input_1: Union[SystemInt32, int]) -> UnityEngineVector4:
        return UnityEngineVector4

    @staticmethod
    def GetVectorArray(input_1: Union[SystemString, str]) -> UnityEngineVector4Array:
        return UnityEngineVector4Array

    @staticmethod
    def GetVectorArray(input_1: Union[SystemInt32, int]) -> UnityEngineVector4Array:
        return UnityEngineVector4Array

    @staticmethod
    def GetVectorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def GetVectorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetBuffer(input_1: Union[SystemString, str], input_2: UnityEngineComputeBuffer) -> None:
        return 

    @staticmethod
    def SetBuffer(input_1: Union[SystemInt32, int], input_2: UnityEngineComputeBuffer) -> None:
        return 

    @staticmethod
    def SetColor(input_1: Union[SystemString, str], input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def SetColor(input_1: Union[SystemInt32, int], input_2: UnityEngineColor) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemString, str], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloat(input_1: Union[SystemInt32, int], input_2: Union[SystemSingle, int, float]) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListSystemSingle) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemString, str], input_2: SystemSingleArray) -> None:
        return 

    @staticmethod
    def SetFloatArray(input_1: Union[SystemInt32, int], input_2: SystemSingleArray) -> None:
        return 

    @staticmethod
    def SetInt(input_1: Union[SystemString, str], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetInt(input_1: Union[SystemInt32, int], input_2: Union[SystemInt32, int]) -> None:
        return 

    @staticmethod
    def SetMatrix(input_1: Union[SystemString, str], input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrix(input_1: Union[SystemInt32, int], input_2: UnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineMatrix4x4) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemString, str], input_2: UnityEngineMatrix4x4Array) -> None:
        return 

    @staticmethod
    def SetMatrixArray(input_1: Union[SystemInt32, int], input_2: UnityEngineMatrix4x4Array) -> None:
        return 

    @staticmethod
    def SetTexture(input_1: Union[SystemString, str], input_2: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetTexture(input_1: Union[SystemInt32, int], input_2: UnityEngineTexture) -> None:
        return 

    @staticmethod
    def SetVector(input_1: Union[SystemString, str], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVector(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemString, str], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemInt32, int], input_2: SystemCollectionsGenericListUnityEngineVector4) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemString, str], input_2: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def SetVectorArray(input_1: Union[SystemInt32, int], input_2: UnityEngineVector4Array) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineMaterialPropertyBlock:
        return UnityEngineMaterialPropertyBlock

    @staticmethod
    def get_isEmpty() -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]
