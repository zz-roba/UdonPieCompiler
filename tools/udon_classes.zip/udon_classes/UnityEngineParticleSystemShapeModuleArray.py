from typing import Any

from . UnityEngineParticleSystemShapeModuleArray import UnityEngineParticleSystemShapeModuleArray


class UnityEngineParticleSystemShapeModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemShapeModuleArray:
        return UnityEngineParticleSystemShapeModuleArray
