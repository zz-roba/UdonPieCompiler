from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . UnityEngineAnimatorUtility import UnityEngineAnimatorUtility
from . SystemInt32 import SystemInt32
from . SystemStringArray import SystemStringArray
from . SystemString import SystemString
from . UnityEngineGameObject import UnityEngineGameObject
from . SystemBoolean import SystemBoolean


class UnityEngineAnimatorUtility:

    def __new__(cls, input_1: Any) -> UnityEngineAnimatorUtility:
        return UnityEngineAnimatorUtility

    @staticmethod
    def DeoptimizeTransformHierarchy(input_0: UnityEngineGameObject) -> None:
        return 

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def OptimizeTransformHierarchy(input_0: UnityEngineGameObject, input_1: SystemStringArray) -> None:
        return 

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def ctor() -> UnityEngineAnimatorUtility:
        return UnityEngineAnimatorUtility
