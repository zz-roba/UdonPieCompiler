from typing import Any

from . UnityEngineParticleSystemCollisionModuleArray import UnityEngineParticleSystemCollisionModuleArray


class UnityEngineParticleSystemCollisionModuleArray:

    def __new__(cls, input_1: Any) -> UnityEngineParticleSystemCollisionModuleArray:
        return UnityEngineParticleSystemCollisionModuleArray
