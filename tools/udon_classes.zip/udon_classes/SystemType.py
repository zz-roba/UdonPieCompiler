from typing import Union
from typing import Any

from . SystemType import SystemType
from . SystemObject import SystemObject
from . SystemInt32 import SystemInt32
from . SystemString import SystemString
from . SystemGuid import SystemGuid
from . SystemBoolean import SystemBoolean


class SystemType:

    def __new__(cls, input_1: Any) -> SystemType:
        return SystemType

    @staticmethod
    def Equals(input_1: SystemObject) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def Equals(input_1: SystemType) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def GetHashCode() -> Union[SystemInt32, int]:
        return Union[SystemInt32, int]

    @staticmethod
    def GetType(input_0: Union[SystemString, str], input_1: Union[SystemBoolean, bool], input_2: Union[SystemBoolean, bool]) -> SystemType:
        return SystemType

    @staticmethod
    def GetType(input_0: Union[SystemString, str], input_1: Union[SystemBoolean, bool]) -> SystemType:
        return SystemType

    @staticmethod
    def GetType(input_0: Union[SystemString, str]) -> SystemType:
        return SystemType

    @staticmethod
    def GetType() -> SystemType:
        return SystemType

    @staticmethod
    def ToString() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_AssemblyQualifiedName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_FullName() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_GUID() -> SystemGuid:
        return SystemGuid

    @staticmethod
    def get_Name() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def get_Namespace() -> Union[SystemString, str]:
        return Union[SystemString, str]

    @staticmethod
    def op_Equality(input_0: SystemType, input_1: SystemType) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]

    @staticmethod
    def op_Inequality(input_0: SystemType, input_1: SystemType) -> Union[SystemBoolean, bool]:
        return Union[SystemBoolean, bool]
