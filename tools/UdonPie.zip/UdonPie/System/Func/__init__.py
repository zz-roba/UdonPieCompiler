from UdonPie import System
from UdonPie.Undefined import *


class Func:
    def __new__(cls, arg1=None):
        '''
        :returns: Func
        :rtype: System.Func
        '''
        pass
