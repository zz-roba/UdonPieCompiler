from UdonPie import System
from UdonPie.Undefined import *


class Decimal:
    def __new__(cls, arg1=None):
        '''
        :returns: Decimal
        :rtype: System.Decimal
        '''
        pass
