from UdonPie import System
from UdonPie.Undefined import *


class AdjustmentRuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: AdjustmentRuleArray
        :rtype: System.AdjustmentRuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: AdjustmentRule
        :type value: System.AdjustmentRule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: AdjustmentRule
        :rtype: System.AdjustmentRule
        '''
        pass
