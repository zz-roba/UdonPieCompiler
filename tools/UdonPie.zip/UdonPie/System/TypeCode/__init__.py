from UdonPie import System
from UdonPie.Undefined import *


class TypeCode:
    def __new__(cls, arg1=None):
        '''
        :returns: TypeCode
        :rtype: System.TypeCode
        '''
        pass
