from UdonPie import System
from UdonPie.Undefined import *


class DateTimeKind:
    def __new__(cls, arg1=None):
        '''
        :returns: DateTimeKind
        :rtype: System.DateTimeKind
        '''
        pass
