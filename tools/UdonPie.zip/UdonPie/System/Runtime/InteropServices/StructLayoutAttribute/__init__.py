from UdonPie import System
from UdonPie.Undefined import *


class StructLayoutAttribute:
    def __new__(cls, arg1=None):
        '''
        :returns: StructLayoutAttribute
        :rtype: System.StructLayoutAttribute
        '''
        pass
