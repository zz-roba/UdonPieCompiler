from UdonPie import System
from UdonPie.Undefined import *


class Base64FormattingOptions:
    def __new__(cls, arg1=None):
        '''
        :returns: Base64FormattingOptions
        :rtype: System.Base64FormattingOptions
        '''
        pass
