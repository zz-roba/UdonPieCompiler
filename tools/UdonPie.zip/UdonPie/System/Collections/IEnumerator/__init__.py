from UdonPie import System
from UdonPie.Undefined import *


class IEnumerator:
    def __new__(cls, arg1=None):
        '''
        :returns: IEnumerator
        :rtype: System.IEnumerator
        '''
        pass
