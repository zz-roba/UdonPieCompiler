from UdonPie import System
from UdonPie.Undefined import *


class IEnumerable:
    def __new__(cls, arg1=None):
        '''
        :returns: IEnumerable
        :rtype: System.IEnumerable
        '''
        pass
