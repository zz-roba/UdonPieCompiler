from UdonPie import System
from UdonPie.Undefined import *


class List:
    def __new__(cls, arg1=None):
        '''
        :returns: List
        :rtype: System.List
        '''
        pass
