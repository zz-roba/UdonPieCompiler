from UdonPie import System
from UdonPie.Undefined import *


class ReadOnlyCollection:
    def __new__(cls, arg1=None):
        '''
        :returns: ReadOnlyCollection
        :rtype: System.ReadOnlyCollection
        '''
        pass
