from UdonPie import System
from UdonPie.Undefined import *


class CompareOptions:
    def __new__(cls, arg1=None):
        '''
        :returns: CompareOptions
        :rtype: System.CompareOptions
        '''
        pass
