from UdonPie import System
from UdonPie.Undefined import *


class DateTimeStyles:
    def __new__(cls, arg1=None):
        '''
        :returns: DateTimeStyles
        :rtype: System.DateTimeStyles
        '''
        pass
