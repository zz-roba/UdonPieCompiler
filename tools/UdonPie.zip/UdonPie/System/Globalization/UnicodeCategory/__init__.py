from UdonPie import System
from UdonPie.Undefined import *


class UnicodeCategory:
    def __new__(cls, arg1=None):
        '''
        :returns: UnicodeCategory
        :rtype: System.UnicodeCategory
        '''
        pass
