from UdonPie import System
from UdonPie.Undefined import *


class CultureInfo:
    def __new__(cls, arg1=None):
        '''
        :returns: CultureInfo
        :rtype: System.CultureInfo
        '''
        pass
