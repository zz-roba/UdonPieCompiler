from UdonPie import System
from UdonPie.Undefined import *


class NumberStyles:
    def __new__(cls, arg1=None):
        '''
        :returns: NumberStyles
        :rtype: System.NumberStyles
        '''
        pass
