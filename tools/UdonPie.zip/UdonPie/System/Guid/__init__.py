from UdonPie import System
from UdonPie.Undefined import *


class Guid:
    def __new__(cls, arg1=None):
        '''
        :returns: Guid
        :rtype: System.Guid
        '''
        pass
