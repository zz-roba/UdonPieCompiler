from UdonPie import System
from UdonPie.Undefined import *


class SingleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: SingleArray
        :rtype: System.SingleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: Single
        :type value: System.Single
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: Single
        :rtype: System.Single
        '''
        pass
