from UdonPie import System
from UdonPie.Undefined import *


class RuntimeTypeHandle:
    def __new__(cls, arg1=None):
        '''
        :returns: RuntimeTypeHandle
        :rtype: System.RuntimeTypeHandle
        '''
        pass
