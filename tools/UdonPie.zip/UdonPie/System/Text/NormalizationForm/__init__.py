from UdonPie import System
from UdonPie.Undefined import *


class NormalizationForm:
    def __new__(cls, arg1=None):
        '''
        :returns: NormalizationForm
        :rtype: System.NormalizationForm
        '''
        pass
