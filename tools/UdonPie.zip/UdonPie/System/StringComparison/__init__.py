from UdonPie import System
from UdonPie.Undefined import *


class StringComparison:
    def __new__(cls, arg1=None):
        '''
        :returns: StringComparison
        :rtype: System.StringComparison
        '''
        pass
