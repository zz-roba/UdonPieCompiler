from UdonPie import System
from UdonPie.Undefined import *


class Array:
    def __new__(cls, arg1=None):
        '''
        :returns: Array
        :rtype: System.Array
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: 
        :type value: System.Array
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: 
        :rtype: System.Array
        '''
        pass
