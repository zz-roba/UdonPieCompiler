from UdonPie import System
from UdonPie.Undefined import *


class StringSplitOptions:
    def __new__(cls, arg1=None):
        '''
        :returns: StringSplitOptions
        :rtype: System.StringSplitOptions
        '''
        pass
