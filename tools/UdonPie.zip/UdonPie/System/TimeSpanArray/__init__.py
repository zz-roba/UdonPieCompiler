from UdonPie import System
from UdonPie.Undefined import *


class TimeSpanArray:
    def __new__(cls, arg1=None):
        '''
        :returns: TimeSpanArray
        :rtype: System.TimeSpanArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: TimeSpan
        :type value: System.TimeSpan
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: TimeSpan
        :rtype: System.TimeSpan
        '''
        pass
