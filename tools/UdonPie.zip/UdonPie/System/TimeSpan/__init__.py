from UdonPie import System
from UdonPie.Undefined import *


class TimeSpan:
    def __new__(cls, arg1=None):
        '''
        :returns: TimeSpan
        :rtype: System.TimeSpan
        '''
        pass
