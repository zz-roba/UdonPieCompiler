from UdonPie import System
from UdonPie.Undefined import *


class IFormatProvider:
    def __new__(cls, arg1=None):
        '''
        :returns: IFormatProvider
        :rtype: System.IFormatProvider
        '''
        pass
