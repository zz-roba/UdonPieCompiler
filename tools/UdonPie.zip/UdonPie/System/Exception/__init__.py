from UdonPie import System
from UdonPie.Undefined import *


class Exception:
    def __new__(cls, arg1=None):
        '''
        :returns: Exception
        :rtype: System.Exception
        '''
        pass
