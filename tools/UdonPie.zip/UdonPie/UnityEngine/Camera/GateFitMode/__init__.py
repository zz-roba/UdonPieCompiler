from UdonPie import UnityEngine
from UdonPie.Undefined import *


class GateFitMode:
    def __new__(cls, arg1=None):
        '''
        :returns: GateFitMode
        :rtype: UnityEngine.GateFitMode
        '''
        pass
