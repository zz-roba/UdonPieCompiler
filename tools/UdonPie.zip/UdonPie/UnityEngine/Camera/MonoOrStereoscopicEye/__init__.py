from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MonoOrStereoscopicEye:
    def __new__(cls, arg1=None):
        '''
        :returns: MonoOrStereoscopicEye
        :rtype: UnityEngine.MonoOrStereoscopicEye
        '''
        pass
