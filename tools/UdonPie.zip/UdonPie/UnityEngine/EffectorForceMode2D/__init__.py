from UdonPie import UnityEngine
from UdonPie.Undefined import *


class EffectorForceMode2D:
    def __new__(cls, arg1=None):
        '''
        :returns: EffectorForceMode2D
        :rtype: UnityEngine.EffectorForceMode2D
        '''
        pass
