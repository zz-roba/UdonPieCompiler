from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ContactFilter2D:
    def __new__(cls, arg1=None):
        '''
        :returns: ContactFilter2D
        :rtype: UnityEngine.ContactFilter2D
        '''
        pass
