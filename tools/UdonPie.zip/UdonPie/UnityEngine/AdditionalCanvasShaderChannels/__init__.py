from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AdditionalCanvasShaderChannels:
    def __new__(cls, arg1=None):
        '''
        :returns: AdditionalCanvasShaderChannels
        :rtype: UnityEngine.AdditionalCanvasShaderChannels
        '''
        pass
