from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CameraClearFlags:
    def __new__(cls, arg1=None):
        '''
        :returns: CameraClearFlags
        :rtype: UnityEngine.CameraClearFlags
        '''
        pass
