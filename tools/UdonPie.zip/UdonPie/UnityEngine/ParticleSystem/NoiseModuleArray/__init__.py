from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NoiseModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: NoiseModuleArray
        :rtype: UnityEngine.NoiseModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: NoiseModule
        :type value: UnityEngine.NoiseModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: NoiseModule
        :rtype: UnityEngine.NoiseModule
        '''
        pass
