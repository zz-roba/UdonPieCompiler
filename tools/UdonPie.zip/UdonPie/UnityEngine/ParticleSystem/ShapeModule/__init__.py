from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ShapeModule:
    def __new__(cls, arg1=None):
        '''
        :returns: ShapeModule
        :rtype: UnityEngine.ShapeModule
        '''
        pass
