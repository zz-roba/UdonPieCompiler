from UdonPie import UnityEngine
from UdonPie.Undefined import *


class RotationBySpeedModule:
    def __new__(cls, arg1=None):
        '''
        :returns: RotationBySpeedModule
        :rtype: UnityEngine.RotationBySpeedModule
        '''
        pass
