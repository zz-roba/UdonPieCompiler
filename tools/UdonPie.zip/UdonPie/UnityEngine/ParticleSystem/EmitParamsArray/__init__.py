from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class EmitParamsArray:
    def __new__(cls, arg1=None):
        '''
        :returns: EmitParamsArray
        :rtype: UnityEngine.EmitParamsArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: EmitParams
        :type value: UnityEngine.EmitParams
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: EmitParams
        :rtype: UnityEngine.EmitParams
        '''
        pass
