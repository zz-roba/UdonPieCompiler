from UdonPie import UnityEngine
from UdonPie.Undefined import *


class SizeBySpeedModule:
    def __new__(cls, arg1=None):
        '''
        :returns: SizeBySpeedModule
        :rtype: UnityEngine.SizeBySpeedModule
        '''
        pass
