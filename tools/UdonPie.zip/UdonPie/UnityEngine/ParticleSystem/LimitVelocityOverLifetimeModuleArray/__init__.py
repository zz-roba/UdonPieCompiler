from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LimitVelocityOverLifetimeModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: LimitVelocityOverLifetimeModuleArray
        :rtype: UnityEngine.LimitVelocityOverLifetimeModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: LimitVelocityOverLifetimeModule
        :type value: UnityEngine.LimitVelocityOverLifetimeModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: LimitVelocityOverLifetimeModule
        :rtype: UnityEngine.LimitVelocityOverLifetimeModule
        '''
        pass
