from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class SubEmittersModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: SubEmittersModuleArray
        :rtype: UnityEngine.SubEmittersModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: SubEmittersModule
        :type value: UnityEngine.SubEmittersModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: SubEmittersModule
        :rtype: UnityEngine.SubEmittersModule
        '''
        pass
