from UdonPie import UnityEngine
from UdonPie.Undefined import *


class EmitParams:
    def __new__(cls, arg1=None):
        '''
        :returns: EmitParams
        :rtype: UnityEngine.EmitParams
        '''
        pass
