from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LimitVelocityOverLifetimeModule:
    def __new__(cls, arg1=None):
        '''
        :returns: LimitVelocityOverLifetimeModule
        :rtype: UnityEngine.LimitVelocityOverLifetimeModule
        '''
        pass
