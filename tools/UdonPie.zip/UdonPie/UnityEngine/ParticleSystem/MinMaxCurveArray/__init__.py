from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MinMaxCurveArray:
    def __new__(cls, arg1=None):
        '''
        :returns: MinMaxCurveArray
        :rtype: UnityEngine.MinMaxCurveArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: MinMaxCurve
        :type value: UnityEngine.MinMaxCurve
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: MinMaxCurve
        :rtype: UnityEngine.MinMaxCurve
        '''
        pass
