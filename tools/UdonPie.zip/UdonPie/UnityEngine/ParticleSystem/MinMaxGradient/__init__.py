from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MinMaxGradient:
    def __new__(cls, arg1=None):
        '''
        :returns: MinMaxGradient
        :rtype: UnityEngine.MinMaxGradient
        '''
        pass
