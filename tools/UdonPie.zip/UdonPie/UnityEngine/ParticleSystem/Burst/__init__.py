from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Burst:
    def __new__(cls, arg1=None):
        '''
        :returns: Burst
        :rtype: UnityEngine.Burst
        '''
        pass
