from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CustomDataModule:
    def __new__(cls, arg1=None):
        '''
        :returns: CustomDataModule
        :rtype: UnityEngine.CustomDataModule
        '''
        pass
