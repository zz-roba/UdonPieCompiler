from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class SizeBySpeedModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: SizeBySpeedModuleArray
        :rtype: UnityEngine.SizeBySpeedModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: SizeBySpeedModule
        :type value: UnityEngine.SizeBySpeedModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: SizeBySpeedModule
        :rtype: UnityEngine.SizeBySpeedModule
        '''
        pass
