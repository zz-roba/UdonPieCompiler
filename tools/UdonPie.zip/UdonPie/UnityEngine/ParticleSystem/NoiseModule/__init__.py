from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NoiseModule:
    def __new__(cls, arg1=None):
        '''
        :returns: NoiseModule
        :rtype: UnityEngine.NoiseModule
        '''
        pass
