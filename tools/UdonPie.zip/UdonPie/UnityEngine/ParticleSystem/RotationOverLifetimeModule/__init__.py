from UdonPie import UnityEngine
from UdonPie.Undefined import *


class RotationOverLifetimeModule:
    def __new__(cls, arg1=None):
        '''
        :returns: RotationOverLifetimeModule
        :rtype: UnityEngine.RotationOverLifetimeModule
        '''
        pass
