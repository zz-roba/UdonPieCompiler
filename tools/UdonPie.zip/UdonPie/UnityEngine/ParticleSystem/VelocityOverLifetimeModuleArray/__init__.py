from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class VelocityOverLifetimeModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: VelocityOverLifetimeModuleArray
        :rtype: UnityEngine.VelocityOverLifetimeModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: VelocityOverLifetimeModule
        :type value: UnityEngine.VelocityOverLifetimeModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: VelocityOverLifetimeModule
        :rtype: UnityEngine.VelocityOverLifetimeModule
        '''
        pass
