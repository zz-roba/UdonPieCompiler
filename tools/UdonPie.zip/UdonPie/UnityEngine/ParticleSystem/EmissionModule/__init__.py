from UdonPie import UnityEngine
from UdonPie.Undefined import *


class EmissionModule:
    def __new__(cls, arg1=None):
        '''
        :returns: EmissionModule
        :rtype: UnityEngine.EmissionModule
        '''
        pass
