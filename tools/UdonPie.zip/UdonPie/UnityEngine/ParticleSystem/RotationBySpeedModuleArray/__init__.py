from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class RotationBySpeedModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: RotationBySpeedModuleArray
        :rtype: UnityEngine.RotationBySpeedModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: RotationBySpeedModule
        :type value: UnityEngine.RotationBySpeedModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: RotationBySpeedModule
        :rtype: UnityEngine.RotationBySpeedModule
        '''
        pass
