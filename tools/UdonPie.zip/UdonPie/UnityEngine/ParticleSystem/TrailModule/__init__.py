from UdonPie import UnityEngine
from UdonPie.Undefined import *


class TrailModule:
    def __new__(cls, arg1=None):
        '''
        :returns: TrailModule
        :rtype: UnityEngine.TrailModule
        '''
        pass
