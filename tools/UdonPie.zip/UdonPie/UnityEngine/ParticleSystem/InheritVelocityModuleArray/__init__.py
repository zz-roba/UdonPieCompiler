from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class InheritVelocityModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: InheritVelocityModuleArray
        :rtype: UnityEngine.InheritVelocityModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: InheritVelocityModule
        :type value: UnityEngine.InheritVelocityModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: InheritVelocityModule
        :rtype: UnityEngine.InheritVelocityModule
        '''
        pass
