from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MainModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: MainModuleArray
        :rtype: UnityEngine.MainModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: MainModule
        :type value: UnityEngine.MainModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: MainModule
        :rtype: UnityEngine.MainModule
        '''
        pass
