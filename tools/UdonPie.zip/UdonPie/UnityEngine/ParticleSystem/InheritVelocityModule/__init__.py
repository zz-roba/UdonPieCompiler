from UdonPie import UnityEngine
from UdonPie.Undefined import *


class InheritVelocityModule:
    def __new__(cls, arg1=None):
        '''
        :returns: InheritVelocityModule
        :rtype: UnityEngine.InheritVelocityModule
        '''
        pass
