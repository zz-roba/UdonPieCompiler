from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Particle:
    def __new__(cls, arg1=None):
        '''
        :returns: Particle
        :rtype: UnityEngine.Particle
        '''
        pass
