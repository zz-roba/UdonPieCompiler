from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CollisionModule:
    def __new__(cls, arg1=None):
        '''
        :returns: CollisionModule
        :rtype: UnityEngine.CollisionModule
        '''
        pass
