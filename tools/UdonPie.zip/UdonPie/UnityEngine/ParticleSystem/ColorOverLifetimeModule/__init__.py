from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ColorOverLifetimeModule:
    def __new__(cls, arg1=None):
        '''
        :returns: ColorOverLifetimeModule
        :rtype: UnityEngine.ColorOverLifetimeModule
        '''
        pass
