from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LightsModule:
    def __new__(cls, arg1=None):
        '''
        :returns: LightsModule
        :rtype: UnityEngine.LightsModule
        '''
        pass
