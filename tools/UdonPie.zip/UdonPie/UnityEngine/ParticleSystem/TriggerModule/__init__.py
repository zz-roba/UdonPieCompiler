from UdonPie import UnityEngine
from UdonPie.Undefined import *


class TriggerModule:
    def __new__(cls, arg1=None):
        '''
        :returns: TriggerModule
        :rtype: UnityEngine.TriggerModule
        '''
        pass
