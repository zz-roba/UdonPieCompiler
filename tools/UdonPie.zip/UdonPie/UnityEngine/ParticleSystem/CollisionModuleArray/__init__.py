from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CollisionModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: CollisionModuleArray
        :rtype: UnityEngine.CollisionModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: CollisionModule
        :type value: UnityEngine.CollisionModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: CollisionModule
        :rtype: UnityEngine.CollisionModule
        '''
        pass
