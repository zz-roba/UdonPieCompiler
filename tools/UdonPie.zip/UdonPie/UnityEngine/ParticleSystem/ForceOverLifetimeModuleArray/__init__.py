from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ForceOverLifetimeModuleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: ForceOverLifetimeModuleArray
        :rtype: UnityEngine.ForceOverLifetimeModuleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: ForceOverLifetimeModule
        :type value: UnityEngine.ForceOverLifetimeModule
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: ForceOverLifetimeModule
        :rtype: UnityEngine.ForceOverLifetimeModule
        '''
        pass
