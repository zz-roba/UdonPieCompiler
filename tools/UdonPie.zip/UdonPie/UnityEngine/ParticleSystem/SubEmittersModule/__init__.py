from UdonPie import UnityEngine
from UdonPie.Undefined import *


class SubEmittersModule:
    def __new__(cls, arg1=None):
        '''
        :returns: SubEmittersModule
        :rtype: UnityEngine.SubEmittersModule
        '''
        pass
