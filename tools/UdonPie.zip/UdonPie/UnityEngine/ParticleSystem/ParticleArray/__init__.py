from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleArray
        :rtype: UnityEngine.ParticleArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: Particle
        :type value: UnityEngine.Particle
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: Particle
        :rtype: UnityEngine.Particle
        '''
        pass
