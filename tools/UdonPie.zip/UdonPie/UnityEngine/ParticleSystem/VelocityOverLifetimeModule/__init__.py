from UdonPie import UnityEngine
from UdonPie.Undefined import *


class VelocityOverLifetimeModule:
    def __new__(cls, arg1=None):
        '''
        :returns: VelocityOverLifetimeModule
        :rtype: UnityEngine.VelocityOverLifetimeModule
        '''
        pass
