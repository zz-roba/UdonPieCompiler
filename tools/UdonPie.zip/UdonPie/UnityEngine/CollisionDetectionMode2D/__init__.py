from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CollisionDetectionMode2D:
    def __new__(cls, arg1=None):
        '''
        :returns: CollisionDetectionMode2D
        :rtype: UnityEngine.CollisionDetectionMode2D
        '''
        pass
