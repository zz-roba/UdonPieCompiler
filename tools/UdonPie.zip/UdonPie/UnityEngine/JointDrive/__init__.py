from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointDrive:
    def __new__(cls, arg1=None):
        '''
        :returns: JointDrive
        :rtype: UnityEngine.JointDrive
        '''
        pass
