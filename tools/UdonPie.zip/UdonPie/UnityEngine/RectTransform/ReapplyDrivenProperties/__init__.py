from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ReapplyDrivenProperties:
    def __new__(cls, arg1=None):
        '''
        :returns: ReapplyDrivenProperties
        :rtype: UnityEngine.ReapplyDrivenProperties
        '''
        pass
