from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AccelerationEventArray:
    def __new__(cls, arg1=None):
        '''
        :returns: AccelerationEventArray
        :rtype: UnityEngine.AccelerationEventArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: AccelerationEvent
        :type value: UnityEngine.AccelerationEvent
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: AccelerationEvent
        :rtype: UnityEngine.AccelerationEvent
        '''
        pass
