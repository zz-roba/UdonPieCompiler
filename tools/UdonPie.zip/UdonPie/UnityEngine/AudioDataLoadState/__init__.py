from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioDataLoadState:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioDataLoadState
        :rtype: UnityEngine.AudioDataLoadState
        '''
        pass
