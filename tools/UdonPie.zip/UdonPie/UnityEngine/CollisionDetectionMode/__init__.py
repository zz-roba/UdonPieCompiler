from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CollisionDetectionMode:
    def __new__(cls, arg1=None):
        '''
        :returns: CollisionDetectionMode
        :rtype: UnityEngine.CollisionDetectionMode
        '''
        pass
