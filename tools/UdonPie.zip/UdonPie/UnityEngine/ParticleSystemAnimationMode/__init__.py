from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemAnimationMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemAnimationMode
        :rtype: UnityEngine.ParticleSystemAnimationMode
        '''
        pass
