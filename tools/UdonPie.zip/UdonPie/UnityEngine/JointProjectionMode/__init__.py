from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointProjectionMode:
    def __new__(cls, arg1=None):
        '''
        :returns: JointProjectionMode
        :rtype: UnityEngine.JointProjectionMode
        '''
        pass
