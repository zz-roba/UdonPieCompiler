from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioMixerGroup:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioMixerGroup
        :rtype: UnityEngine.AudioMixerGroup
        '''
        pass
