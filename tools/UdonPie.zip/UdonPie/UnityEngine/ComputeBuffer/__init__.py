from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ComputeBuffer:
    def __new__(cls, arg1=None):
        '''
        :returns: ComputeBuffer
        :rtype: UnityEngine.ComputeBuffer
        '''
        pass
