from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CapsuleDirection2D:
    def __new__(cls, arg1=None):
        '''
        :returns: CapsuleDirection2D
        :rtype: UnityEngine.CapsuleDirection2D
        '''
        pass
