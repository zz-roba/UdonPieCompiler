from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AvatarMaskBodyPart:
    def __new__(cls, arg1=None):
        '''
        :returns: AvatarMaskBodyPart
        :rtype: UnityEngine.AvatarMaskBodyPart
        '''
        pass
