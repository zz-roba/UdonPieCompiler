from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemShapeType:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemShapeType
        :rtype: UnityEngine.ParticleSystemShapeType
        '''
        pass
