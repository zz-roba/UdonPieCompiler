from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemGradientMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemGradientMode
        :rtype: UnityEngine.ParticleSystemGradientMode
        '''
        pass
