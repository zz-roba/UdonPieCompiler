from UdonPie import UnityEngine
from UdonPie.Undefined import *


class BlendWeights:
    def __new__(cls, arg1=None):
        '''
        :returns: BlendWeights
        :rtype: UnityEngine.BlendWeights
        '''
        pass
