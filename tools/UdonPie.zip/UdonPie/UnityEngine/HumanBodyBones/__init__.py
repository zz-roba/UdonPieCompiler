from UdonPie import UnityEngine
from UdonPie.Undefined import *


class HumanBodyBones:
    def __new__(cls, arg1=None):
        '''
        :returns: HumanBodyBones
        :rtype: UnityEngine.HumanBodyBones
        '''
        pass
