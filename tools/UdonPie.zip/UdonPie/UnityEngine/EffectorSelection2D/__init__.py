from UdonPie import UnityEngine
from UdonPie.Undefined import *


class EffectorSelection2D:
    def __new__(cls, arg1=None):
        '''
        :returns: EffectorSelection2D
        :rtype: UnityEngine.EffectorSelection2D
        '''
        pass
