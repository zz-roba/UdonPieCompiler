from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MaterialGlobalIlluminationFlags:
    def __new__(cls, arg1=None):
        '''
        :returns: MaterialGlobalIlluminationFlags
        :rtype: UnityEngine.MaterialGlobalIlluminationFlags
        '''
        pass
