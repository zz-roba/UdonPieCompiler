from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointTranslationLimits2D:
    def __new__(cls, arg1=None):
        '''
        :returns: JointTranslationLimits2D
        :rtype: UnityEngine.JointTranslationLimits2D
        '''
        pass
