from UdonPie import UnityEngine
from UdonPie.Undefined import *


class GenerationType:
    def __new__(cls, arg1=None):
        '''
        :returns: GenerationType
        :rtype: UnityEngine.GenerationType
        '''
        pass
