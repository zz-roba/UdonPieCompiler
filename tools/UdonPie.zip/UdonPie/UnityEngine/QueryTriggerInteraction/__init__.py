from UdonPie import UnityEngine
from UdonPie.Undefined import *


class QueryTriggerInteraction:
    def __new__(cls, arg1=None):
        '''
        :returns: QueryTriggerInteraction
        :rtype: UnityEngine.QueryTriggerInteraction
        '''
        pass
