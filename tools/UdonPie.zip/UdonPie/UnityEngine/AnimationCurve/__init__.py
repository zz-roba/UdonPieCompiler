from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimationCurve:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimationCurve
        :rtype: UnityEngine.AnimationCurve
        '''
        pass
