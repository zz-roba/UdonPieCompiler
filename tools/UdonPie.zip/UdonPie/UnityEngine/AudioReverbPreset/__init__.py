from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioReverbPreset:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioReverbPreset
        :rtype: UnityEngine.AudioReverbPreset
        '''
        pass
