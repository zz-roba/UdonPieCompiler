from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Color32:
    def __new__(cls, arg1=None):
        '''
        :returns: Color32
        :rtype: UnityEngine.Color32
        '''
        pass
