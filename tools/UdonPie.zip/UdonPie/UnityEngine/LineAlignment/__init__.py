from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LineAlignment:
    def __new__(cls, arg1=None):
        '''
        :returns: LineAlignment
        :rtype: UnityEngine.LineAlignment
        '''
        pass
