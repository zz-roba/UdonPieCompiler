from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MotionVectorGenerationMode:
    def __new__(cls, arg1=None):
        '''
        :returns: MotionVectorGenerationMode
        :rtype: UnityEngine.MotionVectorGenerationMode
        '''
        pass
