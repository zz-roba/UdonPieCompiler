from UdonPie import UnityEngine
from UdonPie.Undefined import *


class BillboardAsset:
    def __new__(cls, arg1=None):
        '''
        :returns: BillboardAsset
        :rtype: UnityEngine.BillboardAsset
        '''
        pass
