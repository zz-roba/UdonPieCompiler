from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Cubemap:
    def __new__(cls, arg1=None):
        '''
        :returns: Cubemap
        :rtype: UnityEngine.Cubemap
        '''
        pass
