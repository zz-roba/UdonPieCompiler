from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PhysicMaterialCombine:
    def __new__(cls, arg1=None):
        '''
        :returns: PhysicMaterialCombine
        :rtype: UnityEngine.PhysicMaterialCombine
        '''
        pass
