from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PhysicsScene2D:
    def __new__(cls, arg1=None):
        '''
        :returns: PhysicsScene2D
        :rtype: UnityEngine.PhysicsScene2D
        '''
        pass
