from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemShapeMultiModeValue:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemShapeMultiModeValue
        :rtype: UnityEngine.ParticleSystemShapeMultiModeValue
        '''
        pass
