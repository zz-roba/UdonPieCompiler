from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemCollisionQuality:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemCollisionQuality
        :rtype: UnityEngine.ParticleSystemCollisionQuality
        '''
        pass
