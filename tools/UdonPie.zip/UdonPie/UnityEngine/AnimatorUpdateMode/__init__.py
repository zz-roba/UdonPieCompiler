from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimatorUpdateMode:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimatorUpdateMode
        :rtype: UnityEngine.AnimatorUpdateMode
        '''
        pass
