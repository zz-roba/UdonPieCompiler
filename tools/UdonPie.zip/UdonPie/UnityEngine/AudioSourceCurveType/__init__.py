from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioSourceCurveType:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioSourceCurveType
        :rtype: UnityEngine.AudioSourceCurveType
        '''
        pass
