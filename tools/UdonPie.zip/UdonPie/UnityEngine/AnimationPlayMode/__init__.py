from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimationPlayMode:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimationPlayMode
        :rtype: UnityEngine.AnimationPlayMode
        '''
        pass
