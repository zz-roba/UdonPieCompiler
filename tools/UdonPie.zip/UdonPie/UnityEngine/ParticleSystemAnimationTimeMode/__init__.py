from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemAnimationTimeMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemAnimationTimeMode
        :rtype: UnityEngine.ParticleSystemAnimationTimeMode
        '''
        pass
