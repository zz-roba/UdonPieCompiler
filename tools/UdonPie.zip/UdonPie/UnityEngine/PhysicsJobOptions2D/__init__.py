from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PhysicsJobOptions2D:
    def __new__(cls, arg1=None):
        '''
        :returns: PhysicsJobOptions2D
        :rtype: UnityEngine.PhysicsJobOptions2D
        '''
        pass
