from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LineTextureMode:
    def __new__(cls, arg1=None):
        '''
        :returns: LineTextureMode
        :rtype: UnityEngine.LineTextureMode
        '''
        pass
