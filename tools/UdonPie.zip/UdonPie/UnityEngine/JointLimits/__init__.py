from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointLimits:
    def __new__(cls, arg1=None):
        '''
        :returns: JointLimits
        :rtype: UnityEngine.JointLimits
        '''
        pass
