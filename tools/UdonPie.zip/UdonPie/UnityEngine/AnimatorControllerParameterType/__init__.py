from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimatorControllerParameterType:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimatorControllerParameterType
        :rtype: UnityEngine.AnimatorControllerParameterType
        '''
        pass
