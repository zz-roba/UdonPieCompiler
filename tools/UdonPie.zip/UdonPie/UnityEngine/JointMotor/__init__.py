from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointMotor:
    def __new__(cls, arg1=None):
        '''
        :returns: JointMotor
        :rtype: UnityEngine.JointMotor
        '''
        pass
