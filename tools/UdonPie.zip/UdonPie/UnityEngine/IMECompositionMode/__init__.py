from UdonPie import UnityEngine
from UdonPie.Undefined import *


class IMECompositionMode:
    def __new__(cls, arg1=None):
        '''
        :returns: IMECompositionMode
        :rtype: UnityEngine.IMECompositionMode
        '''
        pass
