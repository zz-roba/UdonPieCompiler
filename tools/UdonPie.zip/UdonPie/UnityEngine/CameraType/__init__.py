from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CameraType:
    def __new__(cls, arg1=None):
        '''
        :returns: CameraType
        :rtype: UnityEngine.CameraType
        '''
        pass
