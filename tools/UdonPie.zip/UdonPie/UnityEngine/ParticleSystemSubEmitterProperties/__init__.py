from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemSubEmitterProperties:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemSubEmitterProperties
        :rtype: UnityEngine.ParticleSystemSubEmitterProperties
        '''
        pass
