from UdonPie import UnityEngine
from UdonPie.Undefined import *


class DurationUnit:
    def __new__(cls, arg1=None):
        '''
        :returns: DurationUnit
        :rtype: UnityEngine.DurationUnit
        '''
        pass
