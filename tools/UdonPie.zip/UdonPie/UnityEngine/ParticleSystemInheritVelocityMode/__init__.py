from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemInheritVelocityMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemInheritVelocityMode
        :rtype: UnityEngine.ParticleSystemInheritVelocityMode
        '''
        pass
