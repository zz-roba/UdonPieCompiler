from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ForceMode2D:
    def __new__(cls, arg1=None):
        '''
        :returns: ForceMode2D
        :rtype: UnityEngine.ForceMode2D
        '''
        pass
