from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AccelerationEvent:
    def __new__(cls, arg1=None):
        '''
        :returns: AccelerationEvent
        :rtype: UnityEngine.AccelerationEvent
        '''
        pass
