from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Gyroscope:
    def __new__(cls, arg1=None):
        '''
        :returns: Gyroscope
        :rtype: UnityEngine.Gyroscope
        '''
        pass
