from UdonPie import UnityEngine
from UdonPie.Undefined import *


class HorizontalWrapMode:
    def __new__(cls, arg1=None):
        '''
        :returns: HorizontalWrapMode
        :rtype: UnityEngine.HorizontalWrapMode
        '''
        pass
