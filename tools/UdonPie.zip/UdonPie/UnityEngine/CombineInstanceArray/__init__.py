from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class CombineInstanceArray:
    def __new__(cls, arg1=None):
        '''
        :returns: CombineInstanceArray
        :rtype: UnityEngine.CombineInstanceArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: CombineInstance
        :type value: UnityEngine.CombineInstance
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: CombineInstance
        :rtype: UnityEngine.CombineInstance
        '''
        pass
