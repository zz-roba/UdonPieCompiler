from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MeshColliderCookingOptions:
    def __new__(cls, arg1=None):
        '''
        :returns: MeshColliderCookingOptions
        :rtype: UnityEngine.MeshColliderCookingOptions
        '''
        pass
