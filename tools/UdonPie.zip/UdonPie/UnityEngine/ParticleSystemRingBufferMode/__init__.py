from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemRingBufferMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemRingBufferMode
        :rtype: UnityEngine.ParticleSystemRingBufferMode
        '''
        pass
