from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Color32Array:
    def __new__(cls, arg1=None):
        '''
        :returns: Color32Array
        :rtype: UnityEngine.Color32Array
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: Color32
        :type value: UnityEngine.Color32
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: Color32
        :rtype: UnityEngine.Color32
        '''
        pass
