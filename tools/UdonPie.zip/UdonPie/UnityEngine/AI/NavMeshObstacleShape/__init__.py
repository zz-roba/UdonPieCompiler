from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshObstacleShape:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshObstacleShape
        :rtype: UnityEngine.NavMeshObstacleShape
        '''
        pass
