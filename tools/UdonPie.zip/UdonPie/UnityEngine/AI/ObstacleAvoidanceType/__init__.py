from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ObstacleAvoidanceType:
    def __new__(cls, arg1=None):
        '''
        :returns: ObstacleAvoidanceType
        :rtype: UnityEngine.ObstacleAvoidanceType
        '''
        pass
