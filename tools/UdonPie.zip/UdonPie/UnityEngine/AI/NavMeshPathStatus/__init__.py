from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshPathStatus:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshPathStatus
        :rtype: UnityEngine.NavMeshPathStatus
        '''
        pass
