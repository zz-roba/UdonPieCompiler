from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshLinkData:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshLinkData
        :rtype: UnityEngine.NavMeshLinkData
        '''
        pass
