from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshTriangulation:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshTriangulation
        :rtype: UnityEngine.NavMeshTriangulation
        '''
        pass
