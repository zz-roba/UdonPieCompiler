from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshBuildSettings:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshBuildSettings
        :rtype: UnityEngine.NavMeshBuildSettings
        '''
        pass
