from UdonPie import UnityEngine
from UdonPie.Undefined import *


class NavMeshLinkInstance:
    def __new__(cls, arg1=None):
        '''
        :returns: NavMeshLinkInstance
        :rtype: UnityEngine.NavMeshLinkInstance
        '''
        pass
