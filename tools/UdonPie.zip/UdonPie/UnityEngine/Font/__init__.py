from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Font:
    def __new__(cls, arg1=None):
        '''
        :returns: Font
        :rtype: UnityEngine.Font
        '''
        pass
