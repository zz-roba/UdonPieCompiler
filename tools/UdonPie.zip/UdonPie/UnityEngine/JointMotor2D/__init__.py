from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointMotor2D:
    def __new__(cls, arg1=None):
        '''
        :returns: JointMotor2D
        :rtype: UnityEngine.JointMotor2D
        '''
        pass
