from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PhysicsArray:
    def __new__(cls, arg1=None):
        '''
        :returns: PhysicsArray
        :rtype: UnityEngine.PhysicsArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: Physics
        :type value: UnityEngine.Physics
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: Physics
        :rtype: UnityEngine.Physics
        '''
        pass
