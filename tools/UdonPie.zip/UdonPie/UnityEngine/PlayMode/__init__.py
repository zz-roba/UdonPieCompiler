from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PlayMode:
    def __new__(cls, arg1=None):
        '''
        :returns: PlayMode
        :rtype: UnityEngine.PlayMode
        '''
        pass
