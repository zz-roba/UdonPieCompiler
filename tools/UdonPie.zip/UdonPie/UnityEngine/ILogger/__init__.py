from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ILogger:
    def __new__(cls, arg1=None):
        '''
        :returns: ILogger
        :rtype: UnityEngine.ILogger
        '''
        pass
