from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemAnimationType:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemAnimationType
        :rtype: UnityEngine.ParticleSystemAnimationType
        '''
        pass
