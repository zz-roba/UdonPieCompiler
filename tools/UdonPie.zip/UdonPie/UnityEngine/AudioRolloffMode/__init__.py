from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioRolloffMode:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioRolloffMode
        :rtype: UnityEngine.AudioRolloffMode
        '''
        pass
