from UdonPie import UnityEngine
from UdonPie.Undefined import *


class FrustumPlanes:
    def __new__(cls, arg1=None):
        '''
        :returns: FrustumPlanes
        :rtype: UnityEngine.FrustumPlanes
        '''
        pass
