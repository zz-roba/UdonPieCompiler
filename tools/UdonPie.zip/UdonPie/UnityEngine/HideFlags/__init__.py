from UdonPie import UnityEngine
from UdonPie.Undefined import *


class HideFlags:
    def __new__(cls, arg1=None):
        '''
        :returns: HideFlags
        :rtype: UnityEngine.HideFlags
        '''
        pass
