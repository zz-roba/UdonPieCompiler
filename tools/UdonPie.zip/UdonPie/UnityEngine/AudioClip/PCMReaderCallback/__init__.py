from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PCMReaderCallback:
    def __new__(cls, arg1=None):
        '''
        :returns: PCMReaderCallback
        :rtype: UnityEngine.PCMReaderCallback
        '''
        pass
