from UdonPie import UnityEngine
from UdonPie.Undefined import *


class BaseEventData:
    def __new__(cls, arg1=None):
        '''
        :returns: BaseEventData
        :rtype: UnityEngine.BaseEventData
        '''
        pass
