from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AxisEventData:
    def __new__(cls, arg1=None):
        '''
        :returns: AxisEventData
        :rtype: UnityEngine.AxisEventData
        '''
        pass
