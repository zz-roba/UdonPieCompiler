from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PointerEventData:
    def __new__(cls, arg1=None):
        '''
        :returns: PointerEventData
        :rtype: UnityEngine.PointerEventData
        '''
        pass
