from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemCustomData:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemCustomData
        :rtype: UnityEngine.ParticleSystemCustomData
        '''
        pass
