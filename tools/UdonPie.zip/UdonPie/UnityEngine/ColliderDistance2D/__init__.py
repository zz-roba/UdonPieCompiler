from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ColliderDistance2D:
    def __new__(cls, arg1=None):
        '''
        :returns: ColliderDistance2D
        :rtype: UnityEngine.ColliderDistance2D
        '''
        pass
