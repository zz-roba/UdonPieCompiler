from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointSpring:
    def __new__(cls, arg1=None):
        '''
        :returns: JointSpring
        :rtype: UnityEngine.JointSpring
        '''
        pass
