from UdonPie import System
from UdonPie import UnityEngine
from UdonPie.Undefined import *


class RenderBufferArray:
    def __new__(cls, arg1=None):
        '''
        :returns: RenderBufferArray
        :rtype: UnityEngine.RenderBufferArray
        '''
        pass

    def __setitem__(self, key, value):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :param value: RenderBuffer
        :type value: UnityEngine.RenderBuffer
        '''
        pass

    def __getitem__(self, key):
        '''
        :param key: Int32
        :type key: System.Int32 or int
        :returns: RenderBuffer
        :rtype: UnityEngine.RenderBuffer
        '''
        pass
