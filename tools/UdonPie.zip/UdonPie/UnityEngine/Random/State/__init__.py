from UdonPie import UnityEngine
from UdonPie.Undefined import *


class State:
    def __new__(cls, arg1=None):
        '''
        :returns: State
        :rtype: UnityEngine.State
        '''
        pass
