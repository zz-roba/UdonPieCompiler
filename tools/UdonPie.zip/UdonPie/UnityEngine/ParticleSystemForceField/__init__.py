from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemForceField:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemForceField
        :rtype: UnityEngine.ParticleSystemForceField
        '''
        pass
