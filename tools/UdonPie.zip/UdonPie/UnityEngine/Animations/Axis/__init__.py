from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Axis:
    def __new__(cls, arg1=None):
        '''
        :returns: Axis
        :rtype: UnityEngine.Axis
        '''
        pass
