from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemGameObjectFilter:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemGameObjectFilter
        :rtype: UnityEngine.ParticleSystemGameObjectFilter
        '''
        pass
