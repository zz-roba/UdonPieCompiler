from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemTrailMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemTrailMode
        :rtype: UnityEngine.ParticleSystemTrailMode
        '''
        pass
