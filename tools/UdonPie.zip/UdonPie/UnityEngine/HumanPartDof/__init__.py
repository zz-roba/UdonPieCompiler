from UdonPie import UnityEngine
from UdonPie.Undefined import *


class HumanPartDof:
    def __new__(cls, arg1=None):
        '''
        :returns: HumanPartDof
        :rtype: UnityEngine.HumanPartDof
        '''
        pass
