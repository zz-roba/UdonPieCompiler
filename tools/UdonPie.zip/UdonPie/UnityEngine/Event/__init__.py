from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Event:
    def __new__(cls, arg1=None):
        '''
        :returns: Event
        :rtype: UnityEngine.Event
        '''
        pass
