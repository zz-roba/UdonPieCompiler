from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PhysicsScene:
    def __new__(cls, arg1=None):
        '''
        :returns: PhysicsScene
        :rtype: UnityEngine.PhysicsScene
        '''
        pass
