from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemCullingMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemCullingMode
        :rtype: UnityEngine.ParticleSystemCullingMode
        '''
        pass
