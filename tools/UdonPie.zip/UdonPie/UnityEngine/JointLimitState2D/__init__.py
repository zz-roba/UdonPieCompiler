from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointLimitState2D:
    def __new__(cls, arg1=None):
        '''
        :returns: JointLimitState2D
        :rtype: UnityEngine.JointLimitState2D
        '''
        pass
