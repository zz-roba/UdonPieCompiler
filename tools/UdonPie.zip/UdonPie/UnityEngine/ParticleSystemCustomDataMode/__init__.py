from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemCustomDataMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemCustomDataMode
        :rtype: UnityEngine.ParticleSystemCustomDataMode
        '''
        pass
