from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointSuspension2D:
    def __new__(cls, arg1=None):
        '''
        :returns: JointSuspension2D
        :rtype: UnityEngine.JointSuspension2D
        '''
        pass
