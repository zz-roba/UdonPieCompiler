from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Flare:
    def __new__(cls, arg1=None):
        '''
        :returns: Flare
        :rtype: UnityEngine.Flare
        '''
        pass
