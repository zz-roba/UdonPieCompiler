from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemScalingMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemScalingMode
        :rtype: UnityEngine.ParticleSystemScalingMode
        '''
        pass
