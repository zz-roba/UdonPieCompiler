from UdonPie import UnityEngine
from UdonPie.Undefined import *


class MeshTopology:
    def __new__(cls, arg1=None):
        '''
        :returns: MeshTopology
        :rtype: UnityEngine.MeshTopology
        '''
        pass
