from UdonPie import UnityEngine
from UdonPie.Undefined import *


class PlayableGraph:
    def __new__(cls, arg1=None):
        '''
        :returns: PlayableGraph
        :rtype: UnityEngine.PlayableGraph
        '''
        pass
