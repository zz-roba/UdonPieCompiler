from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LightShadows:
    def __new__(cls, arg1=None):
        '''
        :returns: LightShadows
        :rtype: UnityEngine.LightShadows
        '''
        pass
