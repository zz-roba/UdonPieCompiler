from UdonPie import UnityEngine
from UdonPie.Undefined import *


class JointAngleLimits2D:
    def __new__(cls, arg1=None):
        '''
        :returns: JointAngleLimits2D
        :rtype: UnityEngine.JointAngleLimits2D
        '''
        pass
