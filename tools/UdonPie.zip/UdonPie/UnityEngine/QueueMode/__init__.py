from UdonPie import UnityEngine
from UdonPie.Undefined import *


class QueueMode:
    def __new__(cls, arg1=None):
        '''
        :returns: QueueMode
        :rtype: UnityEngine.QueueMode
        '''
        pass
