from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LightShadowCasterMode:
    def __new__(cls, arg1=None):
        '''
        :returns: LightShadowCasterMode
        :rtype: UnityEngine.LightShadowCasterMode
        '''
        pass
