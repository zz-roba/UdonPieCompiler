from UdonPie import UnityEngine
from UdonPie.Undefined import *


class RenderBuffer:
    def __new__(cls, arg1=None):
        '''
        :returns: RenderBuffer
        :rtype: UnityEngine.RenderBuffer
        '''
        pass
