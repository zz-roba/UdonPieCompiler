from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemNoiseQuality:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemNoiseQuality
        :rtype: UnityEngine.ParticleSystemNoiseQuality
        '''
        pass
