from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ParticleSystemCollisionMode:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemCollisionMode
        :rtype: UnityEngine.ParticleSystemCollisionMode
        '''
        pass
