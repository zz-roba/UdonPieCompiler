from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AvatarIKHint:
    def __new__(cls, arg1=None):
        '''
        :returns: AvatarIKHint
        :rtype: UnityEngine.AvatarIKHint
        '''
        pass
