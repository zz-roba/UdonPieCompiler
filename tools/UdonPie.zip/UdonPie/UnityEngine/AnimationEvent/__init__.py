from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimationEvent:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimationEvent
        :rtype: UnityEngine.AnimationEvent
        '''
        pass
