from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LocationService:
    def __new__(cls, arg1=None):
        '''
        :returns: LocationService
        :rtype: UnityEngine.LocationService
        '''
        pass
