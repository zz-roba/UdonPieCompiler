from UdonPie import UnityEngine
from UdonPie.Undefined import *


class FogMode:
    def __new__(cls, arg1=None):
        '''
        :returns: FogMode
        :rtype: UnityEngine.FogMode
        '''
        pass
