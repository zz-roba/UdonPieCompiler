from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LightRenderMode:
    def __new__(cls, arg1=None):
        '''
        :returns: LightRenderMode
        :rtype: UnityEngine.LightRenderMode
        '''
        pass
