from UdonPie import UnityEngine
from UdonPie.Undefined import *


class LightBakingOutput:
    def __new__(cls, arg1=None):
        '''
        :returns: LightBakingOutput
        :rtype: UnityEngine.LightBakingOutput
        '''
        pass
