from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ConfigurableJointMotion:
    def __new__(cls, arg1=None):
        '''
        :returns: ConfigurableJointMotion
        :rtype: UnityEngine.ConfigurableJointMotion
        '''
        pass
