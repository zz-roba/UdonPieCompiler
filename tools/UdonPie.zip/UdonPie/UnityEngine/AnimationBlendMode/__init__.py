from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AnimationBlendMode:
    def __new__(cls, arg1=None):
        '''
        :returns: AnimationBlendMode
        :rtype: UnityEngine.AnimationBlendMode
        '''
        pass
