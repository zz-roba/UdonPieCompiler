from UdonPie import UnityEngine
from UdonPie.Undefined import *


class UnityEventCallState:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEventCallState
        :rtype: UnityEngine.UnityEventCallState
        '''
        pass
