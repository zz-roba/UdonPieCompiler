from UdonPie import UnityEngine
from UdonPie.Undefined import *


class UnityAction:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityAction
        :rtype: UnityEngine.UnityAction
        '''
        pass
