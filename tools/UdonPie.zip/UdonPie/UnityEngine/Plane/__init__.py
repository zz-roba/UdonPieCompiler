from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Plane:
    def __new__(cls, arg1=None):
        '''
        :returns: Plane
        :rtype: UnityEngine.Plane
        '''
        pass
