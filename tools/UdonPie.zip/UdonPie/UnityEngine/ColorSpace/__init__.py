from UdonPie import UnityEngine
from UdonPie.Undefined import *


class ColorSpace:
    def __new__(cls, arg1=None):
        '''
        :returns: ColorSpace
        :rtype: UnityEngine.ColorSpace
        '''
        pass
