from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AudioClipLoadType:
    def __new__(cls, arg1=None):
        '''
        :returns: AudioClipLoadType
        :rtype: UnityEngine.AudioClipLoadType
        '''
        pass
