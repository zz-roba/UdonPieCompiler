from UdonPie import UnityEngine
from UdonPie.Undefined import *


class AvatarTarget:
    def __new__(cls, arg1=None):
        '''
        :returns: AvatarTarget
        :rtype: UnityEngine.AvatarTarget
        '''
        pass
