from UdonPie import UnityEngine
from UdonPie.Undefined import *


class Rect:
    def __new__(cls, arg1=None):
        '''
        :returns: Rect
        :rtype: UnityEngine.Rect
        '''
        pass
