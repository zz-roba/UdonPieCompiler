class AINavMeshHitRef:
    def __new__(cls, arg1=None):
        '''
        :returns: AINavMeshHitRef
        :rtype: AINavMeshHitRef
        '''
        pass


class BooleanRef:
    def __new__(cls, arg1=None):
        '''
        :returns: BooleanRef
        :rtype: BooleanRef
        '''
        pass


class ByteRef:
    def __new__(cls, arg1=None):
        '''
        :returns: ByteRef
        :rtype: ByteRef
        '''
        pass


class CharRef:
    def __new__(cls, arg1=None):
        '''
        :returns: CharRef
        :rtype: CharRef
        '''
        pass


class DateTimeRef:
    def __new__(cls, arg1=None):
        '''
        :returns: DateTimeRef
        :rtype: DateTimeRef
        '''
        pass


class DoubleRef:
    def __new__(cls, arg1=None):
        '''
        :returns: DoubleRef
        :rtype: DoubleRef
        '''
        pass


class HumanPoseRef:
    def __new__(cls, arg1=None):
        '''
        :returns: HumanPoseRef
        :rtype: HumanPoseRef
        '''
        pass


class Int16Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Int16Ref
        :rtype: Int16Ref
        '''
        pass


class Int32Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Int32Ref
        :rtype: Int32Ref
        '''
        pass


class Int64Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Int64Ref
        :rtype: Int64Ref
        '''
        pass


class ListT:
    def __new__(cls, arg1=None):
        '''
        :returns: ListT
        :rtype: ListT
        '''
        pass


class Matrix4x4Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Matrix4x4Ref
        :rtype: Matrix4x4Ref
        '''
        pass


class ParticleSystemParticleRef:
    def __new__(cls, arg1=None):
        '''
        :returns: ParticleSystemParticleRef
        :rtype: ParticleSystemParticleRef
        '''
        pass


class QuaternionRef:
    def __new__(cls, arg1=None):
        '''
        :returns: QuaternionRef
        :rtype: QuaternionRef
        '''
        pass


class RaycastHitRef:
    def __new__(cls, arg1=None):
        '''
        :returns: RaycastHitRef
        :rtype: RaycastHitRef
        '''
        pass


class SByteRef:
    def __new__(cls, arg1=None):
        '''
        :returns: SByteRef
        :rtype: SByteRef
        '''
        pass


class SceneDescriptorSpawnOrientation:
    def __new__(cls, arg1=None):
        '''
        :returns: SceneDescriptorSpawnOrientation
        :rtype: SceneDescriptorSpawnOrientation
        '''
        pass


class SingleRef:
    def __new__(cls, arg1=None):
        '''
        :returns: SingleRef
        :rtype: SingleRef
        '''
        pass


class SystemCharAsterix:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemCharAsterix
        :rtype: SystemCharAsterix
        '''
        pass


class SystemCollectionsGenericIEnumerable:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemCollectionsGenericIEnumerable
        :rtype: SystemCollectionsGenericIEnumerable
        '''
        pass


class SystemCollectionsGenericIList:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemCollectionsGenericIList
        :rtype: SystemCollectionsGenericIList
        '''
        pass


class SystemCollectionsGenericList:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemCollectionsGenericList
        :rtype: SystemCollectionsGenericList
        '''
        pass


class SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo
        :rtype: SystemCollectionsGenericListUnityEngineRenderingReflectionProbeBlendInfo
        '''
        pass


class SystemFunc:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemFunc
        :rtype: SystemFunc
        '''
        pass


class SystemGlobalizationCalendar:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemGlobalizationCalendar
        :rtype: SystemGlobalizationCalendar
        '''
        pass


class SystemSByteAsterix:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemSByteAsterix
        :rtype: SystemSByteAsterix
        '''
        pass


class SystemSingleArray:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemSingleArray
        :rtype: SystemSingleArray
        '''
        pass


class SystemTextEncoding:
    def __new__(cls, arg1=None):
        '''
        :returns: SystemTextEncoding
        :rtype: SystemTextEncoding
        '''
        pass


class UIILayoutElementRef:
    def __new__(cls, arg1=None):
        '''
        :returns: UIILayoutElementRef
        :rtype: UIILayoutElementRef
        '''
        pass


class UIVertexRef:
    def __new__(cls, arg1=None):
        '''
        :returns: UIVertexRef
        :rtype: UIVertexRef
        '''
        pass


class UInt16Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: UInt16Ref
        :rtype: UInt16Ref
        '''
        pass


class UInt32Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: UInt32Ref
        :rtype: UInt32Ref
        '''
        pass


class UInt64Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: UInt64Ref
        :rtype: UInt64Ref
        '''
        pass


class UnityEngineAINavMeshOnNavMeshPreUpdate:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineAINavMeshOnNavMeshPreUpdate
        :rtype: UnityEngineAINavMeshOnNavMeshPreUpdate
        '''
        pass


class UnityEngineArmDof:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineArmDof
        :rtype: UnityEngineArmDof
        '''
        pass


class UnityEngineBodyDof:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineBodyDof
        :rtype: UnityEngineBodyDof
        '''
        pass


class UnityEngineCameraCameraCallback:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineCameraCameraCallback
        :rtype: UnityEngineCameraCameraCallback
        '''
        pass


class UnityEngineFingerDof:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineFingerDof
        :rtype: UnityEngineFingerDof
        '''
        pass


class UnityEngineHeadDof:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineHeadDof
        :rtype: UnityEngineHeadDof
        '''
        pass


class UnityEngineLegDof:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineLegDof
        :rtype: UnityEngineLegDof
        '''
        pass


class UnityEngineRenderingDefaultReflectionMode:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineRenderingDefaultReflectionMode
        :rtype: UnityEngineRenderingDefaultReflectionMode
        '''
        pass


class UnityEngineRenderingReflectionProbeUsage:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineRenderingReflectionProbeUsage
        :rtype: UnityEngineRenderingReflectionProbeUsage
        '''
        pass


class UnityEngineTrackedReference:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineTrackedReference
        :rtype: UnityEngineTrackedReference
        '''
        pass


class UnityEngineUIToggleToggleTransition:
    def __new__(cls, arg1=None):
        '''
        :returns: UnityEngineUIToggleToggleTransition
        :rtype: UnityEngineUIToggleToggleTransition
        '''
        pass


class VRCSDKBaseVRC:
    def __new__(cls, arg1=None):
        '''
        :returns: VRCSDKBaseVRC
        :rtype: VRCSDKBaseVRC
        '''
        pass


class Vector2Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Vector2Ref
        :rtype: Vector2Ref
        '''
        pass


class Vector3Ref:
    def __new__(cls, arg1=None):
        '''
        :returns: Vector3Ref
        :rtype: Vector3Ref
        '''
        pass


class WheelHitRef:
    def __new__(cls, arg1=None):
        '''
        :returns: WheelHitRef
        :rtype: WheelHitRef
        '''
        pass
