from UdonPie import GameObject
from UdonPie import Transform

this_trans = Transform()
this_gameObj = GameObject()
Void = None


def instantiate(arg1):
    '''
    :param arg1: GameObject
    :type arg1: GameObject
    '''
    pass
